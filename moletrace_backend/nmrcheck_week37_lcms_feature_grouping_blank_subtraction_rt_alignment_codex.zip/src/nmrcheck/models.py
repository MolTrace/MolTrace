
from __future__ import annotations

from datetime import datetime
from typing import Any, Literal

from pydantic import BaseModel, ConfigDict, EmailStr, Field, field_validator

from .nmr2d_models import (
    NMR2DAnalyzeRequest,
    NMR2DAnalyzeResult,
    NMR2DCorrelationEvidence,
    NMR2DExperimentType,
    NMR2DPeak,
    NMR2DPreviewReport,
    NMR2DRunRecord,
)

DiagnosticLabel = Literal[
    "consistent",
    "possible_overlap_or_missing_labile_signals",
    "possible_impurity_or_incorrect_assignment",
    "invalid_input",
]

JobStatus = Literal["pending", "queued", "processing", "completed", "failed"]
ActionTokenPurpose = Literal["verify_email", "reset_password"]
ReviewStatus = Literal["pending_review", "approved", "rejected", "needs_revision"]
ReviewAction = Literal["approve", "reject", "override", "request_changes", "review"]
FIDPresetId = Literal[
    "baseline_preserve",
    "balanced",
    "sensitive_weak_peaks",
    "higher_resolution",
    "custom",
]
FIDQualityLabel = Literal["good", "review", "poor", "failed"]


class RawArchiveRecord(BaseModel):
    model_config = ConfigDict(extra="forbid")

    id: int
    created_at: datetime
    user_id: int | None = None
    filename: str = Field(min_length=1, max_length=255)
    content_type: str | None = Field(default=None, max_length=100)
    byte_size: int = Field(ge=0)
    sha256: str = Field(min_length=64, max_length=64)
    storage_path: str = Field(min_length=1)
    vendor_detected: str = Field(min_length=1, max_length=100)
    dataset_root: str | None = Field(default=None, max_length=500)
    required_files_present: bool = False
    files_found: list[str] = Field(default_factory=list)
    acquisition_metadata: dict[str, Any] = Field(default_factory=dict)
    warnings: list[str] = Field(default_factory=list)
    immutable: bool = True
    raw_archive_id: str | None = Field(default=None, min_length=64, max_length=64)


class RawArchivePreview(BaseModel):
    model_config = ConfigDict(extra="forbid")

    archive: RawArchiveRecord
    already_stored: bool = False
    provenance: dict[str, Any] = Field(default_factory=dict)


class RawArchiveExportManifest(BaseModel):
    model_config = ConfigDict(extra="forbid")

    exported_at: datetime
    raw_archive: RawArchiveRecord | None = None
    raw_archive_id: str | None = None
    sha256: str | None = Field(default=None, min_length=64, max_length=64)
    original_filename: str | None = None
    storage_backend: str | None = None
    include_original_archive: bool = False
    sha256_verified: bool = False
    files: list[str] = Field(default_factory=list)
    warnings: list[str] = Field(default_factory=list)


class Peak(BaseModel):
    model_config = ConfigDict(extra="forbid")

    shift_ppm: float = Field(ge=-50.0, le=260.0)
    multiplicity: str = Field(min_length=1, max_length=20)
    integration_h: float = Field(gt=0.0, le=50.0)
    j_values_hz: list[float] = Field(default_factory=list)


class StructureSummary(BaseModel):
    model_config = ConfigDict(extra="forbid")

    smiles: str
    formula: str
    molecular_weight: float
    total_hydrogens: int
    labile_hydrogens: int
    non_labile_hydrogens: int
    aromatic_protons: int
    aliphatic_protons: int
    aromatic_atom_count: int


class SolventHeuristicHit(BaseModel):
    model_config = ConfigDict(extra="forbid")

    solvent: str
    signal_label: str
    expected_ppm: float
    observed_ppm: float
    delta_ppm: float = Field(ge=0.0)
    kind: Literal["residual", "water", "exchange", "impurity"]


class AnalysisInputs(BaseModel):
    model_config = ConfigDict(
        extra="forbid",
        json_schema_extra={
            "examples": [
                {
                    "sample_id": "cmpd-001",
                    "smiles": "CCO",
                    "nmr_text": "¹H NMR (400 MHz, CDCl3) δ 3.65 (q, J = 7.1 Hz, 2H), 1.26 (t, J = 7.1 Hz, 3H), 2.10 (br s, 1H)",
                    "solvent": "CDCl3",
                }
            ]
        },
    )

    sample_id: str | None = Field(default=None, max_length=100)
    smiles: str = Field(min_length=1, max_length=500)
    nmr_text: str = Field(min_length=3, max_length=10_000)
    solvent: str | None = Field(default=None, max_length=50)

    @field_validator("sample_id", "solvent", mode="before")
    @classmethod
    def _optional_trim(cls, value: str | None) -> str | None:
        if value is None:
            return None
        value = str(value).strip()
        return value or None

    @field_validator("smiles", "nmr_text", mode="before")
    @classmethod
    def _required_trim(cls, value: str) -> str:
        value = str(value).strip()
        if not value:
            raise ValueError("This field cannot be empty.")
        return value


class AnalysisValidationInputs(BaseModel):
    model_config = ConfigDict(extra="forbid")

    sample_id: str | None = Field(default=None, max_length=100)
    smiles: str | None = Field(default=None, max_length=500)
    nmr_text: str | None = Field(default=None, max_length=10_000)
    solvent: str | None = Field(default=None, max_length=50)

    @field_validator("sample_id", "smiles", "nmr_text", "solvent", mode="before")
    @classmethod
    def _optional_trim(cls, value: str | None) -> str | None:
        if value is None:
            return None
        value = str(value).strip()
        return value or None


class AnalysisReport(BaseModel):
    model_config = ConfigDict(extra="forbid")

    label: DiagnosticLabel
    confidence: float = Field(ge=0.0, le=1.0)
    sample_id: str | None = None
    solvent: str | None = None
    expected_total_h: int
    expected_non_labile_h: int
    expected_labile_h: int
    observed_total_h: float
    rounded_observed_total_h: int
    delta_total_h: int
    parsed_peak_count: int
    notes: list[str]
    peaks: list[Peak]
    structure: StructureSummary
    solvent_signal_hits: list[SolventHeuristicHit] = Field(default_factory=list)
    pattern_alerts: list[str] = Field(default_factory=list)
    proton_evidence_score: float | None = Field(default=None, ge=0.0, le=1.0)
    proton_evidence: dict[str, Any] = Field(default_factory=dict)


class BatchAnalysisInputs(BaseModel):
    model_config = ConfigDict(extra="forbid")

    items: list[AnalysisInputs] = Field(min_length=1, max_length=100)


class BatchAnalysisReport(BaseModel):
    model_config = ConfigDict(extra="forbid")

    items: list[AnalysisReport]
    total_items: int


class ValidationReport(BaseModel):
    model_config = ConfigDict(extra="forbid")

    sample_id: str | None = None
    solvent: str | None = None
    structure_valid: bool
    nmr_text_valid: bool
    structure_nmr_match: bool = False
    analysis_ready: bool = False
    parseable_peak_count: int
    expected_visible_h: float | None = None
    observed_total_h: float | None = None
    adjusted_observed_total_h: float | None = None
    delta_visible_h: float | None = None
    parsed_peaks: list[Peak] = Field(default_factory=list)
    structure: StructureSummary | None = None
    warnings: list[str] = Field(default_factory=list)
    errors: list[str] = Field(default_factory=list)




class SpectrumPoint(BaseModel):
    model_config = ConfigDict(extra="forbid")

    shift_ppm: float = Field(ge=-50.0, le=260.0)
    intensity: float


class SpectrumPeakMatch(BaseModel):
    model_config = ConfigDict(extra="forbid")

    reference_peak: Peak
    extracted_peak: Peak
    reference_raw_text: str
    reference_shift_start_ppm: float | None = Field(default=None, ge=-5.0, le=20.0)
    reference_shift_end_ppm: float | None = Field(default=None, ge=-5.0, le=20.0)
    delta_ppm: float = Field(ge=0.0)
    status: Literal["matched", "shifted"]
    multiplicity_match: bool
    integration_match: bool


class SpectrumMissingReferencePeak(BaseModel):
    model_config = ConfigDict(extra="forbid")

    reference_peak: Peak
    reference_raw_text: str
    reference_shift_start_ppm: float | None = Field(default=None, ge=-5.0, le=20.0)
    reference_shift_end_ppm: float | None = Field(default=None, ge=-5.0, le=20.0)


class SpectrumExtraPeak(BaseModel):
    model_config = ConfigDict(extra="forbid")

    extracted_peak: Peak


class SpectrumComparisonReport(BaseModel):
    model_config = ConfigDict(extra="forbid")

    matched: list[SpectrumPeakMatch] = Field(default_factory=list)
    missing_reference: list[SpectrumMissingReferencePeak] = Field(default_factory=list)
    extra_spectrum: list[SpectrumExtraPeak] = Field(default_factory=list)
    matched_count: int = Field(ge=0, default=0)
    shifted_count: int = Field(ge=0, default=0)
    missing_count: int = Field(ge=0, default=0)
    extra_count: int = Field(ge=0, default=0)
    multiplicity_match_count: int = Field(ge=0, default=0)
    integration_match_count: int = Field(ge=0, default=0)
    total_shift_delta_ppm: float = Field(ge=0.0, default=0.0)
    reference_total_h: float = Field(ge=0.0, default=0.0)
    extracted_total_h: float = Field(ge=0.0, default=0.0)
    structure_visible_h: float | None = Field(default=None, ge=0.0)
    reference_structure_delta_h: float | None = None
    extracted_structure_delta_h: float | None = None
    reference_extracted_delta_h: float | None = None
    structure_reference_mismatch: bool = False
    structure_extracted_mismatch: bool = False
    notes: list[str] = Field(default_factory=list)


class SpectrumPreviewReport(BaseModel):
    model_config = ConfigDict(extra="forbid")

    filename: str
    format_detected: str
    source_mode: Literal["trace", "peak_table"]
    point_count: int = Field(ge=0)
    preview_points: list[SpectrumPoint] = Field(default_factory=list)
    inferred_peaks: list[Peak] = Field(default_factory=list)
    inferred_nmr_text: str = ""
    reference_nmr_text_normalized: str | None = None
    reference_peaks: list[Peak] = Field(default_factory=list)
    comparison: SpectrumComparisonReport | None = None
    warnings: list[str] = Field(default_factory=list)
    metadata: dict[str, Any] = Field(default_factory=dict)


class SpectrumAnalyzeResult(BaseModel):
    model_config = ConfigDict(extra="forbid")

    preview: SpectrumPreviewReport
    generated_inputs: AnalysisInputs
    analysis: AnalysisReport


class FIDProcessingSettings(BaseModel):
    model_config = ConfigDict(extra="forbid")

    selected_preset: FIDPresetId = "balanced"
    zero_fill_factor: int = Field(default=2, ge=1, le=8)
    fourier_transform: str = "fft_1d"
    apodization_mode: str = "exponential"
    line_broadening_hz: float = Field(default=0.3, ge=0.0, le=10.0)
    apply_group_delay: bool = True
    auto_phase: bool = True
    auto_baseline: bool = True
    phase_mode: str = "auto"
    phase_p0: float = 0.0
    phase_p1: float = 0.0
    baseline_correction: str = "bernstein"
    baseline_order: int = Field(default=3, ge=1, le=8)
    baseline_lock_visual_only: bool = True
    peak_sensitivity: float | None = Field(default=None, ge=0.02, le=0.45)
    mask_solvent_regions: bool = True
    max_preview_points: int = Field(default=700, ge=100, le=5000)
    display_mode: Literal["real", "magnifier"] = "real"
    vertical_gain: float = Field(default=1.0, ge=1.0, le=1_000_000.0)
    debug_preview: bool = False


class FIDProcessingRecipe(BaseModel):
    model_config = ConfigDict(extra="forbid")

    vendor: str = "unknown"
    nucleus: str = "1H"
    processing_preset: str = "balanced"
    digital_filter_correction: str = "auto"
    apodization_mode: str = "exponential"
    line_broadening_hz: float = Field(default=0.3, ge=0.0, le=10.0)
    zero_fill_factor: int = Field(default=2, ge=1, le=8)
    fourier_transform: str = "fft_1d"
    phase_mode: str = "auto"
    phase_p0: float = 0.0
    phase_p1: float = 0.0
    baseline_correction: str = "bernstein"
    baseline_order: int = Field(default=3, ge=1, le=8)
    reference_ppm: float | None = None
    solvent: str | None = None
    peak_sensitivity: float | None = Field(default=None, ge=0.02, le=0.45)
    mask_solvent_regions: bool = True
    display_mode: Literal["real", "magnifier"] = "real"
    vertical_gain: float = Field(default=1.0, ge=1.0, le=1_000_000.0)
    debug_preview: bool = False


class FIDProcessingPreset(BaseModel):
    model_config = ConfigDict(extra="forbid")

    id: FIDPresetId
    label: str
    description: str
    settings: dict[str, Any] = Field(default_factory=dict)


class FIDQADiagnostics(BaseModel):
    model_config = ConfigDict(extra="forbid")

    quality_score: float = Field(ge=0.0, le=1.0)
    quality_label: FIDQualityLabel
    dynamic_range: float = Field(ge=0.0)
    noise_estimate: float = Field(ge=0.0)
    baseline_offset_ratio: float = Field(ge=0.0)
    saturation_clipping_proxy: float = Field(ge=0.0, le=1.0)
    point_count: int = Field(ge=0)
    warnings: list[str] = Field(default_factory=list)


class FIDProcessingMetadata(BaseModel):
    model_config = ConfigDict(extra="forbid")

    vendor_format_detected: str
    dataset_folder: str
    selected_preset: str = "Balanced"
    nucleus: str = "1H"
    solvent: str | None = None
    reference_ppm: float | None = None
    reference_shift_applied_ppm: float = 0.0
    reference_peak_selection: dict[str, Any] = Field(default_factory=dict)
    group_delay_correction_applied: bool = False
    automatic_phase_correction: bool = False
    automatic_baseline_correction: bool = False
    zero_filling: dict[str, Any] = Field(default_factory=dict)
    line_broadening: dict[str, Any] = Field(default_factory=dict)
    phase_settings: dict[str, Any] = Field(default_factory=dict)
    baseline_correction: dict[str, Any] = Field(default_factory=dict)
    digital_filter_correction_status: str = "not_applied"
    qa_diagnostics: FIDQADiagnostics
    processing_parameters: dict[str, Any] = Field(default_factory=dict)
    processing_recipe: FIDProcessingRecipe = Field(default_factory=FIDProcessingRecipe)
    acquisition_parameters: dict[str, Any] = Field(default_factory=dict)
    raw_dataset_files_found: dict[str, bool] = Field(default_factory=dict)
    raw_upload_provenance: dict[str, Any] = Field(default_factory=dict)
    analysis_artifact_policy: dict[str, Any] = Field(default_factory=dict)
    nmrglue_used: bool = False
    pulseprogram_present: bool = False
    pdata_present: bool = False
    extracted_peak_list: list[Peak] = Field(default_factory=list)
    reviewer_signoff_required: bool = True
    human_review_status: str = "pending_review"
    warnings: list[str] = Field(default_factory=list)


class FIDPreviewReport(SpectrumPreviewReport):
    model_config = ConfigDict(extra="forbid")

    fid_run_id: int | None = None
    processing_metadata: FIDProcessingMetadata


class FIDProcessResult(BaseModel):
    model_config = ConfigDict(extra="forbid")

    preview: FIDPreviewReport
    generated_inputs: AnalysisInputs
    analysis: AnalysisReport


class FIDRunReviewCreate(BaseModel):
    model_config = ConfigDict(extra="forbid")

    action: ReviewAction | None = None
    comment: str | None = Field(default=None, max_length=4000)


class FIDRunReviewDecisionRecord(BaseModel):
    model_config = ConfigDict(extra="forbid")

    id: int
    run_id: int
    reviewer_user_id: int
    action: ReviewAction
    previous_status: ReviewStatus
    new_status: ReviewStatus
    comment: str | None = None
    created_at: datetime


class FIDRunRecord(BaseModel):
    model_config = ConfigDict(extra="forbid")

    id: int
    user_id: int | None = None
    analysis_id: int | None = None
    raw_archive_id: int | None = None
    raw_sha256: str | None = Field(default=None, min_length=64, max_length=64)
    created_at: datetime
    sample_id: str | None = None
    filename: str
    selected_preset: str
    quality_label: FIDQualityLabel
    quality_score: float = Field(ge=0.0, le=1.0)
    review_status: ReviewStatus = "pending_review"
    reviewer_user_id: int | None = None
    reviewed_at: datetime | None = None
    reviewer_comment: str | None = None
    preview: FIDPreviewReport
    processing_metadata: FIDProcessingMetadata
    processing_recipe: dict[str, Any] = Field(default_factory=dict)
    derived_spectrum_metadata: dict[str, Any] = Field(default_factory=dict)
    review_decision_count: int = 0


class FIDRunReport(BaseModel):
    model_config = ConfigDict(extra="forbid")

    run: FIDRunRecord
    raw_fid_provenance: dict[str, Any] = Field(default_factory=dict)
    processing_assumptions: dict[str, Any] = Field(default_factory=dict)
    qa_diagnostics: FIDQADiagnostics
    inferred_peak_list: list[Peak] = Field(default_factory=list)
    review_decisions: list[FIDRunReviewDecisionRecord] = Field(default_factory=list)


class Carbon13Peak(BaseModel):
    model_config = ConfigDict(extra="forbid")

    shift_ppm: float = Field(ge=-50.0, le=260.0)
    intensity: float | None = None
    assignment: str | None = Field(default=None, max_length=200)
    region: str | None = None
    carbon_type: str | None = None
    is_likely_solvent: bool = False
    is_likely_impurity: bool = False
    impurity_matches: list[dict[str, Any]] = Field(default_factory=list)
    notes: list[str] = Field(default_factory=list)


class Carbon13Inputs(BaseModel):
    model_config = ConfigDict(extra="forbid")

    smiles: str = Field(min_length=1, max_length=500)
    carbon13_text: str = Field(min_length=1, max_length=20_000)
    solvent: str | None = Field(default=None, max_length=50)
    sample_id: str | None = Field(default=None, max_length=100)

    @field_validator("smiles", "carbon13_text", mode="before")
    @classmethod
    def _required_trim(cls, value: str) -> str:
        value = str(value).strip()
        if not value:
            raise ValueError("This field cannot be empty.")
        return value

    @field_validator("solvent", "sample_id", mode="before")
    @classmethod
    def _optional_trim(cls, value: str | None) -> str | None:
        if value is None:
            return None
        value = str(value).strip()
        return value or None


class Carbon13UploadPreview(BaseModel):
    model_config = ConfigDict(extra="forbid")

    filename: str
    source_mode: str
    observed_signal_count: int
    peaks: list[Carbon13Peak] = Field(default_factory=list)
    warnings: list[str] = Field(default_factory=list)
    metadata: dict[str, Any] = Field(default_factory=dict)


class Carbon13RegionSummary(BaseModel):
    model_config = ConfigDict(extra="forbid")

    region: str
    count: int
    shifts_ppm: list[float] = Field(default_factory=list)


class Carbon13AnalysisReport(BaseModel):
    model_config = ConfigDict(extra="forbid")

    sample_id: str | None = None
    smiles: str
    solvent: str | None = None
    expected_carbon_atoms: int
    observed_carbon_signals: int
    delta_carbon_signals: int
    label: Literal[
        "carbon_count_consistent",
        "possible_overlap_or_missing_weak_carbons",
        "possible_extra_carbons_or_impurity",
        "invalid_input",
    ]
    confidence: float = Field(ge=0.0, le=1.0)
    peaks: list[Carbon13Peak] = Field(default_factory=list)
    region_summary: list[Carbon13RegionSummary] = Field(default_factory=list)
    solvent_warnings: list[str] = Field(default_factory=list)
    notes: list[str] = Field(default_factory=list)
    carbon13_match_score: float | None = None
    carbon_count_score: float | None = None
    region_consistency_score: float | None = None
    solvent_exclusion_score: float | None = None
    dept_apt_consistency_score: float | None = None
    expected_region_summary: dict[str, int] = Field(default_factory=dict)
    observed_region_summary: dict[str, int] = Field(default_factory=dict)
    evidence_summary: list[str] = Field(default_factory=list)
    structure: StructureSummary | None = None


DeptAptExperimentType = Literal["DEPT90", "DEPT135", "DEPT", "APT", "UNKNOWN"]
DeptAptCarbonType = Literal["C", "CH", "CH2", "CH3", "CH_OR_CH3", "CH2_OR_C"]
DeptAptPhase = Literal["positive", "negative", "unknown"]


class DeptAptPeak(BaseModel):
    model_config = ConfigDict(extra="forbid")

    experiment: DeptAptExperimentType = "UNKNOWN"
    shift_ppm: float = Field(ge=-50.0, le=260.0)
    intensity: float | None = None
    phase: DeptAptPhase = "unknown"
    carbon_type: DeptAptCarbonType | None = None
    assignment: str | None = Field(default=None, max_length=200)
    matched_carbon13_shift_ppm: float | None = None
    warnings: list[str] = Field(default_factory=list)


class DeptAptPreviewReport(BaseModel):
    model_config = ConfigDict(extra="forbid")

    filename: str
    experiment_detected: DeptAptExperimentType = "UNKNOWN"
    peak_count: int = 0
    peaks: list[DeptAptPeak] = Field(default_factory=list)
    warnings: list[str] = Field(default_factory=list)
    metadata: dict[str, Any] = Field(default_factory=dict)


class DeptAptAnalyzeResult(BaseModel):
    model_config = ConfigDict(extra="forbid")

    preview: DeptAptPreviewReport
    carbon13_peak_count: int = 0
    matched_carbon13_count: int = 0
    missing_carbon13_count: int = 0
    extra_dept_apt_count: int = 0
    typed_peak_count: int = 0
    dept_apt_consistency_score: float | None = Field(default=None, ge=0.0, le=1.0)
    type_summary: dict[str, int] = Field(default_factory=dict)
    notes: list[str] = Field(default_factory=list)
    warnings: list[str] = Field(default_factory=list)


class ProtonEvidencePeak(BaseModel):
    model_config = ConfigDict(extra="forbid")

    shift_ppm: float = Field(ge=-5.0, le=20.0)
    multiplicity: str
    integration_h: float
    region: str
    is_likely_solvent: bool = False
    is_likely_water: bool = False
    notes: list[str] = Field(default_factory=list)


class ProtonEvidenceReport(BaseModel):
    model_config = ConfigDict(extra="forbid")

    sample_id: str | None = None
    smiles: str
    solvent: str | None = None
    expected_total_h: int
    expected_non_labile_h: int
    expected_labile_h: int
    observed_total_h: float
    observed_non_solvent_h: float
    solvent_or_water_h: float
    delta_total_h: float
    delta_non_solvent_h: float
    label: DiagnosticLabel
    overall_score: float = Field(ge=0.0, le=1.0)
    integration_score: float = Field(ge=0.0, le=1.0)
    solvent_exclusion_score: float = Field(ge=0.0, le=1.0)
    region_support_score: float = Field(ge=0.0, le=1.0)
    peaks: list[ProtonEvidencePeak] = Field(default_factory=list)
    notes: list[str] = Field(default_factory=list)
    warnings: list[str] = Field(default_factory=list)
    structure: StructureSummary | None = None


class SpectralEvidenceScore(BaseModel):
    model_config = ConfigDict(extra="forbid")

    nucleus: str
    score: float = Field(ge=0.0, le=1.0)
    matched_count: int = 0
    unmatched_observed_count: int = 0
    unmatched_expected_count: int = 0
    notes: list[str] = Field(default_factory=list)


class CandidateInput(BaseModel):
    model_config = ConfigDict(extra="forbid")

    name: str | None = Field(default=None, max_length=200)
    smiles: str = Field(min_length=1, max_length=1000)
    role: str | None = Field(default=None, max_length=100)

    @field_validator("smiles", mode="before")
    @classmethod
    def _trim_smiles(cls, value: str) -> str:
        value = str(value).strip()
        if not value:
            raise ValueError("Candidate SMILES cannot be empty.")
        return value

    @field_validator("name", "role", mode="before")
    @classmethod
    def _optional_trim_candidate(cls, value: str | None) -> str | None:
        if value is None:
            return None
        value = str(value).strip()
        return value or None


class CandidateComparisonRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")

    sample_id: str | None = Field(default=None, max_length=100)
    solvent: str | None = Field(default=None, max_length=50)
    proton_nmr_text: str | None = Field(default=None, max_length=20_000)
    carbon13_text: str | None = Field(default=None, max_length=20_000)
    candidates: list[CandidateInput] = Field(min_length=1, max_length=25)

    @field_validator("sample_id", "solvent", "proton_nmr_text", "carbon13_text", mode="before")
    @classmethod
    def _optional_trim_evidence(cls, value: str | None) -> str | None:
        if value is None:
            return None
        value = str(value).strip()
        return value or None


class CandidateScoreBreakdown(BaseModel):
    model_config = ConfigDict(extra="forbid")

    structure_validity_score: float = Field(ge=0.0, le=1.0)
    proton_score: float | None = Field(default=None, ge=0.0, le=1.0)
    carbon13_score: float | None = Field(default=None, ge=0.0, le=1.0)
    dept_apt_score: float | None = Field(default=None, ge=0.0, le=1.0)
    nmr2d_score: float | None = Field(default=None, ge=0.0, le=1.0)
    formula_match_score: float | None = Field(default=None, ge=0.0, le=1.0)


class CandidateComparisonItem(BaseModel):
    model_config = ConfigDict(extra="forbid")

    rank: int
    name: str | None = None
    role: str | None = None
    smiles: str
    label: Literal["best_supported", "supported", "ambiguous", "weak_support", "invalid_structure"]
    total_score: float = Field(ge=0.0, le=1.0)
    score_breakdown: CandidateScoreBreakdown
    formula: str | None = None
    exact_mass: float | None = None
    proton_label: str | None = None
    carbon13_label: str | None = None
    evidence_summary: list[str] = Field(default_factory=list)
    contradictions: list[str] = Field(default_factory=list)
    warnings: list[str] = Field(default_factory=list)
    metadata: dict[str, Any] = Field(default_factory=dict)


class CandidateComparisonResult(BaseModel):
    model_config = ConfigDict(extra="forbid")

    sample_id: str | None = None
    solvent: str | None = None
    candidate_count: int
    best_candidate: CandidateComparisonItem | None = None
    ranked_candidates: list[CandidateComparisonItem] = Field(default_factory=list)
    ambiguity_alerts: list[str] = Field(default_factory=list)
    evidence_layers_used: list[str] = Field(default_factory=list)
    notes: list[str] = Field(default_factory=list)
    warnings: list[str] = Field(default_factory=list)


class SpectralSimilarityMatch(BaseModel):
    model_config = ConfigDict(extra="forbid")

    observed_ppm: float
    reference_ppm: float
    delta_ppm: float
    score: float = Field(ge=0.0, le=1.0)


class NMR2DCrossPeakMatch(BaseModel):
    model_config = ConfigDict(extra="forbid")

    observed_f2_ppm: float
    observed_f1_ppm: float
    reference_f2_ppm: float
    reference_f1_ppm: float
    delta_f2_ppm: float
    delta_f1_ppm: float
    score: float = Field(ge=0.0, le=1.0)


class SpectralSimilarityLayerResult(BaseModel):
    model_config = ConfigDict(extra="forbid")

    layer: Literal["1H", "13C", "COSY", "HSQC", "HMQC", "HMBC", "2D"]
    vector_score: float | None = Field(default=None, ge=0.0, le=1.0)
    set_score: float | None = Field(default=None, ge=0.0, le=1.0)
    combined_score: float = Field(ge=0.0, le=1.0)
    observed_count: int = 0
    reference_count: int = 0
    matched_count: int = 0
    unmatched_observed_count: int = 0
    unmatched_reference_count: int = 0
    matches: list[SpectralSimilarityMatch] = Field(default_factory=list)
    crosspeak_matches: list[NMR2DCrossPeakMatch] = Field(default_factory=list)
    notes: list[str] = Field(default_factory=list)
    warnings: list[str] = Field(default_factory=list)
    metadata: dict[str, Any] = Field(default_factory=dict)


class SpectralSimilarityRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")

    sample_id: str | None = Field(default=None, max_length=100)
    solvent: str | None = Field(default=None, max_length=50)
    observed_proton_text: str | None = Field(default=None, max_length=20_000)
    reference_proton_text: str | None = Field(default=None, max_length=20_000)
    observed_carbon13_text: str | None = Field(default=None, max_length=20_000)
    reference_carbon13_text: str | None = Field(default=None, max_length=20_000)

    @field_validator(
        "sample_id",
        "solvent",
        "observed_proton_text",
        "reference_proton_text",
        "observed_carbon13_text",
        "reference_carbon13_text",
        mode="before",
    )
    @classmethod
    def _optional_trim_similarity(cls, value: str | None) -> str | None:
        if value is None:
            return None
        value = str(value).strip()
        return value or None


class SpectralSimilarityResult(BaseModel):
    model_config = ConfigDict(extra="forbid")

    sample_id: str | None = None
    solvent: str | None = None
    overall_score: float = Field(ge=0.0, le=1.0)
    label: Literal["high_similarity", "moderate_similarity", "low_similarity", "insufficient_evidence"]
    layers: list[SpectralSimilarityLayerResult] = Field(default_factory=list)
    evidence_layers_used: list[str] = Field(default_factory=list)
    notes: list[str] = Field(default_factory=list)
    warnings: list[str] = Field(default_factory=list)
    metadata: dict[str, Any] = Field(default_factory=dict)


class PredictedNMRPeak(BaseModel):
    model_config = ConfigDict(extra="forbid")

    nucleus: Literal["1H", "13C"]
    shift_ppm: float
    uncertainty_ppm: float = Field(ge=0.0)
    atom_index: int | None = None
    attached_h: int | None = Field(default=None, ge=0)
    integration_h: float | None = Field(default=None, ge=0.0)
    carbon_type: str | None = None
    multiplicity_hint: str | None = None
    environment: str | None = None
    source: Literal["heuristic_rdkit", "external", "ml_placeholder"] = "heuristic_rdkit"
    warnings: list[str] = Field(default_factory=list)


class PredictedNMRReport(BaseModel):
    model_config = ConfigDict(extra="forbid")

    name: str | None = None
    smiles: str
    formula: str | None = None
    molecular_weight: float | None = None
    prediction_method: str
    confidence_label: Literal["high", "medium", "low", "invalid_structure"]
    proton_peaks: list[PredictedNMRPeak] = Field(default_factory=list)
    carbon13_peaks: list[PredictedNMRPeak] = Field(default_factory=list)
    predicted_hsqc_crosspeaks: list[dict[str, Any]] = Field(default_factory=list)
    warnings: list[str] = Field(default_factory=list)
    notes: list[str] = Field(default_factory=list)
    metadata: dict[str, Any] = Field(default_factory=dict)


class CandidatePredictedNMRMatchRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")

    sample_id: str | None = Field(default=None, max_length=100)
    solvent: str | None = Field(default=None, max_length=50)
    observed_proton_text: str | None = Field(default=None, max_length=20_000)
    observed_carbon13_text: str | None = Field(default=None, max_length=20_000)
    candidates: list[CandidateInput] = Field(min_length=1, max_length=25)

    @field_validator("sample_id", "solvent", "observed_proton_text", "observed_carbon13_text", mode="before")
    @classmethod
    def _optional_trim_predicted_match(cls, value: str | None) -> str | None:
        if value is None:
            return None
        value = str(value).strip()
        return value or None


class CandidatePredictedNMRMatchItem(BaseModel):
    model_config = ConfigDict(extra="forbid")

    rank: int
    name: str | None = None
    role: str | None = None
    smiles: str
    label: Literal["best_predicted_match", "predicted_match", "ambiguous", "weak_match", "invalid_structure"]
    total_score: float = Field(ge=0.0, le=1.0)
    prediction: PredictedNMRReport | None = None
    proton_similarity: SpectralSimilarityLayerResult | None = None
    carbon13_similarity: SpectralSimilarityLayerResult | None = None
    nmr2d_similarity: SpectralSimilarityLayerResult | None = None
    evidence_summary: list[str] = Field(default_factory=list)
    contradictions: list[str] = Field(default_factory=list)
    warnings: list[str] = Field(default_factory=list)
    metadata: dict[str, Any] = Field(default_factory=dict)


class CandidatePredictedNMRMatchResult(BaseModel):
    model_config = ConfigDict(extra="forbid")

    sample_id: str | None = None
    solvent: str | None = None
    candidate_count: int
    best_candidate: CandidatePredictedNMRMatchItem | None = None
    ranked_candidates: list[CandidatePredictedNMRMatchItem] = Field(default_factory=list)
    ambiguity_alerts: list[str] = Field(default_factory=list)
    evidence_layers_used: list[str] = Field(default_factory=list)
    notes: list[str] = Field(default_factory=list)
    warnings: list[str] = Field(default_factory=list)
    metadata: dict[str, Any] = Field(default_factory=dict)


MassIonMode = Literal["positive", "negative", "neutral"]
HRMSMatchLabel = Literal["exact_mass_match", "possible_match", "outside_tolerance", "invalid_structure"]


class HRMSAdductInfo(BaseModel):
    model_config = ConfigDict(extra="forbid")

    name: str
    ion_mode: MassIonMode
    charge: int
    mass_shift: float
    description: str


class HRMSFormulaInfo(BaseModel):
    model_config = ConfigDict(extra="forbid")

    formula: str
    exact_mass: float
    dbe: float | None = None
    element_counts: dict[str, int] = Field(default_factory=dict)
    isotope_m_plus_1_percent: float | None = None
    isotope_m_plus_2_percent: float | None = None


class HRMSCandidateMatch(BaseModel):
    model_config = ConfigDict(extra="forbid")

    rank: int
    name: str | None = None
    role: str | None = None
    smiles: str
    label: HRMSMatchLabel
    formula: str | None = None
    neutral_exact_mass: float | None = None
    theoretical_mz: float | None = None
    observed_mz: float
    ppm_error: float | None = None
    abs_mass_error_da: float | None = None
    ppm_score: float = Field(ge=0.0, le=1.0)
    isotope_score: float | None = Field(default=None, ge=0.0, le=1.0)
    dbe: float | None = None
    evidence_summary: list[str] = Field(default_factory=list)
    warnings: list[str] = Field(default_factory=list)
    metadata: dict[str, Any] = Field(default_factory=dict)


class HRMSCandidateMatchRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")

    sample_id: str | None = Field(default=None, max_length=100)
    observed_mz: float = Field(gt=0.0)
    adduct: str = Field(default="[M+H]+", max_length=50)
    ion_mode: MassIonMode | None = None
    ppm_tolerance: float = Field(default=5.0, gt=0.0, le=100.0)
    observed_m_plus_1_percent: float | None = Field(default=None, ge=0.0)
    observed_m_plus_2_percent: float | None = Field(default=None, ge=0.0)
    candidates: list[CandidateInput] = Field(min_length=1, max_length=50)

    @field_validator("sample_id", "adduct", mode="before")
    @classmethod
    def _optional_trim_hrms_candidate(cls, value: str | None) -> str | None:
        if value is None:
            return None
        value = str(value).strip()
        return value or None


class HRMSCandidateMatchResult(BaseModel):
    model_config = ConfigDict(extra="forbid")

    sample_id: str | None = None
    observed_mz: float
    adduct: HRMSAdductInfo
    ppm_tolerance: float
    candidate_count: int
    best_match: HRMSCandidateMatch | None = None
    ranked_candidates: list[HRMSCandidateMatch] = Field(default_factory=list)
    exact_match_count: int = 0
    possible_match_count: int = 0
    warnings: list[str] = Field(default_factory=list)
    notes: list[str] = Field(default_factory=list)
    metadata: dict[str, Any] = Field(default_factory=dict)


class HRMSFormulaSearchRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")

    observed_mz: float = Field(gt=0.0)
    adduct: str = Field(default="[M+H]+", max_length=50)
    ppm_tolerance: float = Field(default=5.0, gt=0.0, le=100.0)
    max_c: int = Field(default=40, ge=0, le=120)
    max_h: int = Field(default=100, ge=0, le=250)
    max_n: int = Field(default=6, ge=0, le=20)
    max_o: int = Field(default=12, ge=0, le=40)
    max_s: int = Field(default=4, ge=0, le=12)
    max_p: int = Field(default=2, ge=0, le=8)
    max_cl: int = Field(default=4, ge=0, le=10)
    max_br: int = Field(default=3, ge=0, le=8)
    require_nonnegative_dbe: bool = True
    max_results: int = Field(default=50, ge=1, le=500)


class HRMSFormulaSearchResult(BaseModel):
    model_config = ConfigDict(extra="forbid")

    observed_mz: float
    neutral_mass: float
    adduct: HRMSAdductInfo
    ppm_tolerance: float
    formula_count: int
    formulas: list[HRMSFormulaInfo] = Field(default_factory=list)
    warnings: list[str] = Field(default_factory=list)
    metadata: dict[str, Any] = Field(default_factory=dict)


MSMSCandidateLabel = Literal["consistent_with_msms", "partial_msms_support", "weak_or_no_msms_support", "invalid_structure"]


class MSMSPeak(BaseModel):
    model_config = ConfigDict(extra="forbid")

    mz: float = Field(gt=0.0)
    intensity: float = Field(ge=0.0)
    relative_intensity: float | None = Field(default=None, ge=0.0, le=100.0)


class MSMSNeutralLossHit(BaseModel):
    model_config = ConfigDict(extra="forbid")

    fragment_mz: float
    intensity: float
    relative_intensity: float
    loss_name: str
    observed_loss_da: float
    expected_loss_da: float
    error_da: float
    ppm_error: float | None = None
    chemically_plausible: bool = True
    interpretation: str
    metadata: dict[str, Any] = Field(default_factory=dict)


class MSMSFragmentMatch(BaseModel):
    model_config = ConfigDict(extra="forbid")

    peak_mz: float
    intensity: float
    relative_intensity: float
    theoretical_mz: float
    ppm_error: float
    formula: str | None = None
    fragment_type: str
    explanation: str
    metadata: dict[str, Any] = Field(default_factory=dict)


class MSMSCandidateAnnotation(BaseModel):
    model_config = ConfigDict(extra="forbid")

    rank: int
    name: str | None = None
    role: str | None = None
    smiles: str
    label: MSMSCandidateLabel
    formula: str | None = None
    precursor_theoretical_mz: float | None = None
    precursor_ppm_error: float | None = None
    precursor_score: float = Field(ge=0.0, le=1.0)
    fragment_match_count: int = 0
    neutral_loss_count: int = 0
    explained_peak_count: int = 0
    explained_intensity_fraction: float = Field(default=0.0, ge=0.0, le=1.0)
    candidate_score: float = Field(default=0.0, ge=0.0, le=1.0)
    fragment_matches: list[MSMSFragmentMatch] = Field(default_factory=list)
    neutral_loss_hits: list[MSMSNeutralLossHit] = Field(default_factory=list)
    evidence_summary: list[str] = Field(default_factory=list)
    warnings: list[str] = Field(default_factory=list)
    metadata: dict[str, Any] = Field(default_factory=dict)


class MSMSAnnotationRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")

    sample_id: str | None = Field(default=None, max_length=100)
    precursor_mz: float = Field(gt=0.0)
    adduct: str = Field(default="[M+H]+", max_length=50)
    ion_mode: MassIonMode | None = None
    mz_tolerance_da: float = Field(default=0.02, gt=0.0, le=2.0)
    ppm_tolerance: float = Field(default=20.0, gt=0.0, le=500.0)
    min_relative_intensity: float = Field(default=1.0, ge=0.0, le=100.0)
    max_peaks_to_annotate: int = Field(default=50, ge=1, le=250)
    peaks: list[MSMSPeak] | None = Field(default=None, max_length=1000)
    peak_list_text: str | None = Field(default=None, max_length=100_000)
    candidates: list[CandidateInput] = Field(default_factory=list, max_length=50)

    @field_validator("sample_id", "adduct", "peak_list_text", mode="before")
    @classmethod
    def _optional_trim_msms(cls, value: str | None) -> str | None:
        if value is None:
            return None
        value = str(value).strip()
        return value or None


class MSMSAnnotationResult(BaseModel):
    model_config = ConfigDict(extra="forbid")

    sample_id: str | None = None
    precursor_mz: float
    adduct: HRMSAdductInfo
    mz_tolerance_da: float
    ppm_tolerance: float
    peak_count: int
    annotated_peak_count: int
    candidate_count: int
    best_candidate: MSMSCandidateAnnotation | None = None
    ranked_candidates: list[MSMSCandidateAnnotation] = Field(default_factory=list)
    neutral_loss_hits: list[MSMSNeutralLossHit] = Field(default_factory=list)
    warnings: list[str] = Field(default_factory=list)
    notes: list[str] = Field(default_factory=list)
    metadata: dict[str, Any] = Field(default_factory=dict)


MSMSFragmentationTreeLabel = Literal[
    "strong_fragmentation_tree_support",
    "plausible_fragmentation_tree_support",
    "weak_fragmentation_tree_support",
    "contradictory_fragmentation_tree",
    "invalid_structure",
]
MSMSFragmentationNodeType = Literal["precursor", "observed_peak", "hypothesized_fragment"]
MSMSFragmentationEdgeType = Literal["neutral_loss", "candidate_fragment_match", "series_loss", "precursor_match"]


class MSMSFragmentationTreeNode(BaseModel):
    model_config = ConfigDict(extra="forbid")

    node_id: str
    mz: float
    intensity: float | None = None
    relative_intensity: float | None = Field(default=None, ge=0.0, le=100.0)
    formula: str | None = None
    node_type: MSMSFragmentationNodeType
    annotation: str | None = None
    explained: bool = False
    evidence_summary: list[str] = Field(default_factory=list)
    warnings: list[str] = Field(default_factory=list)
    metadata: dict[str, Any] = Field(default_factory=dict)


class MSMSFragmentationTreeEdge(BaseModel):
    model_config = ConfigDict(extra="forbid")

    parent_id: str
    child_id: str
    relation_type: MSMSFragmentationEdgeType
    loss_name: str | None = None
    observed_loss_da: float | None = None
    expected_loss_da: float | None = None
    error_da: float | None = None
    ppm_error: float | None = None
    chemically_plausible: bool = True
    diagnostic: bool = False
    explanation: str
    metadata: dict[str, Any] = Field(default_factory=dict)


class MSMSDiagnosticLossEvidence(BaseModel):
    model_config = ConfigDict(extra="forbid")

    loss_name: str
    fragment_mz: float
    observed_loss_da: float
    expected_loss_da: float
    relative_intensity: float
    chemically_plausible: bool
    diagnostic_class: str
    interpretation: str


class MSMSFragmentationTreeCandidate(BaseModel):
    model_config = ConfigDict(extra="forbid")

    rank: int
    name: str | None = None
    role: str | None = None
    smiles: str
    label: MSMSFragmentationTreeLabel
    formula: str | None = None
    precursor_theoretical_mz: float | None = None
    precursor_ppm_error: float | None = None
    precursor_score: float = Field(default=0.0, ge=0.0, le=1.0)
    tree_score: float = Field(default=0.0, ge=0.0, le=1.0)
    explained_peak_count: int = 0
    explained_intensity_fraction: float = Field(default=0.0, ge=0.0, le=1.0)
    diagnostic_loss_count: int = 0
    contradiction_count: int = 0
    max_tree_depth: int = 0
    nodes: list[MSMSFragmentationTreeNode] = Field(default_factory=list)
    edges: list[MSMSFragmentationTreeEdge] = Field(default_factory=list)
    diagnostic_hits: list[MSMSDiagnosticLossEvidence] = Field(default_factory=list)
    contradiction_flags: list[str] = Field(default_factory=list)
    evidence_summary: list[str] = Field(default_factory=list)
    warnings: list[str] = Field(default_factory=list)
    metadata: dict[str, Any] = Field(default_factory=dict)


class MSMSFragmentationTreeRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")

    sample_id: str | None = Field(default=None, max_length=100)
    precursor_mz: float = Field(gt=0.0)
    adduct: str = Field(default="[M+H]+", max_length=50)
    ion_mode: MassIonMode | None = None
    mz_tolerance_da: float = Field(default=0.02, gt=0.0, le=2.0)
    ppm_tolerance: float = Field(default=20.0, gt=0.0, le=500.0)
    min_relative_intensity: float = Field(default=1.0, ge=0.0, le=100.0)
    max_peaks_to_analyze: int = Field(default=75, ge=1, le=500)
    max_tree_depth: int = Field(default=3, ge=1, le=8)
    peaks: list[MSMSPeak] | None = Field(default=None, max_length=2000)
    peak_list_text: str | None = Field(default=None, max_length=100_000)
    candidates: list[CandidateInput] = Field(default_factory=list, max_length=50)

    @field_validator("sample_id", "adduct", "peak_list_text", mode="before")
    @classmethod
    def _optional_trim_fragmentation_tree(cls, value: str | None) -> str | None:
        if value is None:
            return None
        value = str(value).strip()
        return value or None


class MSMSFragmentationTreeResult(BaseModel):
    model_config = ConfigDict(extra="forbid")

    sample_id: str | None = None
    precursor_mz: float
    adduct: HRMSAdductInfo
    mz_tolerance_da: float
    ppm_tolerance: float
    peak_count: int
    analyzed_peak_count: int
    candidate_count: int
    best_candidate: MSMSFragmentationTreeCandidate | None = None
    ranked_candidates: list[MSMSFragmentationTreeCandidate] = Field(default_factory=list)
    global_neutral_loss_hits: list[MSMSNeutralLossHit] = Field(default_factory=list)
    warnings: list[str] = Field(default_factory=list)
    notes: list[str] = Field(default_factory=list)
    metadata: dict[str, Any] = Field(default_factory=dict)


MS1IsotopeClusterLabel = Literal["clear_isotope_cluster", "possible_isotope_cluster", "single_peak_only"]
MS1HalogenSignature = Literal[
    "none_detected",
    "chlorine_like",
    "bromine_like",
    "mixed_or_high_m_plus_2",
    "sulfur_or_silicon_possible",
    "unknown",
]
MS1AdductInferenceLabel = Literal["strong_adduct_evidence", "plausible_adduct", "weak_adduct_evidence", "incompatible_adduct"]


class MS1Peak(BaseModel):
    model_config = ConfigDict(extra="forbid")

    mz: float = Field(gt=0.0)
    intensity: float = Field(ge=0.0)
    relative_intensity: float | None = Field(default=None, ge=0.0, le=100.0)


class MS1IsotopeClusterPeak(BaseModel):
    model_config = ConfigDict(extra="forbid")

    isotope_label: Literal["M", "M+1", "M+2", "M+3"]
    mz: float
    expected_mz: float
    delta_da: float
    relative_intensity: float = Field(ge=0.0, le=100.0)
    ppm_error: float | None = None
    spacing_from_m0_da: float | None = None


class MS1IsotopeCluster(BaseModel):
    model_config = ConfigDict(extra="forbid")

    monoisotopic_mz: float
    charge: int = Field(ge=1, le=5)
    label: MS1IsotopeClusterLabel
    confidence_score: float = Field(ge=0.0, le=1.0)
    m_plus_1_percent: float | None = Field(default=None, ge=0.0)
    m_plus_2_percent: float | None = Field(default=None, ge=0.0)
    estimated_carbon_count: float | None = Field(default=None, ge=0.0)
    halogen_signature: MS1HalogenSignature = "unknown"
    peaks: list[MS1IsotopeClusterPeak] = Field(default_factory=list)
    evidence_summary: list[str] = Field(default_factory=list)
    warnings: list[str] = Field(default_factory=list)
    metadata: dict[str, Any] = Field(default_factory=dict)


class MS1AdductPeakEvidence(BaseModel):
    model_config = ConfigDict(extra="forbid")

    adduct: str
    observed_mz: float
    expected_mz: float
    ppm_error: float
    relative_intensity: float = Field(ge=0.0, le=100.0)


class MS1AdductInferenceCandidate(BaseModel):
    model_config = ConfigDict(extra="forbid")

    rank: int
    label: MS1AdductInferenceLabel
    adduct: HRMSAdductInfo
    observed_mz: float
    neutral_mass: float
    formula_count: int = 0
    top_formulas: list[HRMSFormulaInfo] = Field(default_factory=list)
    isotope_score: float | None = Field(default=None, ge=0.0, le=1.0)
    adduct_pair_count: int = 0
    adduct_peak_matches: list[MS1AdductPeakEvidence] = Field(default_factory=list)
    candidate_score: float = Field(ge=0.0, le=1.0)
    evidence_summary: list[str] = Field(default_factory=list)
    warnings: list[str] = Field(default_factory=list)
    metadata: dict[str, Any] = Field(default_factory=dict)


class MS1AdductInferenceRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")

    sample_id: str | None = Field(default=None, max_length=100)
    peak_list_text: str | None = Field(default=None, max_length=100_000)
    peaks: list[MS1Peak] | None = Field(default=None, max_length=5000)
    ion_mode: MassIonMode | None = "positive"
    target_mz: float | None = Field(default=None, gt=0.0)
    mz_tolerance_da: float = Field(default=0.02, gt=0.0, le=2.0)
    ppm_tolerance: float = Field(default=10.0, gt=0.0, le=500.0)
    isotope_mz_tolerance_da: float = Field(default=0.02, gt=0.0, le=1.0)
    min_relative_intensity: float = Field(default=0.2, ge=0.0, le=100.0)
    max_peaks_to_analyze: int = Field(default=200, ge=1, le=5000)
    max_charge: int = Field(default=3, ge=1, le=5)
    max_clusters: int = Field(default=20, ge=1, le=100)
    perform_formula_search: bool = True
    formula_candidates_per_adduct: int = Field(default=5, ge=1, le=50)
    max_c: int = Field(default=20, ge=0, le=120)
    max_h: int = Field(default=60, ge=0, le=250)
    max_n: int = Field(default=4, ge=0, le=20)
    max_o: int = Field(default=8, ge=0, le=40)
    max_s: int = Field(default=2, ge=0, le=12)
    max_p: int = Field(default=1, ge=0, le=8)
    max_cl: int = Field(default=2, ge=0, le=10)
    max_br: int = Field(default=1, ge=0, le=8)
    require_nonnegative_dbe: bool = True

    @field_validator("sample_id", "peak_list_text", mode="before")
    @classmethod
    def _optional_trim_ms1_adduct(cls, value: str | None) -> str | None:
        if value is None:
            return None
        value = str(value).strip()
        return value or None


class MS1AdductInferenceResult(BaseModel):
    model_config = ConfigDict(extra="forbid")

    sample_id: str | None = None
    ion_mode: MassIonMode | str
    peak_count: int
    analyzed_peak_count: int
    primary_mz: float
    inferred_charge: int | None = None
    inferred_m_plus_1_percent: float | None = None
    inferred_m_plus_2_percent: float | None = None
    isotope_clusters: list[MS1IsotopeCluster] = Field(default_factory=list)
    best_adduct_candidate: MS1AdductInferenceCandidate | None = None
    adduct_candidates: list[MS1AdductInferenceCandidate] = Field(default_factory=list)
    warnings: list[str] = Field(default_factory=list)
    notes: list[str] = Field(default_factory=list)
    metadata: dict[str, Any] = Field(default_factory=dict)


UnifiedConfidenceLabel = Literal[
    "high_confidence_candidate",
    "moderate_confidence_candidate",
    "low_confidence_candidate",
    "conflicting_evidence",
    "insufficient_evidence",
    "invalid_structure",
]
UnifiedConfidenceBand = Literal["high", "medium", "low", "conflicting", "insufficient"]
UnifiedEvidenceLayerName = Literal[
    "predicted_nmr",
    "hrms_exact_mass",
    "adduct_isotope",
    "msms_annotation",
    "fragmentation_tree",
]


class UnifiedEvidenceLayerScore(BaseModel):
    model_config = ConfigDict(extra="forbid")

    layer: UnifiedEvidenceLayerName
    label: str
    used: bool = False
    score: float | None = Field(default=None, ge=0.0, le=1.0)
    weight: float = Field(default=0.0, ge=0.0)
    status: str
    agreement: bool = False
    contradiction: bool = False
    evidence_count: int = 0
    evidence_summary: list[str] = Field(default_factory=list)
    warnings: list[str] = Field(default_factory=list)
    metadata: dict[str, Any] = Field(default_factory=dict)


class UnifiedCandidateConfidenceRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")

    sample_id: str | None = Field(default=None, max_length=100)
    solvent: str | None = Field(default=None, max_length=50)
    candidates: list[CandidateInput] = Field(min_length=1, max_length=25)

    observed_proton_text: str | None = Field(default=None, max_length=50_000)
    observed_carbon13_text: str | None = Field(default=None, max_length=50_000)
    observed_nmr2d_text: str | None = Field(default=None, max_length=100_000)
    observed_nmr2d_experiment_type: NMR2DExperimentType | None = None

    hrms_observed_mz: float | None = Field(default=None, gt=0.0)
    hrms_adduct: str | None = Field(default=None, max_length=50)
    ion_mode: MassIonMode | None = None
    hrms_ppm_tolerance: float = Field(default=5.0, gt=0.0, le=100.0)
    observed_m_plus_1_percent: float | None = Field(default=None, ge=0.0)
    observed_m_plus_2_percent: float | None = Field(default=None, ge=0.0)

    ms1_peak_list_text: str | None = Field(default=None, max_length=100_000)
    ms1_peaks: list[MS1Peak] | None = Field(default=None, max_length=5000)
    use_inferred_adduct: bool = True
    adduct_ppm_tolerance: float = Field(default=10.0, gt=0.0, le=500.0)
    isotope_mz_tolerance_da: float = Field(default=0.02, gt=0.0, le=1.0)
    ms1_min_relative_intensity: float = Field(default=0.2, ge=0.0, le=100.0)
    ms1_max_peaks_to_analyze: int = Field(default=200, ge=1, le=5000)
    max_charge: int = Field(default=3, ge=1, le=5)
    perform_adduct_formula_search: bool = True
    formula_candidates_per_adduct: int = Field(default=5, ge=1, le=50)
    formula_max_c: int = Field(default=20, ge=0, le=120)
    formula_max_h: int = Field(default=60, ge=0, le=250)
    formula_max_n: int = Field(default=4, ge=0, le=20)
    formula_max_o: int = Field(default=8, ge=0, le=40)
    formula_max_s: int = Field(default=2, ge=0, le=12)
    formula_max_p: int = Field(default=1, ge=0, le=8)
    formula_max_cl: int = Field(default=2, ge=0, le=10)
    formula_max_br: int = Field(default=1, ge=0, le=8)

    msms_peak_list_text: str | None = Field(default=None, max_length=100_000)
    msms_precursor_mz: float | None = Field(default=None, gt=0.0)
    msms_adduct: str | None = Field(default=None, max_length=50)
    mz_tolerance_da: float = Field(default=0.02, gt=0.0, le=2.0)
    msms_ppm_tolerance: float = Field(default=20.0, gt=0.0, le=500.0)
    msms_min_relative_intensity: float = Field(default=1.0, ge=0.0, le=100.0)
    msms_max_peaks_to_analyze: int = Field(default=75, ge=1, le=500)
    max_tree_depth: int = Field(default=3, ge=1, le=8)

    layer_weights: dict[str, float] = Field(default_factory=dict)
    ambiguity_delta_threshold: float = Field(default=0.05, ge=0.0, le=1.0)

    @field_validator(
        "sample_id",
        "solvent",
        "observed_proton_text",
        "observed_carbon13_text",
        "observed_nmr2d_text",
        "hrms_adduct",
        "msms_adduct",
        "ms1_peak_list_text",
        "msms_peak_list_text",
        mode="before",
    )
    @classmethod
    def _optional_trim_unified_confidence(cls, value: str | None) -> str | None:
        if value is None:
            return None
        value = str(value).strip()
        return value or None


class UnifiedCandidateConfidenceItem(BaseModel):
    model_config = ConfigDict(extra="forbid")

    rank: int
    name: str | None = None
    role: str | None = None
    smiles: str
    formula: str | None = None
    exact_mass: float | None = None
    label: UnifiedConfidenceLabel
    confidence_band: UnifiedConfidenceBand
    confidence_score: float = Field(ge=0.0, le=1.0)
    raw_weighted_score: float = Field(ge=0.0, le=1.0)
    evidence_completeness: float = Field(ge=0.0, le=1.0)
    agreement_count: int = 0
    contradiction_count: int = 0
    missing_layers: list[str] = Field(default_factory=list)
    layers: list[UnifiedEvidenceLayerScore] = Field(default_factory=list)
    layer_scores: dict[str, float | None] = Field(default_factory=dict)
    evidence_summary: list[str] = Field(default_factory=list)
    contradictions: list[str] = Field(default_factory=list)
    warnings: list[str] = Field(default_factory=list)
    metadata: dict[str, Any] = Field(default_factory=dict)


class UnifiedCandidateConfidenceResult(BaseModel):
    model_config = ConfigDict(extra="forbid")

    sample_id: str | None = None
    solvent: str | None = None
    selected_adduct: str
    candidate_count: int
    best_candidate: UnifiedCandidateConfidenceItem | None = None
    ranked_candidates: list[UnifiedCandidateConfidenceItem] = Field(default_factory=list)
    evidence_layers_used: list[str] = Field(default_factory=list)
    global_contradictions: list[str] = Field(default_factory=list)
    ambiguity_alerts: list[str] = Field(default_factory=list)
    notes: list[str] = Field(default_factory=list)
    warnings: list[str] = Field(default_factory=list)
    component_metadata: dict[str, Any] = Field(default_factory=dict)


class EvidenceReportSection(BaseModel):
    model_config = ConfigDict(extra="forbid")

    title: str
    items: list[str] = Field(default_factory=list)


StructureElucidationReportStatus = Literal[
    "draft_requires_review",
    "review_ready",
    "approved_for_release",
    "blocked_by_contradictions",
    "insufficient_evidence",
]
StructureElucidationReleaseGate = Literal[
    "requires_human_review",
    "approved_for_release",
    "blocked_by_contradictions",
    "insufficient_evidence",
]
StructureElucidationIntendedUse = Literal[
    "research_decision_support",
    "qc_batch_record",
    "regulatory_support",
    "training_or_education",
]


class StructureElucidationReportCandidateSummary(BaseModel):
    model_config = ConfigDict(extra="forbid")

    rank: int
    name: str | None = None
    role: str | None = None
    smiles: str
    formula: str | None = None
    exact_mass: float | None = None
    confidence_score: float = Field(ge=0.0, le=1.0)
    confidence_band: UnifiedConfidenceBand
    label: UnifiedConfidenceLabel
    evidence_completeness: float = Field(ge=0.0, le=1.0)
    agreement_count: int = 0
    contradiction_count: int = 0
    missing_layers: list[str] = Field(default_factory=list)
    evidence_summary: list[str] = Field(default_factory=list)
    contradictions: list[str] = Field(default_factory=list)
    warnings: list[str] = Field(default_factory=list)


class StructureElucidationReportRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")

    report_title: str = Field(default="Regulatory-ready Structure Elucidation Report", min_length=3, max_length=200)
    sample_id: str | None = Field(default=None, max_length=100)
    project_name: str | None = Field(default=None, max_length=200)
    prepared_by: str | None = Field(default=None, max_length=200)
    reviewer_name: str | None = Field(default=None, max_length=200)
    reviewer_comment: str | None = Field(default=None, max_length=4000)
    review_status: ReviewStatus | None = None
    intended_use: StructureElucidationIntendedUse = "research_decision_support"
    require_human_approval: bool = True
    requestor_notes: str | None = Field(default=None, max_length=8000)

    raw_data_sha256: str | None = Field(default=None, max_length=128)
    source_files: list[str] = Field(default_factory=list, max_length=50)
    processing_history: list[str] = Field(default_factory=list, max_length=100)

    unified_confidence_request: UnifiedCandidateConfidenceRequest | None = None
    unified_confidence_result: UnifiedCandidateConfidenceResult | None = None

    @field_validator(
        "sample_id",
        "project_name",
        "prepared_by",
        "reviewer_name",
        "reviewer_comment",
        "requestor_notes",
        "raw_data_sha256",
        mode="before",
    )
    @classmethod
    def _optional_trim_structure_report_fields(cls, value: str | None) -> str | None:
        if value is None:
            return None
        value = str(value).strip()
        return value or None

    @field_validator("source_files", "processing_history", mode="before")
    @classmethod
    def _trim_structure_report_lists(cls, value: list[str] | tuple[str, ...] | None) -> list[str]:
        if value is None:
            return []
        return [str(item).strip() for item in value if str(item).strip()]


class StructureElucidationReportResult(BaseModel):
    model_config = ConfigDict(extra="forbid")

    report_id: str
    generated_at: datetime
    report_title: str
    sample_id: str | None = None
    project_name: str | None = None
    prepared_by: str | None = None
    reviewer_name: str | None = None
    review_status: ReviewStatus | None = None
    reviewer_comment: str | None = None
    intended_use: StructureElucidationIntendedUse
    status: StructureElucidationReportStatus
    release_gate: StructureElucidationReleaseGate
    human_review_required: bool = True
    human_review_approved: bool = False

    best_candidate: StructureElucidationReportCandidateSummary | None = None
    ranked_candidates: list[StructureElucidationReportCandidateSummary] = Field(default_factory=list)
    selected_adduct: str | None = None
    evidence_layers_used: list[str] = Field(default_factory=list)
    evidence_completeness: float = Field(default=0.0, ge=0.0, le=1.0)
    agreement_count: int = 0
    contradiction_count: int = 0
    global_contradictions: list[str] = Field(default_factory=list)
    ambiguity_alerts: list[str] = Field(default_factory=list)
    warnings: list[str] = Field(default_factory=list)
    notes: list[str] = Field(default_factory=list)

    provenance: dict[str, Any] = Field(default_factory=dict)
    sections: list[EvidenceReportSection] = Field(default_factory=list)
    json_report: dict[str, Any] = Field(default_factory=dict)
    html_report: str = ""


LCMSSourceFormat = Literal["auto", "processed_peak_table", "mzML", "mzXML", "unsupported_vendor", "unknown"]
LCMSDetectedSourceFormat = Literal["processed_peak_table", "mzML", "mzXML", "unsupported_vendor", "unknown"]
LCMSImportLabel = Literal["ready_for_downstream_ms", "metadata_only", "unsupported_vendor_format", "invalid_input"]
LCMSPolarity = Literal["positive", "negative", "unknown"]


class LCMSPeak(BaseModel):
    model_config = ConfigDict(extra="forbid")

    mz: float = Field(gt=0.0)
    intensity: float = Field(ge=0.0)
    relative_intensity: float = Field(ge=0.0, le=100.0)


class LCMSChromatogramPoint(BaseModel):
    model_config = ConfigDict(extra="forbid")

    scan_id: str
    ms_level: int = Field(ge=1, le=2)
    retention_time_min: float | None = Field(default=None, ge=0.0)
    total_ion_current: float | None = Field(default=None, ge=0.0)
    base_peak_mz: float | None = Field(default=None, gt=0.0)
    base_peak_intensity: float | None = Field(default=None, ge=0.0)


class LCMSScanSummary(BaseModel):
    model_config = ConfigDict(extra="forbid")

    scan_id: str
    ms_level: int = Field(ge=1, le=2)
    retention_time_min: float | None = Field(default=None, ge=0.0)
    precursor_mz: float | None = Field(default=None, gt=0.0)
    polarity: LCMSPolarity = "unknown"
    peak_count: int = Field(ge=0)
    total_ion_current: float | None = Field(default=None, ge=0.0)
    base_peak_mz: float | None = Field(default=None, gt=0.0)
    base_peak_intensity: float | None = Field(default=None, ge=0.0)
    warnings: list[str] = Field(default_factory=list)


class LCMSImportedSpectrum(BaseModel):
    model_config = ConfigDict(extra="forbid")

    scan_id: str
    ms_level: int = Field(ge=1, le=2)
    retention_time_min: float | None = Field(default=None, ge=0.0)
    precursor_mz: float | None = Field(default=None, gt=0.0)
    polarity: LCMSPolarity = "unknown"
    peak_count: int = Field(ge=0)
    peaks: list[LCMSPeak] = Field(default_factory=list)
    warnings: list[str] = Field(default_factory=list)


class LCMSExtractedPrecursor(BaseModel):
    model_config = ConfigDict(extra="forbid")

    scan_id: str
    precursor_mz: float = Field(gt=0.0)
    retention_time_min: float | None = Field(default=None, ge=0.0)
    peak_count: int = Field(ge=0)
    total_ion_current: float | None = Field(default=None, ge=0.0)


class LCMSImportBridgeRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")

    sample_id: str | None = Field(default=None, max_length=100)
    filename: str | None = Field(default=None, max_length=300)
    source_format: LCMSSourceFormat = "auto"
    source_text: str = Field(min_length=1, max_length=5_000_000)
    preferred_msms_precursor_mz: float | None = Field(default=None, gt=0.0)
    min_relative_intensity: float = Field(default=0.5, ge=0.0, le=100.0)
    max_ms1_peaks: int = Field(default=250, ge=1, le=5000)
    max_msms_peaks_per_spectrum: int = Field(default=250, ge=1, le=5000)
    max_peaks_per_spectrum: int = Field(default=50, ge=1, le=1000)
    max_scans_to_report: int = Field(default=250, ge=1, le=5000)
    mz_tolerance_da: float = Field(default=0.02, gt=0.0, le=2.0)
    ppm_tolerance: float = Field(default=20.0, gt=0.0, le=500.0)

    @field_validator("sample_id", "filename", mode="before")
    @classmethod
    def _optional_trim_lcms_import(cls, value: str | None) -> str | None:
        if value is None:
            return None
        value = str(value).strip()
        return value or None


class LCMSImportBridgeResult(BaseModel):
    model_config = ConfigDict(extra="forbid")

    sample_id: str | None = None
    filename: str | None = None
    source_format: LCMSDetectedSourceFormat
    file_sha256: str
    immutable_raw_data: bool = True
    label: LCMSImportLabel
    scan_count: int = Field(ge=0)
    ms1_scan_count: int = Field(ge=0)
    ms2_scan_count: int = Field(ge=0)
    chromatogram: list[LCMSChromatogramPoint] = Field(default_factory=list)
    scans: list[LCMSScanSummary] = Field(default_factory=list)
    imported_spectra: list[LCMSImportedSpectrum] = Field(default_factory=list)
    extracted_ms1_peak_count: int = Field(ge=0)
    extracted_ms1_peak_list_text: str = ""
    extracted_msms_spectrum_count: int = Field(ge=0)
    extracted_msms_peak_list_text: str = ""
    selected_msms_scan_id: str | None = None
    selected_msms_precursor_mz: float | None = Field(default=None, gt=0.0)
    primary_ms1_mz: float | None = Field(default=None, gt=0.0)
    extracted_precursors: list[LCMSExtractedPrecursor] = Field(default_factory=list)
    recommended_next_actions: list[str] = Field(default_factory=list)
    warnings: list[str] = Field(default_factory=list)
    notes: list[str] = Field(default_factory=list)
    metadata: dict[str, Any] = Field(default_factory=dict)


LCMSFeaturePurityLabel = Literal["high_purity", "possible_coelution", "poor_peak_purity", "not_assessed"]
LCMSFeatureLabel = Literal["clean_feature", "possible_coelution", "weak_or_no_feature", "invalid_input"]


class LCMSXICPoint(BaseModel):
    model_config = ConfigDict(extra="forbid")

    target_mz: float = Field(gt=0.0)
    scan_id: str
    retention_time_min: float = Field(ge=0.0)
    intensity: float = Field(ge=0.0)
    relative_intensity: float = Field(ge=0.0, le=100.0)


class LCMSCoelutingIon(BaseModel):
    model_config = ConfigDict(extra="forbid")

    mz: float = Field(gt=0.0)
    area: float = Field(ge=0.0)
    relative_area_percent: float = Field(ge=0.0, le=100.0)
    max_intensity: float = Field(ge=0.0)
    correlation_to_target: float | None = Field(default=None, ge=-1.0, le=1.0)


class LCMSFeaturePurityReport(BaseModel):
    model_config = ConfigDict(extra="forbid")

    feature_id: str
    target_mz: float = Field(gt=0.0)
    apex_rt_min: float = Field(ge=0.0)
    rt_window_start_min: float = Field(ge=0.0)
    rt_window_end_min: float = Field(ge=0.0)
    purity_percent: float = Field(ge=0.0, le=100.0)
    label: LCMSFeaturePurityLabel
    top_coeluting_ions: list[LCMSCoelutingIon] = Field(default_factory=list)
    warnings: list[str] = Field(default_factory=list)


class LCMSLinkedMSMSSpectrum(BaseModel):
    model_config = ConfigDict(extra="forbid")

    scan_id: str
    precursor_mz: float = Field(gt=0.0)
    retention_time_min: float | None = Field(default=None, ge=0.0)
    precursor_error_da: float
    precursor_error_ppm: float
    peak_count: int = Field(ge=0)
    total_ion_current: float | None = Field(default=None, ge=0.0)


class LCMSFeaturePeak(BaseModel):
    model_config = ConfigDict(extra="forbid")

    feature_id: str
    target_mz: float = Field(gt=0.0)
    observed_mz: float | None = Field(default=None, gt=0.0)
    apex_rt_min: float = Field(ge=0.0)
    start_rt_min: float = Field(ge=0.0)
    end_rt_min: float = Field(ge=0.0)
    apex_intensity: float = Field(ge=0.0)
    area: float = Field(ge=0.0)
    width_min: float = Field(ge=0.0)
    scan_count: int = Field(ge=0)
    signal_to_noise: float = Field(ge=0.0)
    purity: LCMSFeaturePurityReport
    linked_msms_spectra: list[LCMSLinkedMSMSSpectrum] = Field(default_factory=list)
    label: LCMSFeatureLabel
    evidence_summary: list[str] = Field(default_factory=list)
    warnings: list[str] = Field(default_factory=list)


class LCMSFeatureDetectionRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")

    sample_id: str | None = Field(default=None, max_length=100)
    filename: str | None = Field(default=None, max_length=300)
    source_format: LCMSSourceFormat = "auto"
    source_text: str = Field(min_length=1, max_length=5_000_000)
    target_mz_values: list[float] = Field(default_factory=list, max_length=100)
    target_mz_text: str | None = Field(default=None, max_length=4000)
    mz_tolerance_da: float = Field(default=0.02, gt=0.0, le=2.0)
    ppm_tolerance: float = Field(default=20.0, gt=0.0, le=500.0)
    min_relative_feature_height: float = Field(default=5.0, ge=0.0, le=100.0)
    min_peak_height: float = Field(default=0.0, ge=0.0)
    min_scans_per_feature: int = Field(default=2, ge=1, le=100)
    smoothing_window: int = Field(default=1, ge=1, le=25)
    purity_rt_window_min: float = Field(default=0.20, ge=0.0, le=10.0)
    top_coeluting_ions: int = Field(default=5, ge=0, le=50)
    max_features: int = Field(default=20, ge=1, le=200)
    max_scans_to_report: int = Field(default=1000, ge=1, le=20000)
    max_xic_points: int = Field(default=5000, ge=1, le=200000)

    @field_validator("sample_id", "filename", "target_mz_text", mode="before")
    @classmethod
    def _optional_trim_lcms_feature_fields(cls, value: str | None) -> str | None:
        if value is None:
            return None
        value = str(value).strip()
        return value or None

    @field_validator("target_mz_values")
    @classmethod
    def _positive_targets(cls, value: list[float]) -> list[float]:
        for item in value:
            if item <= 0:
                raise ValueError("target_mz_values must contain only positive values.")
        return value


class LCMSFeatureDetectionResult(BaseModel):
    model_config = ConfigDict(extra="forbid")

    sample_id: str | None = None
    filename: str | None = None
    source_format: LCMSDetectedSourceFormat
    file_sha256: str
    immutable_raw_data: bool = True
    label: LCMSImportLabel
    scan_count: int = Field(ge=0)
    ms1_scan_count: int = Field(ge=0)
    ms2_scan_count: int = Field(ge=0)
    target_count: int = Field(ge=0)
    feature_count: int = Field(ge=0)
    clean_feature_count: int = Field(ge=0)
    coeluting_feature_count: int = Field(ge=0)
    weak_feature_count: int = Field(ge=0)
    best_feature: LCMSFeaturePeak | None = None
    features: list[LCMSFeaturePeak] = Field(default_factory=list)
    xic_points: list[LCMSXICPoint] = Field(default_factory=list)
    chromatogram: list[LCMSChromatogramPoint] = Field(default_factory=list)
    recommended_next_actions: list[str] = Field(default_factory=list)
    warnings: list[str] = Field(default_factory=list)
    notes: list[str] = Field(default_factory=list)
    metadata: dict[str, Any] = Field(default_factory=dict)


LCMSRunRole = Literal["sample", "blank", "qc", "reference"]
LCMSFeatureGroupLabel = Literal[
    "sample_enriched_feature",
    "sample_only_feature",
    "possible_background_feature",
    "blank_like_feature",
    "blank_only_background",
    "low_abundance_feature",
    "reference_or_qc_only",
    "invalid_input",
]
LCMSFeatureGroupingLabel = Literal["ready_for_candidate_scoring", "review_background_before_scoring", "metadata_only", "invalid_input"]


class LCMSFeatureGroupingRunInput(BaseModel):
    model_config = ConfigDict(extra="forbid")

    run_id: str = Field(min_length=1, max_length=100)
    role: LCMSRunRole = "sample"
    filename: str | None = Field(default=None, max_length=300)
    source_format: LCMSSourceFormat = "auto"
    source_text: str = Field(min_length=1, max_length=5_000_000)

    @field_validator("run_id", "filename", mode="before")
    @classmethod
    def _trim_grouping_run_strings(cls, value: str | None) -> str | None:
        if value is None:
            return None
        value = str(value).strip()
        return value or None


class LCMSRunAlignmentSummary(BaseModel):
    model_config = ConfigDict(extra="forbid")

    run_id: str
    role: LCMSRunRole
    filename: str | None = None
    source_format: LCMSDetectedSourceFormat | str
    file_sha256: str
    raw_feature_count: int = Field(ge=0)
    aligned_feature_count: int = Field(ge=0)
    rt_shift_min: float
    anchor_match_count: int = Field(ge=0)
    warnings: list[str] = Field(default_factory=list)


class LCMSFeatureGroupMember(BaseModel):
    model_config = ConfigDict(extra="forbid")

    run_id: str
    role: LCMSRunRole | str
    source_format: LCMSDetectedSourceFormat | str
    file_sha256: str
    feature_id: str
    target_mz: float = Field(gt=0.0)
    observed_mz: float = Field(gt=0.0)
    raw_apex_rt_min: float = Field(ge=0.0)
    aligned_apex_rt_min: float = Field(ge=0.0)
    rt_shift_applied_min: float
    area: float = Field(ge=0.0)
    apex_intensity: float = Field(ge=0.0)
    purity_percent: float = Field(ge=0.0, le=100.0)
    purity_label: str
    feature_label: str
    linked_msms_count: int = Field(ge=0)
    warnings: list[str] = Field(default_factory=list)


class LCMSFeatureRelationship(BaseModel):
    model_config = ConfigDict(extra="forbid")

    relationship_type: str
    label: str
    partner_group_id: str
    observed_delta_mz: float = Field(ge=0.0)
    expected_delta_mz: float = Field(ge=0.0)
    rt_delta_min: float = Field(ge=0.0)
    evidence_summary: str


class LCMSFeatureGroup(BaseModel):
    model_config = ConfigDict(extra="forbid")

    group_id: str
    representative_mz: float = Field(gt=0.0)
    representative_rt_min: float = Field(ge=0.0)
    label: LCMSFeatureGroupLabel
    member_count: int = Field(ge=0)
    roles_present: list[str] = Field(default_factory=list)
    sample_area: float = Field(ge=0.0)
    blank_area: float = Field(ge=0.0)
    qc_area: float = Field(default=0.0, ge=0.0)
    reference_area: float = Field(default=0.0, ge=0.0)
    blank_ratio: float = Field(default=0.0, ge=0.0)
    blank_subtracted_area: float = Field(ge=0.0)
    members: list[LCMSFeatureGroupMember] = Field(default_factory=list)
    relationships: list[LCMSFeatureRelationship] = Field(default_factory=list)
    evidence_summary: list[str] = Field(default_factory=list)
    warnings: list[str] = Field(default_factory=list)


class LCMSFeatureGroupingRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")

    sample_id: str | None = Field(default=None, max_length=100)
    runs: list[LCMSFeatureGroupingRunInput] = Field(default_factory=list, max_length=20)
    reference_run_id: str | None = Field(default=None, max_length=100)

    target_mz_values: list[float] = Field(default_factory=list, max_length=200)
    target_mz_text: str | None = Field(default=None, max_length=8000)
    mz_tolerance_da: float = Field(default=0.02, gt=0.0, le=2.0)
    ppm_tolerance: float = Field(default=20.0, gt=0.0, le=500.0)
    min_relative_feature_height: float = Field(default=5.0, ge=0.0, le=100.0)
    min_peak_height: float = Field(default=0.0, ge=0.0)
    min_scans_per_feature: int = Field(default=2, ge=1, le=100)
    smoothing_window: int = Field(default=1, ge=1, le=25)
    purity_rt_window_min: float = Field(default=0.20, ge=0.0, le=10.0)
    top_coeluting_ions: int = Field(default=5, ge=0, le=50)
    max_features_per_run: int = Field(default=50, ge=1, le=500)
    max_scans_to_report: int = Field(default=2000, ge=1, le=50000)
    max_xic_points: int = Field(default=5000, ge=1, le=200000)
    exclude_weak_features: bool = True

    align_retention_times: bool = True
    alignment_anchor_mz_values: list[float] = Field(default_factory=list, max_length=100)
    alignment_anchor_mz_text: str | None = Field(default=None, max_length=4000)
    group_rt_tolerance_min: float = Field(default=0.12, ge=0.0, le=10.0)
    family_rt_tolerance_min: float = Field(default=0.15, ge=0.0, le=10.0)
    rt_alignment_search_window_min: float = Field(default=1.0, ge=0.0, le=30.0)
    max_rt_shift_min: float = Field(default=2.0, ge=0.0, le=30.0)

    blank_subtraction_factor: float = Field(default=1.0, ge=0.0, le=100.0)
    blank_area_ratio_threshold: float = Field(default=0.30, ge=0.0, le=100.0)
    possible_background_ratio_threshold: float = Field(default=0.10, ge=0.0, le=100.0)
    min_blank_subtracted_area: float = Field(default=0.0, ge=0.0)
    annotate_feature_families: bool = True
    max_runs: int = Field(default=10, ge=1, le=50)
    max_groups_to_report: int = Field(default=100, ge=1, le=1000)

    @field_validator("sample_id", "reference_run_id", "target_mz_text", "alignment_anchor_mz_text", mode="before")
    @classmethod
    def _trim_grouping_optional_fields(cls, value: str | None) -> str | None:
        if value is None:
            return None
        value = str(value).strip()
        return value or None

    @field_validator("target_mz_values", "alignment_anchor_mz_values")
    @classmethod
    def _positive_grouping_mz_values(cls, value: list[float]) -> list[float]:
        for item in value:
            if item <= 0:
                raise ValueError("m/z values must be positive.")
        return value


class LCMSFeatureGroupingResult(BaseModel):
    model_config = ConfigDict(extra="forbid")

    sample_id: str | None = None
    run_count: int = Field(ge=0)
    reference_run_id: str
    label: LCMSFeatureGroupingLabel
    group_count: int = Field(ge=0)
    sample_enriched_group_count: int = Field(ge=0)
    background_group_count: int = Field(ge=0)
    blank_subtracted_group_count: int = Field(ge=0)
    relationship_count: int = Field(ge=0)
    alignment_summaries: list[LCMSRunAlignmentSummary] = Field(default_factory=list)
    groups: list[LCMSFeatureGroup] = Field(default_factory=list)
    feature_table_text: str = ""
    recommended_next_actions: list[str] = Field(default_factory=list)
    warnings: list[str] = Field(default_factory=list)
    notes: list[str] = Field(default_factory=list)
    metadata: dict[str, Any] = Field(default_factory=dict)


class StoredAnalysisRecord(BaseModel):
    model_config = ConfigDict(extra="forbid")

    id: int
    created_at: datetime
    label: DiagnosticLabel
    sample_id: str | None = None
    solvent: str | None = None
    smiles: str
    nmr_text: str
    expected_total_h: int
    observed_total_h: float
    confidence: float
    notes: list[str]
    parsed_peak_count: int = 0
    delta_total_h: int = 0
    job_id: int | None = None
    user_id: int | None = None
    review_status: ReviewStatus = "pending_review"
    reviewer_user_id: int | None = None
    reviewed_at: datetime | None = None
    review_comment: str | None = None
    final_label: str | None = None
    hours_saved_estimate: float = 0.0


class FullStoredAnalysisRecord(StoredAnalysisRecord):
    model_config = ConfigDict(extra="forbid")

    full_report: AnalysisReport


class ProjectCreate(BaseModel):
    model_config = ConfigDict(extra="forbid")

    name: str = Field(min_length=1, max_length=200)
    description: str | None = Field(default=None, max_length=2000)

    @field_validator("name", "description", mode="before")
    @classmethod
    def _trim_project_fields(cls, value: str | None) -> str | None:
        if value is None:
            return None
        value = str(value).strip()
        return value or None


class ProjectRecord(BaseModel):
    model_config = ConfigDict(extra="forbid")

    id: int
    user_id: int
    name: str
    description: str | None = None
    created_at: datetime
    updated_at: datetime
    sample_count: int = 0
    analysis_count: int = 0
    linked_analysis_count: int = 0


class ProjectSampleCreate(BaseModel):
    model_config = ConfigDict(extra="forbid")

    sample_id: str | None = Field(default=None, max_length=100)
    smiles: str = Field(min_length=1, max_length=500)
    nmr_text: str = Field(min_length=3, max_length=10_000)
    solvent: str | None = Field(default=None, max_length=50)
    analysis_id: int | None = Field(default=None, ge=1)

    @field_validator("sample_id", "solvent", mode="before")
    @classmethod
    def _trim_optional_sample_fields(cls, value: str | None) -> str | None:
        if value is None:
            return None
        value = str(value).strip()
        return value or None

    @field_validator("smiles", "nmr_text", mode="before")
    @classmethod
    def _trim_required_sample_fields(cls, value: str) -> str:
        value = str(value).strip()
        if not value:
            raise ValueError("This field cannot be empty.")
        return value


class ProjectSampleAnalysisLink(BaseModel):
    model_config = ConfigDict(extra="forbid")

    analysis_id: int = Field(ge=1)


class ProjectSampleRecord(BaseModel):
    model_config = ConfigDict(extra="forbid")

    id: int
    project_id: int
    analysis_id: int | None = None
    sample_id: str | None = None
    smiles: str
    nmr_text: str
    solvent: str | None = None
    created_at: datetime
    updated_at: datetime


class JobRecord(BaseModel):
    model_config = ConfigDict(extra="forbid")

    id: int
    created_at: datetime
    user_id: int | None = None
    job_name: str | None = None
    uploaded_filename: str | None = None
    status: JobStatus
    total_items: int
    completed_items: int
    started_at: datetime | None = None
    finished_at: datetime | None = None
    error_message: str | None = None
    backend_job_id: str | None = None
    queue_name: str | None = None
    review_required: bool = True
    review_completion_rate: float = 0.0


class AsyncJobAccepted(BaseModel):
    model_config = ConfigDict(extra="forbid")

    job: JobRecord
    accepted: bool = True
    detail: str = "Job accepted and queued for background processing."
    queue_backend: Literal["rq", "fastapi-background"]


class UserCreate(BaseModel):
    model_config = ConfigDict(extra="forbid")

    email: EmailStr
    password: str = Field(min_length=8, max_length=512)


class UserLogin(BaseModel):
    model_config = ConfigDict(extra="forbid")

    email: EmailStr
    password: str = Field(min_length=8, max_length=512)


class UserPublic(BaseModel):
    model_config = ConfigDict(extra="forbid")

    id: int
    email: EmailStr
    is_active: bool
    is_admin: bool
    is_verified: bool
    created_at: datetime
    verified_at: datetime | None = None


class AccessTokenResponse(BaseModel):
    model_config = ConfigDict(extra="forbid")

    access_token: str
    token_type: Literal["bearer"] = "bearer"
    expires_at: datetime
    user: UserPublic


class MessageResponse(BaseModel):
    model_config = ConfigDict(extra="forbid")

    detail: str


class EmailActionRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")

    email: EmailStr


class PasswordResetConfirm(BaseModel):
    model_config = ConfigDict(extra="forbid")

    token: str = Field(min_length=10, max_length=512)
    new_password: str = Field(min_length=8, max_length=512)


class TokenActionPreview(BaseModel):
    model_config = ConfigDict(extra="forbid")

    detail: str
    token: str | None = None
    expires_at: datetime | None = None


class EmailOutboxRecord(BaseModel):
    model_config = ConfigDict(extra="forbid")

    id: int
    created_at: datetime
    to_email: EmailStr
    subject: str
    body: str
    purpose: ActionTokenPurpose | None = None


class QueueWorkerStatus(BaseModel):
    model_config = ConfigDict(extra="forbid")

    backend: Literal["rq", "fastapi-background"]
    redis_configured: bool
    queue_name: str
    detail: str


class ReviewDecisionCreate(BaseModel):
    model_config = ConfigDict(extra="forbid")

    comment: str | None = Field(default=None, max_length=4000)
    final_label: str | None = Field(default=None, max_length=100)
    hours_saved_estimate: float | None = Field(default=None, ge=0.0, le=100.0)


class ReviewDecisionRecord(BaseModel):
    model_config = ConfigDict(extra="forbid")

    id: int
    analysis_id: int
    reviewer_user_id: int
    action: ReviewAction
    previous_status: ReviewStatus
    new_status: ReviewStatus
    comment: str | None = None
    previous_label: str | None = None
    final_label: str | None = None
    created_at: datetime


class ReviewQueueItem(BaseModel):
    model_config = ConfigDict(extra="forbid")

    analysis: StoredAnalysisRecord
    evidence_notes: list[str] = Field(default_factory=list)
    recommended_action: ReviewStatus | None = None


class AuditEventRecord(BaseModel):
    model_config = ConfigDict(extra="forbid")

    id: int
    created_at: datetime
    event_type: str
    message: str
    actor_user_id: int | None = None
    actor_email: str | None = None
    entity_type: str | None = None
    entity_id: int | None = None
    metadata: dict[str, Any] = Field(default_factory=dict)


class NMR2DEvidenceReportSection(BaseModel):
    model_config = ConfigDict(extra="forbid")

    run_id: int
    report_url: str
    experiment_type: str
    peak_count: int = 0
    matched_correlations: int = 0
    suspicious_correlations: int = 0
    evidence_score: float = Field(ge=0.0, le=1.0)
    cosy_connectivity_notes: list[str] = Field(default_factory=list)
    hsqc_hmqc_direct_attachment_notes: list[str] = Field(default_factory=list)
    hmbc_long_range_notes: list[str] = Field(default_factory=list)
    missing_extra_correlation_notes: list[str] = Field(default_factory=list)
    dept_apt_experiment_type: str | None = None
    dept_apt_typed_peak_count: int = 0
    dept_apt_type_summary: dict[str, int] = Field(default_factory=dict)
    dept_apt_matched_carbon13_count: int = 0
    dept_apt_consistency_score: float | None = Field(default=None, ge=0.0, le=1.0)
    dept_apt_apt_convention_warning: str | None = None
    hsqc_hmqc_dept_apt_supported_correlations: int = 0
    hsqc_hmqc_dept_apt_conflicting_correlations: int = 0
    hmbc_dept_apt_contextual_correlations: int = 0
    human_review_status: ReviewStatus = "pending_review"
    score_components: dict[str, Any] = Field(default_factory=dict)
    warnings: list[str] = Field(default_factory=list)


class AnalysisEvidenceReport(BaseModel):
    model_config = ConfigDict(extra="forbid")

    analysis: FullStoredAnalysisRecord
    structure: StructureSummary
    parsed_nmr_text: str
    parsed_peaks: list[Peak] = Field(default_factory=list)
    spectrum_derived_matched_peaks: list[Peak] = Field(default_factory=list)
    unmatched_peaks: list[Peak] = Field(default_factory=list)
    impurity_candidates: list[str] = Field(default_factory=list)
    confidence_notes: list[str] = Field(default_factory=list)
    review_decisions: list[ReviewDecisionRecord] = Field(default_factory=list)
    audit_events: list[AuditEventRecord] = Field(default_factory=list)
    audit_metadata: dict[str, Any] = Field(default_factory=dict)
    nmr2d_evidence: list[NMR2DEvidenceReportSection] = Field(default_factory=list)
    time_saved_estimate: float = 0.0


class StoredReportRecord(BaseModel):
    model_config = ConfigDict(extra="forbid")

    id: int
    analysis_id: int
    user_id: int | None = None
    created_at: datetime
    version: int = 1
    title: str
    report: AnalysisEvidenceReport


class SampleDetailRecord(BaseModel):
    model_config = ConfigDict(extra="forbid")

    sample: ProjectSampleRecord
    latest_analysis: StoredAnalysisRecord | None = None
    notes: list[str] = Field(default_factory=list)
    reports_count: int = 0


class SampleTimelineRecord(BaseModel):
    model_config = ConfigDict(extra="forbid")

    sample: ProjectSampleRecord
    analysis_ids: list[int] = Field(default_factory=list)
    review_decisions: list[ReviewDecisionRecord] = Field(default_factory=list)
    audit_events: list[AuditEventRecord] = Field(default_factory=list)


class SampleReportsRecord(BaseModel):
    model_config = ConfigDict(extra="forbid")

    sample: ProjectSampleRecord
    reports: list[StoredReportRecord] = Field(default_factory=list)


class ProjectDashboardRecord(BaseModel):
    model_config = ConfigDict(extra="forbid")

    project: ProjectRecord
    sample_count: int = 0
    analysis_count: int = 0
    approved_reviews: int = 0
    rejected_reviews: int = 0
    pending_review: int = 0
    solvent_distribution: dict[str, int] = Field(default_factory=dict)
    hours_saved_estimate: float = 0.0
    likely_impurity_flags: int = 0
    latest_activity: list[AuditEventRecord] = Field(default_factory=list)


class SampleAnalysisComparisonItem(BaseModel):
    model_config = ConfigDict(extra="forbid")

    analysis_id: int
    created_at: datetime
    label: DiagnosticLabel
    final_label: str | None = None
    proton_count_delta: int = 0
    confidence: float
    impurity_flags: int = 0
    reviewer_outcome: ReviewStatus
    peak_count: int = 0
    peak_count_change: int = 0
    time_saved: float = 0.0


class SampleAnalysisComparison(BaseModel):
    model_config = ConfigDict(extra="forbid")

    sample: ProjectSampleRecord
    basis: Literal["sample_id", "smiles", "none"]
    items: list[SampleAnalysisComparisonItem] = Field(default_factory=list)


class MetricCard(BaseModel):
    model_config = ConfigDict(extra="forbid")

    key: str
    label: str
    value: float
    unit: str | None = None
    detail: str | None = None


class MetricsSummary(BaseModel):
    model_config = ConfigDict(extra="forbid")

    total_analyses: int
    total_jobs: int
    pending_review: int
    approved_reviews: int
    rejected_reviews: int
    overrides: int
    validation_failures: int
    likely_impurity_flags: int
    hours_saved_estimate: float
    automation_rate: float = Field(ge=0.0, le=1.0)
    cards: list[MetricCard] = Field(default_factory=list)


class AdminUserRecord(BaseModel):
    model_config = ConfigDict(extra="forbid")

    id: int
    email: EmailStr
    is_active: bool
    is_admin: bool
    is_verified: bool
    created_at: datetime
    analyses_count: int = 0
    jobs_count: int = 0


class AdminSystemSummary(BaseModel):
    model_config = ConfigDict(extra="forbid")

    users: int
    admins: int
    active_users: int
    analyses: int
    jobs: int
    pending_review: int
    audit_events: int
    queue_backend: str
    redis_configured: bool
