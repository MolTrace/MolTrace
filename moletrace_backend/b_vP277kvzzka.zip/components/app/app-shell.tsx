"use client"

import { useState } from "react"
import { AppSidebar } from "./app-sidebar"
import { AppTopbar } from "./app-topbar"
import { AIEvidenceQueue } from "./ai-evidence-queue"
import { cn } from "@/lib/utils"

export function AppShell({ children }: { children: React.ReactNode }) {
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false)
  const [evidenceQueueOpen, setEvidenceQueueOpen] = useState(true)

  return (
    <div className="flex h-screen overflow-hidden bg-background">
      <AppSidebar 
        collapsed={sidebarCollapsed} 
        onToggle={() => setSidebarCollapsed(!sidebarCollapsed)} 
      />
      <div className="flex flex-1 flex-col overflow-hidden">
        <AppTopbar onToggleEvidenceQueue={() => setEvidenceQueueOpen(!evidenceQueueOpen)} />
        <div className="flex flex-1 overflow-hidden">
          <main className={cn(
            "flex-1 overflow-y-auto p-6",
            evidenceQueueOpen && "lg:mr-80"
          )}>
            {children}
          </main>
          {evidenceQueueOpen && (
            <AIEvidenceQueue onClose={() => setEvidenceQueueOpen(false)} />
          )}
        </div>
      </div>
    </div>
  )
}
