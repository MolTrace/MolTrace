import { Upload, Search, ListOrdered, UserCheck, FileText, ChevronRight } from "lucide-react"

const steps = [
  { icon: Upload, label: "Upload Data", description: "NMR, MS, LC-MS/MS" },
  { icon: Search, label: "Analyze Evidence", description: "AI-powered interpretation" },
  { icon: ListOrdered, label: "Rank Candidates", description: "Confidence scoring" },
  { icon: UserCheck, label: "Human Review", description: "Expert validation" },
  { icon: FileText, label: "Export Report", description: "Regulatory-ready" },
]

export function WorkflowStrip() {
  return (
    <section className="border-y bg-muted/30 py-16">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="text-center">
          <h2 className="text-sm font-medium uppercase tracking-wider text-muted-foreground">
            Workflow
          </h2>
          <p className="mt-2 text-2xl font-semibold tracking-tight">
            From raw data to regulatory report
          </p>
        </div>
        <div className="mt-12 flex flex-wrap items-center justify-center gap-4 lg:gap-2">
          {steps.map((step, index) => (
            <div key={step.label} className="flex items-center">
              <div className="flex flex-col items-center gap-3 rounded-lg border bg-card p-4 shadow-sm transition-shadow hover:shadow-md sm:min-w-[160px]">
                <div className="flex h-10 w-10 items-center justify-center rounded-full bg-secondary">
                  <step.icon className="h-5 w-5 text-foreground" />
                </div>
                <div className="text-center">
                  <div className="text-sm font-medium">{step.label}</div>
                  <div className="text-xs text-muted-foreground">{step.description}</div>
                </div>
              </div>
              {index < steps.length - 1 && (
                <ChevronRight className="mx-2 hidden h-5 w-5 text-muted-foreground lg:block" />
              )}
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
