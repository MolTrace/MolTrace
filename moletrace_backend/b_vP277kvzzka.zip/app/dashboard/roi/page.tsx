"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Progress } from "@/components/ui/progress"
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table"
import {
  Clock,
  FileText,
  CheckSquare,
  TrendingUp,
  TrendingDown,
  AlertCircle,
  Target,
  Zap,
  RefreshCw,
  Download,
  Calendar,
} from "lucide-react"

const topWorkflows = [
  { name: "NMR Structure Elucidation", runs: 156, hoursSaved: 312, avgTime: "8 min" },
  { name: "MS/MS Unknown Annotation", runs: 243, hoursSaved: 162, avgTime: "4 min" },
  { name: "Impurity Profiling Report", runs: 89, hoursSaved: 178, avgTime: "12 min" },
  { name: "Regulatory Evidence Assembly", runs: 34, hoursSaved: 136, avgTime: "25 min" },
  { name: "Batch Record Generation", runs: 67, hoursSaved: 67, avgTime: "6 min" },
]

const monthlyTrend = [
  { month: "Jan", hours: 620 },
  { month: "Feb", hours: 680 },
  { month: "Mar", hours: 720 },
  { month: "Apr", hours: 690 },
  { month: "May", hours: 780 },
  { month: "Jun", hours: 820 },
  { month: "Jul", hours: 790 },
  { month: "Aug", hours: 850 },
  { month: "Sep", hours: 880 },
  { month: "Oct", hours: 920 },
  { month: "Nov", hours: 960 },
  { month: "Dec", hours: 1020 },
]

export default function ROIPage() {
  const maxHours = Math.max(...monthlyTrend.map(m => m.hours))

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-semibold tracking-tight">Automation ROI</h1>
          <p className="text-muted-foreground">
            Measure the value delivered by MolTrace to your organization.
          </p>
        </div>
        <div className="flex items-center gap-2">
          <Badge variant="outline" className="gap-1">
            <Calendar className="h-3 w-3" />
            Last 30 days
          </Badge>
          <Button variant="outline" size="sm" className="gap-2">
            <Download className="h-4 w-4" />
            Export Report
          </Button>
        </div>
      </div>

      {/* Primary KPIs */}
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-5">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Hours Saved</CardTitle>
            <Clock className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">847</div>
            <div className="mt-1 flex items-center gap-1 text-xs">
              <TrendingUp className="h-3 w-3 text-success" />
              <span className="text-success">+23%</span>
              <span className="text-muted-foreground">vs last month</span>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Reports Generated</CardTitle>
            <FileText className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">156</div>
            <div className="mt-1 flex items-center gap-1 text-xs">
              <TrendingUp className="h-3 w-3 text-success" />
              <span className="text-success">+15%</span>
              <span className="text-muted-foreground">vs last month</span>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Manual Steps Avoided</CardTitle>
            <CheckSquare className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">2,341</div>
            <div className="mt-1 text-xs text-muted-foreground">
              Peak picking, baseline correction, integration
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Avg. Upload to Report</CardTitle>
            <Zap className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">12<span className="text-lg font-normal text-muted-foreground"> min</span></div>
            <div className="mt-1 flex items-center gap-1 text-xs">
              <TrendingDown className="h-3 w-3 text-success" />
              <span className="text-success">-18%</span>
              <span className="text-muted-foreground">faster</span>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Pending Review</CardTitle>
            <AlertCircle className="h-4 w-4 text-warning" />
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">7</div>
            <div className="mt-1 text-xs text-muted-foreground">
              3 with contradictions flagged
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-6 lg:grid-cols-3">
        {/* Hours Saved Trend */}
        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle>Hours Saved Trend</CardTitle>
            <CardDescription>Monthly automation savings over the past year</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex h-64 items-end gap-2">
              {monthlyTrend.map((month) => (
                <div key={month.month} className="flex flex-1 flex-col items-center gap-1">
                  <div className="text-xs font-mono text-muted-foreground">{month.hours}</div>
                  <div
                    className="w-full rounded-t bg-accent/80 transition-all hover:bg-accent"
                    style={{ height: `${(month.hours / maxHours) * 180}px` }}
                  />
                  <div className="text-xs text-muted-foreground">{month.month}</div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Model Confidence Calibration */}
        <Card>
          <CardHeader>
            <CardTitle>Model Confidence Calibration</CardTitle>
            <CardDescription>How well predictions match outcomes</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="text-center">
              <div className="text-4xl font-bold text-accent">94.2%</div>
              <div className="mt-1 text-sm text-muted-foreground">Overall Accuracy</div>
            </div>

            <div className="space-y-4">
              <div>
                <div className="mb-1.5 flex justify-between text-sm">
                  <span>Spectroscopy Module</span>
                  <span className="font-mono text-success">96.1%</span>
                </div>
                <Progress value={96.1} className="h-2" />
              </div>
              <div>
                <div className="mb-1.5 flex justify-between text-sm">
                  <span>Reaction Optimization</span>
                  <span className="font-mono text-success">91.8%</span>
                </div>
                <Progress value={91.8} className="h-2" />
              </div>
              <div>
                <div className="mb-1.5 flex justify-between text-sm">
                  <span>Regulatory Intelligence</span>
                  <span className="font-mono text-success">94.7%</span>
                </div>
                <Progress value={94.7} className="h-2" />
              </div>
            </div>

            <div className="rounded-lg border bg-muted/30 p-3 text-center">
              <div className="flex items-center justify-center gap-1 text-xs text-muted-foreground">
                <RefreshCw className="h-3 w-3" />
                Last calibrated: 2 days ago
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-6 lg:grid-cols-3">
        {/* Top Automated Workflows */}
        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle>Top Automated Workflows</CardTitle>
            <CardDescription>Most impactful automation by hours saved</CardDescription>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Workflow</TableHead>
                  <TableHead className="text-right">Runs</TableHead>
                  <TableHead className="text-right">Hours Saved</TableHead>
                  <TableHead className="text-right">Avg. Time</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {topWorkflows.map((workflow, i) => (
                  <TableRow key={workflow.name}>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <Badge variant="outline" className="w-6 justify-center text-xs">
                          {i + 1}
                        </Badge>
                        <span className="font-medium">{workflow.name}</span>
                      </div>
                    </TableCell>
                    <TableCell className="text-right font-mono">{workflow.runs}</TableCell>
                    <TableCell className="text-right">
                      <span className="font-mono font-medium text-success">{workflow.hoursSaved}</span>
                    </TableCell>
                    <TableCell className="text-right font-mono text-muted-foreground">
                      {workflow.avgTime}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>

        {/* Renewal Value Summary */}
        <Card className="border-accent/30 bg-accent/5">
          <CardHeader>
            <div className="flex items-center gap-2">
              <Target className="h-5 w-5 text-accent" />
              <CardTitle>Renewal Value Summary</CardTitle>
            </div>
            <CardDescription>Annual platform impact for renewal discussion</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="space-y-4">
              <div className="flex justify-between border-b pb-2">
                <span className="text-sm text-muted-foreground">Total Hours Saved (YTD)</span>
                <span className="text-lg font-bold">9,840</span>
              </div>
              <div className="flex justify-between border-b pb-2">
                <span className="text-sm text-muted-foreground">FTE Equivalent</span>
                <span className="text-lg font-bold">4.9</span>
              </div>
              <div className="flex justify-between border-b pb-2">
                <span className="text-sm text-muted-foreground">Reports Generated (YTD)</span>
                <span className="text-lg font-bold">1,847</span>
              </div>
              <div className="flex justify-between border-b pb-2">
                <span className="text-sm text-muted-foreground">Error Rate Reduction</span>
                <span className="text-lg font-bold text-success">78%</span>
              </div>
              <div className="flex justify-between">
                <span className="text-sm text-muted-foreground">Est. Cost Savings</span>
                <span className="text-lg font-bold text-accent">$492K</span>
              </div>
            </div>

            <div className="rounded-lg bg-background p-4 text-center">
              <div className="text-3xl font-bold text-accent">12.3x</div>
              <div className="text-sm text-muted-foreground">Return on Investment</div>
            </div>

            <Button className="w-full gap-2">
              <Download className="h-4 w-4" />
              Download Executive Summary
            </Button>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
