import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table"
import { 
  Activity, 
  AlertCircle, 
  FileText, 
  Clock, 
  TrendingUp,
  CheckCircle2,
  AlertTriangle,
  Eye,
} from "lucide-react"

const recentActivity = [
  {
    id: "NMR-2024-0847",
    sampleId: "API-Q4-BATCH-12",
    module: "Spectroscopy",
    status: "review",
    confidence: 87,
    reviewer: "Dr. Chen",
    reportStatus: "pending",
  },
  {
    id: "MSMS-2024-1293",
    sampleId: "MET-STUDY-089",
    module: "Spectroscopy",
    status: "approved",
    confidence: 94,
    reviewer: "Dr. Patel",
    reportStatus: "ready",
  },
  {
    id: "RXN-OPT-2024-156",
    sampleId: "PROC-DEV-022",
    module: "Reactions",
    status: "running",
    confidence: 78,
    reviewer: "-",
    reportStatus: "pending",
  },
  {
    id: "REG-2024-0445",
    sampleId: "API-Q4-BATCH-12",
    module: "Regulatory",
    status: "approved",
    confidence: 96,
    reviewer: "Dr. Kim",
    reportStatus: "ready",
  },
  {
    id: "NMR-2024-0842",
    sampleId: "IMP-PROF-017",
    module: "Spectroscopy",
    status: "contradiction",
    confidence: 72,
    reviewer: "Dr. Chen",
    reportStatus: "pending",
  },
]

export default function DashboardPage() {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-semibold tracking-tight">Dashboard</h1>
        <p className="text-muted-foreground">
          Overview of your analytical workflows and pending reviews.
        </p>
      </div>

      {/* Stats Grid */}
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-5">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Active Analyses</CardTitle>
            <Activity className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">23</div>
            <p className="text-xs text-muted-foreground">
              <span className="text-success">+4</span> from yesterday
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Review Required</CardTitle>
            <AlertCircle className="h-4 w-4 text-warning" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">7</div>
            <p className="text-xs text-muted-foreground">
              2 with contradictions
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Reports Ready</CardTitle>
            <FileText className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">12</div>
            <p className="text-xs text-muted-foreground">
              Ready for export
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Hours Saved</CardTitle>
            <Clock className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">156</div>
            <p className="text-xs text-muted-foreground">
              <span className="text-success">+12%</span> this week
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Model Confidence</CardTitle>
            <TrendingUp className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="flex items-baseline gap-2">
              <span className="text-2xl font-bold">94.2%</span>
            </div>
            <Progress value={94.2} className="mt-2 h-1.5" />
          </CardContent>
        </Card>
      </div>

      {/* Recent Activity Table */}
      <Card>
        <CardHeader>
          <CardTitle>Recent Activity</CardTitle>
          <CardDescription>
            Latest analyses across all modules requiring attention.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Analysis ID</TableHead>
                <TableHead>Sample ID</TableHead>
                <TableHead>Module</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Confidence</TableHead>
                <TableHead>Reviewer</TableHead>
                <TableHead>Report</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {recentActivity.map((item) => (
                <TableRow key={item.id} className="cursor-pointer hover:bg-muted/50">
                  <TableCell className="font-mono text-sm">{item.id}</TableCell>
                  <TableCell className="text-sm">{item.sampleId}</TableCell>
                  <TableCell>
                    <Badge variant="outline">{item.module}</Badge>
                  </TableCell>
                  <TableCell>
                    {item.status === "approved" && (
                      <Badge variant="outline" className="gap-1 border-success/50 text-success">
                        <CheckCircle2 className="h-3 w-3" />
                        Approved
                      </Badge>
                    )}
                    {item.status === "review" && (
                      <Badge variant="outline" className="gap-1 border-accent/50 text-accent">
                        <Eye className="h-3 w-3" />
                        Review
                      </Badge>
                    )}
                    {item.status === "running" && (
                      <Badge variant="secondary" className="gap-1">
                        <Activity className="h-3 w-3" />
                        Running
                      </Badge>
                    )}
                    {item.status === "contradiction" && (
                      <Badge variant="outline" className="gap-1 border-warning/50 text-warning">
                        <AlertTriangle className="h-3 w-3" />
                        Contradiction
                      </Badge>
                    )}
                  </TableCell>
                  <TableCell>
                    <div className="flex items-center gap-2">
                      <Progress value={item.confidence} className="h-1.5 w-16" />
                      <span className="font-mono text-sm">{item.confidence}%</span>
                    </div>
                  </TableCell>
                  <TableCell className="text-sm">{item.reviewer}</TableCell>
                  <TableCell>
                    {item.reportStatus === "ready" ? (
                      <Badge className="bg-success text-success-foreground">Ready</Badge>
                    ) : (
                      <Badge variant="secondary">Pending</Badge>
                    )}
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  )
}
