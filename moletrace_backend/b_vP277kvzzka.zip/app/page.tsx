"use client"

import { Header } from "@/components/marketing/header"
import { Hero } from "@/components/marketing/hero"
import { WorkflowStrip } from "@/components/marketing/workflow-strip"
import { ModuleCards } from "@/components/marketing/module-cards"
import { EvidenceSection } from "@/components/marketing/evidence-section"
import { EnterpriseSection } from "@/components/marketing/enterprise-section"
import { DashboardPreview } from "@/components/marketing/dashboard-preview"
import { CTASection } from "@/components/marketing/cta-section"
import { Footer } from "@/components/marketing/footer"

export default function MarketingPage() {
  return (
    <div className="min-h-screen bg-background">
      <Header />
      <main>
        <Hero />
        <WorkflowStrip />
        <ModuleCards />
        <EvidenceSection />
        <EnterpriseSection />
        <DashboardPreview />
        <CTASection />
      </main>
      <Footer />
    </div>
  )
}
