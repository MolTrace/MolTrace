from __future__ import annotations

from fastapi import APIRouter, Depends, File, Form, HTTPException, Request, UploadFile

from .database import get_nmr2d_run_by_id, save_nmr2d_run
from .exceptions import StructureParseError
from .nmr2d_analyzer import analyze_nmr2d
from .nmr2d_models import NMR2DAnalysisReport, NMR2DPreview, NMR2DRunRecord
from .nmr2d_parser import NMR2DParseError, parse_processed_2d_nmr

router = APIRouter(prefix="/nmr2d", tags=["2D NMR"])


def _feature_enabled(request: Request) -> bool:
    return bool(getattr(request.app.state.settings, "enable_2d_nmr", False))


def require_nmr2d_enabled(request: Request) -> None:
    if not _feature_enabled(request):
        raise HTTPException(status_code=404, detail="2D NMR evidence engine is disabled by feature flag.")


@router.get("/status")
def nmr2d_status(request: Request) -> dict[str, object]:
    return {
        "enabled": _feature_enabled(request),
        "feature_flag": "ENABLE_2D_NMR",
        "supported_experiments": ["COSY", "HSQC", "HMQC", "HMBC"],
        "raw_2d_fid_processing": "not_implemented",
        "guarded_release": True,
    }


@router.post("/preview", response_model=NMR2DPreview, dependencies=[Depends(require_nmr2d_enabled)])
async def nmr2d_preview(
    request: Request,
    file: UploadFile = File(...),
    experiment: str | None = Form(default=None),
    include_contour_preview: bool = Form(default=False),
    context=Depends(__import__("nmrcheck.api", fromlist=["require_access_context"]).require_access_context),
) -> NMR2DPreview:
    filename = file.filename or "processed_2d_nmr.csv"
    content = await file.read()
    try:
        preview = parse_processed_2d_nmr(
            filename,
            content,
            experiment_hint=experiment,
            include_contour_preview=include_contour_preview,
        )
    except (NMR2DParseError, ValueError) as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    api = __import__("nmrcheck.api", fromlist=["_audit_from_context"])
    api._audit_from_context(
        request,
        context=context,
        event_type="nmr2d.preview",
        message="Processed 2D NMR table previewed.",
        metadata={"filename": filename, "experiments": preview.experiments, "peak_count": preview.peak_count},
    )
    return preview


@router.post("/analyze", response_model=NMR2DAnalysisReport, dependencies=[Depends(require_nmr2d_enabled)])
async def nmr2d_analyze(
    request: Request,
    file: UploadFile = File(...),
    smiles: str = Form(...),
    sample_id: str | None = Form(default=None),
    solvent: str | None = Form(default=None),
    proton_nmr_text: str | None = Form(default=None),
    carbon13_text: str | None = Form(default=None),
    experiment: str | None = Form(default=None),
    include_contour_preview: bool = Form(default=False),
    analysis_id: int | None = Form(default=None),
    context=Depends(__import__("nmrcheck.api", fromlist=["require_access_context"]).require_access_context),
) -> NMR2DAnalysisReport:
    filename = file.filename or "processed_2d_nmr.csv"
    content = await file.read()
    try:
        preview = parse_processed_2d_nmr(
            filename,
            content,
            experiment_hint=experiment,
            include_contour_preview=include_contour_preview,
        )
        report = analyze_nmr2d(
            smiles=smiles,
            preview=preview,
            sample_id=sample_id,
            solvent=solvent,
            proton_nmr_text=proton_nmr_text,
            carbon13_text=carbon13_text,
        )
    except (NMR2DParseError, StructureParseError, ValueError) as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    run = save_nmr2d_run(
        request.app.state.session_factory,
        report,
        source_filename=filename,
        user_id=getattr(context, "user_id", None),
        analysis_id=analysis_id,
    )
    report = report.model_copy(update={"run_id": run.id})
    api = __import__("nmrcheck.api", fromlist=["_audit_from_context"])
    api._audit_from_context(
        request,
        context=context,
        event_type="nmr2d.analyze",
        message="Processed 2D NMR evidence analyzed.",
        entity_type="nmr2d_run",
        entity_id=run.id,
        metadata={
            "filename": filename,
            "sample_id": sample_id,
            "experiments": report.experiments,
            "overall_score": report.overall_score,
            "human_review_required": True,
        },
    )
    return report


@router.get("/runs/{run_id}", response_model=NMR2DRunRecord, dependencies=[Depends(require_nmr2d_enabled)])
def nmr2d_run_report(
    run_id: int,
    request: Request,
    context=Depends(__import__("nmrcheck.api", fromlist=["require_access_context"]).require_access_context),
) -> NMR2DRunRecord:
    user_id = None if getattr(context, "system_api_key", False) else getattr(context, "user_id", None)
    record = get_nmr2d_run_by_id(request.app.state.session_factory, run_id=run_id, user_id=user_id)
    if record is None:
        raise HTTPException(status_code=404, detail="2D NMR run not found.")
    return record


@router.get("/runs/{run_id}/report", response_model=NMR2DAnalysisReport, dependencies=[Depends(require_nmr2d_enabled)])
def nmr2d_run_evidence_report(
    run_id: int,
    request: Request,
    context=Depends(__import__("nmrcheck.api", fromlist=["require_access_context"]).require_access_context),
) -> NMR2DAnalysisReport:
    user_id = None if getattr(context, "system_api_key", False) else getattr(context, "user_id", None)
    record = get_nmr2d_run_by_id(request.app.state.session_factory, run_id=run_id, user_id=user_id)
    if record is None:
        raise HTTPException(status_code=404, detail="2D NMR run not found.")
    return record.report


@router.post("/raw/preview", dependencies=[Depends(require_nmr2d_enabled)])
def nmr2d_raw_preview_stub(
    context=Depends(__import__("nmrcheck.api", fromlist=["require_access_context"]).require_access_context),
) -> dict[str, object]:
    return {
        "implemented": False,
        "detail": "Raw 2D FID/SER processing is intentionally deferred; upload processed COSY/HSQC/HMQC/HMBC peak tables for this guarded release.",
    }
