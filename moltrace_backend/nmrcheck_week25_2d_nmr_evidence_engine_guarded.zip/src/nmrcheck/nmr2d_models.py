from __future__ import annotations

from datetime import datetime
from typing import Any, Literal

from pydantic import BaseModel, ConfigDict, Field

NMR2DExperiment = Literal["COSY", "HSQC", "HMQC", "HMBC"]


class NMR2DPeak(BaseModel):
    model_config = ConfigDict(extra="forbid")

    experiment: NMR2DExperiment
    f1_ppm: float = Field(ge=-20.0, le=260.0)
    f2_ppm: float = Field(ge=-20.0, le=260.0)
    intensity: float | None = None
    assignment: str | None = Field(default=None, max_length=250)
    proton1_ppm: float | None = Field(default=None, ge=-5.0, le=20.0)
    proton2_ppm: float | None = Field(default=None, ge=-5.0, le=20.0)
    carbon_ppm: float | None = Field(default=None, ge=-20.0, le=260.0)
    linked_proton_ppm: float | None = Field(default=None, ge=-5.0, le=20.0)
    linked_carbon_ppm: float | None = Field(default=None, ge=-20.0, le=260.0)
    evidence_label: str = "review"
    notes: list[str] = Field(default_factory=list)


class NMR2DContourPoint(BaseModel):
    model_config = ConfigDict(extra="forbid")

    f1_ppm: float
    f2_ppm: float
    intensity: float


class NMR2DPreview(BaseModel):
    model_config = ConfigDict(extra="forbid")

    filename: str
    source_mode: Literal["processed_peak_table", "processed_contour_table", "raw_2d_stub"] = "processed_peak_table"
    experiments: list[NMR2DExperiment] = Field(default_factory=list)
    peak_count: int = 0
    peaks: list[NMR2DPeak] = Field(default_factory=list)
    contour_preview: list[NMR2DContourPoint] = Field(default_factory=list)
    warnings: list[str] = Field(default_factory=list)
    metadata: dict[str, Any] = Field(default_factory=dict)


class NMR2DAnalysisReport(BaseModel):
    model_config = ConfigDict(extra="forbid")

    sample_id: str | None = None
    run_id: int | None = None
    smiles: str
    solvent: str | None = None
    experiments: list[NMR2DExperiment] = Field(default_factory=list)
    peak_count: int = 0
    linked_1d_peak_count: int = 0
    correlation_score: float = Field(ge=0.0, le=1.0)
    structure_consistency_score: float = Field(ge=0.0, le=1.0)
    overall_score: float = Field(ge=0.0, le=1.0)
    confidence: float = Field(ge=0.0, le=1.0)
    label: Literal["supportive", "review", "weak", "invalid_input"]
    peaks: list[NMR2DPeak] = Field(default_factory=list)
    warnings: list[str] = Field(default_factory=list)
    notes: list[str] = Field(default_factory=list)
    evidence_summary: dict[str, Any] = Field(default_factory=dict)
    metadata: dict[str, Any] = Field(default_factory=dict)


class NMR2DRunRecord(BaseModel):
    model_config = ConfigDict(extra="forbid")

    id: int
    created_at: datetime
    user_id: int | None = None
    analysis_id: int | None = None
    sample_id: str | None = None
    experiments: list[NMR2DExperiment] = Field(default_factory=list)
    peak_count: int = 0
    overall_score: float = Field(ge=0.0, le=1.0)
    review_status: str = "pending_review"
    report: NMR2DAnalysisReport
