from __future__ import annotations

from collections import Counter
from typing import Any

from rdkit import Chem

from .carbon13 import Carbon13ParseError, parse_carbon13_text
from .chemistry import mol_from_smiles
from .exceptions import PeakParseError, StructureParseError
from .nmr2d_models import NMR2DAnalysisReport, NMR2DPeak, NMR2DPreview
from .parser import parse_nmr_text


def _nearest(value: float | None, candidates: list[float], tolerance: float) -> float | None:
    if value is None or not candidates:
        return None
    nearest = min(candidates, key=lambda item: abs(item - value))
    return round(nearest, 4) if abs(nearest - value) <= tolerance else None


def _one_d_context(proton_nmr_text: str | None, carbon13_text: str | None) -> tuple[list[float], list[float], list[str]]:
    warnings: list[str] = []
    proton_shifts: list[float] = []
    carbon_shifts: list[float] = []
    if proton_nmr_text and proton_nmr_text.strip():
        try:
            proton_shifts = [peak.shift_ppm for peak in parse_nmr_text(proton_nmr_text)]
        except PeakParseError as exc:
            warnings.append(f"Could not parse linked ¹H trace text: {exc}")
    if carbon13_text and carbon13_text.strip():
        try:
            carbon_shifts = [peak.shift_ppm for peak in parse_carbon13_text(carbon13_text)]
        except (Carbon13ParseError, ValueError) as exc:
            warnings.append(f"Could not parse linked ¹³C trace text: {exc}")
    return proton_shifts, carbon_shifts, warnings


def _carbon_count(smiles: str) -> int:
    mol = mol_from_smiles(smiles)
    return sum(1 for atom in mol.GetAtoms() if atom.GetAtomicNum() == 6)


def _protonated_carbon_count(smiles: str) -> int:
    mol = Chem.AddHs(mol_from_smiles(smiles))
    count = 0
    for atom in mol.GetAtoms():
        if atom.GetAtomicNum() != 6:
            continue
        if any(neighbor.GetAtomicNum() == 1 for neighbor in atom.GetNeighbors()):
            count += 1
    return count


def _plausible_peak(peak: NMR2DPeak) -> bool:
    if peak.experiment == "COSY":
        return peak.proton1_ppm is not None and peak.proton2_ppm is not None
    return peak.proton1_ppm is not None and peak.carbon_ppm is not None


def analyze_nmr2d(
    *,
    smiles: str,
    preview: NMR2DPreview,
    sample_id: str | None = None,
    solvent: str | None = None,
    proton_nmr_text: str | None = None,
    carbon13_text: str | None = None,
) -> NMR2DAnalysisReport:
    try:
        carbon_count = _carbon_count(smiles)
        protonated_carbons = _protonated_carbon_count(smiles)
    except StructureParseError:
        raise
    proton_shifts, carbon_shifts, warnings = _one_d_context(proton_nmr_text, carbon13_text)
    linked_peaks: list[NMR2DPeak] = []
    for peak in preview.peaks:
        linked_h = _nearest(peak.proton1_ppm, proton_shifts, 0.06)
        linked_c = _nearest(peak.carbon_ppm, carbon_shifts, 0.7)
        evidence_label = "supportive" if (linked_h or linked_c or _plausible_peak(peak)) else "review"
        notes = list(peak.notes)
        if peak.experiment in {"HSQC", "HMQC"}:
            notes.append("Direct ¹H-¹³C attachment evidence; do not treat intensity as carbon count.")
        elif peak.experiment == "HMBC":
            notes.append("Long-range ¹H-¹³C connectivity evidence; ambiguous without review.")
        elif peak.experiment == "COSY":
            notes.append("¹H-¹H scalar connectivity evidence.")
        linked_peaks.append(
            peak.model_copy(
                update={
                    "linked_proton_ppm": linked_h,
                    "linked_carbon_ppm": linked_c,
                    "evidence_label": evidence_label,
                    "notes": notes,
                }
            )
        )
    plausible_count = sum(1 for peak in linked_peaks if _plausible_peak(peak))
    linked_count = sum(1 for peak in linked_peaks if peak.linked_proton_ppm is not None or peak.linked_carbon_ppm is not None)
    peak_count = len(linked_peaks)
    plausibility_score = plausible_count / peak_count if peak_count else 0.0
    link_score = linked_count / peak_count if peak_count and (proton_shifts or carbon_shifts) else (0.6 if peak_count else 0.0)
    experiment_counts = Counter(peak.experiment for peak in linked_peaks)
    direct_count = experiment_counts.get("HSQC", 0) + experiment_counts.get("HMQC", 0)
    direct_expected = max(1, protonated_carbons)
    direct_score = 1.0
    if direct_count:
        direct_score = max(0.0, min(1.0, 1.0 - abs(direct_count - direct_expected) / max(direct_expected, direct_count, 1)))
    elif {"HSQC", "HMQC"} & set(preview.experiments):
        direct_score = 0.25
    diversity_score = min(1.0, len(experiment_counts) / 3.0)
    structure_score = round(0.55 * plausibility_score + 0.30 * direct_score + 0.15 * diversity_score, 4)
    correlation_score = round(0.65 * plausibility_score + 0.35 * link_score, 4)
    overall = round(0.58 * correlation_score + 0.42 * structure_score, 4)
    confidence = round(min(0.92, 0.35 + overall * 0.55), 4)
    if overall >= 0.72:
        label = "supportive"
    elif overall >= 0.45:
        label = "review"
    else:
        label = "weak"
    notes = [
        "2D NMR correlations are treated as supporting evidence and require human review.",
        "Processed 2D tables are not a substitute for raw 2D FID/SER processing.",
    ]
    if not proton_shifts and not carbon_shifts:
        warnings.append("No linked 1D ¹H/¹³C trace text was supplied; 1D trace linking score is limited.")
    if direct_count > carbon_count + 2:
        warnings.append("More direct ¹H-¹³C correlations were observed than expected carbons; review duplicate/aliased peaks.")
    return NMR2DAnalysisReport(
        sample_id=sample_id,
        smiles=smiles,
        solvent=solvent,
        experiments=preview.experiments,
        peak_count=peak_count,
        linked_1d_peak_count=linked_count,
        correlation_score=correlation_score,
        structure_consistency_score=structure_score,
        overall_score=overall,
        confidence=confidence,
        label=label,  # type: ignore[arg-type]
        peaks=linked_peaks,
        warnings=[*preview.warnings, *warnings],
        notes=notes,
        evidence_summary={
            "experiment_counts": dict(experiment_counts),
            "plausible_peak_count": plausible_count,
            "linked_1d_peak_count": linked_count,
            "expected_carbon_count": carbon_count,
            "expected_protonated_carbon_count": protonated_carbons,
            "human_review_required": True,
        },
        metadata={
            "feature": "week25_2d_nmr_evidence_engine_guarded",
            "raw_2d_fid_processing": "not_implemented",
            "report_integration": "nmr2d_run_report",
        },
    )
