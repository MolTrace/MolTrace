
from __future__ import annotations

from datetime import UTC, datetime

from sqlalchemy import Boolean, DateTime, Float, ForeignKey, Index, Integer, String, Text, UniqueConstraint
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column, relationship


def utcnow() -> datetime:
    return datetime.now(UTC)


class Base(DeclarativeBase):
    pass


class UserORM(Base):
    __tablename__ = "users"
    __table_args__ = (Index("ix_users_email_verified", "email", "is_verified"),)

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    email: Mapped[str] = mapped_column(String(255), unique=True, index=True)
    password_hash: Mapped[str] = mapped_column(Text)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)
    is_admin: Mapped[bool] = mapped_column(Boolean, default=False)
    is_verified: Mapped[bool] = mapped_column(Boolean, default=False, index=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
    verified_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)

    tokens: Mapped[list[SessionTokenORM]] = relationship(back_populates="user", cascade="all, delete-orphan")
    action_tokens: Mapped[list[UserActionTokenORM]] = relationship(back_populates="user", cascade="all, delete-orphan")
    analyses: Mapped[list[AnalysisORM]] = relationship(back_populates="user", foreign_keys="AnalysisORM.user_id")
    review_assignments: Mapped[list[AnalysisORM]] = relationship(back_populates="reviewer", foreign_keys="AnalysisORM.reviewer_user_id")
    jobs: Mapped[list[JobORM]] = relationship(back_populates="user")
    projects: Mapped[list[ProjectORM]] = relationship(back_populates="user", cascade="all, delete-orphan")
    review_decisions: Mapped[list[ReviewDecisionORM]] = relationship(back_populates="reviewer")
    raw_archives: Mapped[list[RawArchiveORM]] = relationship(back_populates="user")
    nmr2d_runs: Mapped[list[NMR2DRunORM]] = relationship(back_populates="user")
    audit_events: Mapped[list[AuditEventORM]] = relationship(back_populates="actor_user")


class SessionTokenORM(Base):
    __tablename__ = "session_tokens"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"), index=True)
    token_hash: Mapped[str] = mapped_column(String(128), unique=True, index=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
    expires_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), index=True)
    revoked_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    last_used_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)

    user: Mapped[UserORM] = relationship(back_populates="tokens")


class UserActionTokenORM(Base):
    __tablename__ = "user_action_tokens"
    __table_args__ = (
        Index("ix_user_action_tokens_user_purpose", "user_id", "purpose"),
        Index("ix_user_action_tokens_expires", "expires_at"),
        UniqueConstraint("token_hash", name="uq_user_action_tokens_token_hash"),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"), index=True)
    purpose: Mapped[str] = mapped_column(String(32), index=True)
    token_hash: Mapped[str] = mapped_column(String(128), index=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
    expires_at: Mapped[datetime] = mapped_column(DateTime(timezone=True))
    consumed_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)

    user: Mapped[UserORM] = relationship(back_populates="action_tokens")


class EmailOutboxORM(Base):
    __tablename__ = "email_outbox"
    __table_args__ = (Index("ix_email_outbox_created_at", "created_at"),)

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
    to_email: Mapped[str] = mapped_column(String(255), index=True)
    subject: Mapped[str] = mapped_column(String(255))
    body: Mapped[str] = mapped_column(Text)
    purpose: Mapped[str | None] = mapped_column(String(32), nullable=True)


class JobORM(Base):
    __tablename__ = "jobs"
    __table_args__ = (
        Index("ix_jobs_user_status_created", "user_id", "status", "created_at"),
        Index("ix_jobs_status_created", "status", "created_at"),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    user_id: Mapped[int | None] = mapped_column(ForeignKey("users.id", ondelete="SET NULL"), nullable=True, index=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
    started_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    finished_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    job_name: Mapped[str | None] = mapped_column(String(255), nullable=True)
    uploaded_filename: Mapped[str | None] = mapped_column(String(255), nullable=True)
    status: Mapped[str] = mapped_column(String(32), index=True)
    total_items: Mapped[int] = mapped_column(Integer, default=0)
    completed_items: Mapped[int] = mapped_column(Integer, default=0)
    error_message: Mapped[str | None] = mapped_column(Text, nullable=True)
    backend_job_id: Mapped[str | None] = mapped_column(String(64), nullable=True, index=True)
    queue_name: Mapped[str | None] = mapped_column(String(100), nullable=True)
    review_required: Mapped[bool] = mapped_column(Boolean, default=True)

    user: Mapped[UserORM | None] = relationship(back_populates="jobs")
    analyses: Mapped[list[AnalysisORM]] = relationship(back_populates="job")


class AnalysisORM(Base):
    __tablename__ = "analyses"
    __table_args__ = (
        Index("ix_analyses_user_created", "user_id", "created_at"),
        Index("ix_analyses_job_created", "job_id", "created_at"),
        Index("ix_analyses_label_created", "label", "created_at"),
        Index("ix_analyses_review_status", "review_status", "created_at"),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    user_id: Mapped[int | None] = mapped_column(ForeignKey("users.id", ondelete="SET NULL"), nullable=True, index=True)
    job_id: Mapped[int | None] = mapped_column(ForeignKey("jobs.id", ondelete="SET NULL"), nullable=True, index=True)
    reviewer_user_id: Mapped[int | None] = mapped_column(ForeignKey("users.id", ondelete="SET NULL"), nullable=True, index=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
    reviewed_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    sample_id: Mapped[str | None] = mapped_column(String(100), nullable=True)
    solvent: Mapped[str | None] = mapped_column(String(50), nullable=True)
    smiles: Mapped[str] = mapped_column(Text)
    nmr_text: Mapped[str] = mapped_column(Text)
    label: Mapped[str] = mapped_column(String(64), index=True)
    review_status: Mapped[str] = mapped_column(String(32), default="pending_review")
    final_label: Mapped[str | None] = mapped_column(String(100), nullable=True)
    review_comment: Mapped[str | None] = mapped_column(Text, nullable=True)
    expected_total_h: Mapped[int] = mapped_column(Integer)
    observed_total_h: Mapped[float] = mapped_column(Float)
    confidence: Mapped[float] = mapped_column(Float)
    notes_json: Mapped[str] = mapped_column(Text)
    parsed_peak_count: Mapped[int] = mapped_column(Integer, default=0)
    delta_total_h: Mapped[int] = mapped_column(Integer, default=0)
    hours_saved_estimate: Mapped[float] = mapped_column(Float, default=0.0)
    full_report_json: Mapped[str] = mapped_column(Text)

    user: Mapped[UserORM | None] = relationship(back_populates="analyses", foreign_keys=[user_id])
    reviewer: Mapped[UserORM | None] = relationship(back_populates="review_assignments", foreign_keys=[reviewer_user_id])
    job: Mapped[JobORM | None] = relationship(back_populates="analyses")
    project_samples: Mapped[list[ProjectSampleORM]] = relationship(back_populates="analysis")
    review_decisions: Mapped[list[ReviewDecisionORM]] = relationship(back_populates="analysis", cascade="all, delete-orphan")
    reports: Mapped[list[ReportORM]] = relationship(back_populates="analysis", cascade="all, delete-orphan")
    fid_runs: Mapped[list[FIDRunORM]] = relationship(back_populates="analysis")
    nmr2d_runs: Mapped[list[NMR2DRunORM]] = relationship(back_populates="analysis")


class ProjectORM(Base):
    __tablename__ = "projects"
    __table_args__ = (
        Index("ix_projects_user_created", "user_id", "created_at"),
        UniqueConstraint("user_id", "name", name="uq_projects_user_name"),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"), index=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow, onupdate=utcnow)
    name: Mapped[str] = mapped_column(String(200))
    description: Mapped[str | None] = mapped_column(Text, nullable=True)

    user: Mapped[UserORM] = relationship(back_populates="projects")
    samples: Mapped[list[ProjectSampleORM]] = relationship(back_populates="project", cascade="all, delete-orphan")


class ProjectSampleORM(Base):
    __tablename__ = "project_samples"
    __table_args__ = (
        Index("ix_project_samples_project_created", "project_id", "created_at"),
        Index("ix_project_samples_analysis_created", "analysis_id", "created_at"),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    project_id: Mapped[int] = mapped_column(ForeignKey("projects.id", ondelete="CASCADE"), index=True)
    analysis_id: Mapped[int | None] = mapped_column(ForeignKey("analyses.id", ondelete="SET NULL"), nullable=True, index=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow, onupdate=utcnow)
    sample_id: Mapped[str | None] = mapped_column(String(100), nullable=True)
    smiles: Mapped[str] = mapped_column(Text)
    nmr_text: Mapped[str] = mapped_column(Text)
    solvent: Mapped[str | None] = mapped_column(String(50), nullable=True)

    project: Mapped[ProjectORM] = relationship(back_populates="samples")
    analysis: Mapped[AnalysisORM | None] = relationship(back_populates="project_samples")


class ReportORM(Base):
    __tablename__ = "reports"
    __table_args__ = (
        Index("ix_reports_analysis_created", "analysis_id", "created_at"),
        Index("ix_reports_user_created", "user_id", "created_at"),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    analysis_id: Mapped[int] = mapped_column(ForeignKey("analyses.id", ondelete="CASCADE"), index=True)
    user_id: Mapped[int | None] = mapped_column(ForeignKey("users.id", ondelete="SET NULL"), nullable=True, index=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
    version: Mapped[int] = mapped_column(Integer, default=1)
    title: Mapped[str] = mapped_column(String(255))
    report_json: Mapped[str] = mapped_column(Text)

    analysis: Mapped[AnalysisORM] = relationship(back_populates="reports")


class ReviewDecisionORM(Base):
    __tablename__ = "review_decisions"
    __table_args__ = (
        Index("ix_review_decisions_analysis_created", "analysis_id", "created_at"),
        Index("ix_review_decisions_reviewer_created", "reviewer_user_id", "created_at"),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    analysis_id: Mapped[int] = mapped_column(ForeignKey("analyses.id", ondelete="CASCADE"), index=True)
    reviewer_user_id: Mapped[int] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"), index=True)
    action: Mapped[str] = mapped_column(String(32), index=True)
    previous_status: Mapped[str] = mapped_column(String(32))
    new_status: Mapped[str] = mapped_column(String(32), index=True)
    comment: Mapped[str | None] = mapped_column(Text, nullable=True)
    previous_label: Mapped[str | None] = mapped_column(String(100), nullable=True)
    final_label: Mapped[str | None] = mapped_column(String(100), nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)

    analysis: Mapped[AnalysisORM] = relationship(back_populates="review_decisions")
    reviewer: Mapped[UserORM] = relationship(back_populates="review_decisions")


class FIDRunORM(Base):
    __tablename__ = "fid_runs"
    __table_args__ = (
        Index("ix_fid_runs_user_created", "user_id", "created_at"),
        Index("ix_fid_runs_review_status_created", "review_status", "created_at"),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    user_id: Mapped[int | None] = mapped_column(
        ForeignKey("users.id", ondelete="SET NULL"), nullable=True, index=True
    )
    analysis_id: Mapped[int | None] = mapped_column(
        ForeignKey("analyses.id", ondelete="SET NULL"), nullable=True, index=True
    )
    raw_archive_id: Mapped[int | None] = mapped_column(
        ForeignKey("raw_archives.id", ondelete="SET NULL"), nullable=True, index=True
    )
    reviewer_user_id: Mapped[int | None] = mapped_column(
        ForeignKey("users.id", ondelete="SET NULL"), nullable=True, index=True
    )
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
    reviewed_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    sample_id: Mapped[str | None] = mapped_column(String(100), nullable=True)
    filename: Mapped[str] = mapped_column(String(255))
    raw_sha256: Mapped[str | None] = mapped_column(String(64), nullable=True, index=True)
    selected_preset: Mapped[str] = mapped_column(String(100))
    quality_label: Mapped[str] = mapped_column(String(32))
    quality_score: Mapped[float] = mapped_column(Float, default=0.0)
    review_status: Mapped[str] = mapped_column(String(32), default="pending_review")
    reviewer_comment: Mapped[str | None] = mapped_column(Text, nullable=True)
    preview_json: Mapped[str] = mapped_column(Text)
    metadata_json: Mapped[str] = mapped_column(Text)
    processing_recipe_json: Mapped[str] = mapped_column(Text, default="{}")
    derived_spectrum_metadata_json: Mapped[str] = mapped_column(Text, default="{}")

    analysis: Mapped[AnalysisORM | None] = relationship(back_populates="fid_runs")
    raw_archive: Mapped[RawArchiveORM | None] = relationship(back_populates="fid_runs")
    decisions: Mapped[list[FIDRunReviewDecisionORM]] = relationship(
        back_populates="run", cascade="all, delete-orphan"
    )


class FIDRunReviewDecisionORM(Base):
    __tablename__ = "fid_run_review_decisions"
    __table_args__ = (
        Index("ix_fid_run_decisions_run_created", "run_id", "created_at"),
        Index("ix_fid_run_decisions_reviewer_created", "reviewer_user_id", "created_at"),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    run_id: Mapped[int] = mapped_column(ForeignKey("fid_runs.id", ondelete="CASCADE"), index=True)
    reviewer_user_id: Mapped[int] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"), index=True)
    action: Mapped[str] = mapped_column(String(32), index=True)
    previous_status: Mapped[str] = mapped_column(String(32))
    new_status: Mapped[str] = mapped_column(String(32), index=True)
    comment: Mapped[str | None] = mapped_column(Text, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)

    run: Mapped[FIDRunORM] = relationship(back_populates="decisions")


class RawArchiveORM(Base):
    __tablename__ = "raw_archives"
    __table_args__ = (
        UniqueConstraint("sha256", name="uq_raw_archives_sha256"),
        Index("ix_raw_archives_user_created", "user_id", "created_at"),
        Index("ix_raw_archives_vendor_created", "vendor_detected", "created_at"),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
    user_id: Mapped[int | None] = mapped_column(
        ForeignKey("users.id", ondelete="SET NULL"), nullable=True, index=True
    )
    filename: Mapped[str] = mapped_column(String(255))
    content_type: Mapped[str | None] = mapped_column(String(100), nullable=True)
    byte_size: Mapped[int] = mapped_column(Integer)
    sha256: Mapped[str] = mapped_column(String(64), index=True)
    storage_path: Mapped[str] = mapped_column(Text)
    vendor_detected: Mapped[str] = mapped_column(String(100), index=True)
    dataset_root: Mapped[str | None] = mapped_column(String(500), nullable=True)
    required_files_present: Mapped[bool] = mapped_column(Boolean, default=False)
    files_found_json: Mapped[str] = mapped_column(Text, default="[]")
    acquisition_metadata_json: Mapped[str] = mapped_column(Text, default="{}")
    warnings_json: Mapped[str] = mapped_column(Text, default="[]")
    immutable: Mapped[bool] = mapped_column(Boolean, default=True)

    user: Mapped[UserORM | None] = relationship(back_populates="raw_archives")
    fid_runs: Mapped[list[FIDRunORM]] = relationship(back_populates="raw_archive")


class NMR2DRunORM(Base):
    __tablename__ = "nmr2d_runs"
    __table_args__ = (
        Index("ix_nmr2d_runs_user_created", "user_id", "created_at"),
        Index("ix_nmr2d_runs_analysis_created", "analysis_id", "created_at"),
        Index("ix_nmr2d_runs_review_status_created", "review_status", "created_at"),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    user_id: Mapped[int | None] = mapped_column(ForeignKey("users.id", ondelete="SET NULL"), nullable=True, index=True)
    analysis_id: Mapped[int | None] = mapped_column(ForeignKey("analyses.id", ondelete="SET NULL"), nullable=True, index=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
    sample_id: Mapped[str | None] = mapped_column(String(100), nullable=True)
    source_filename: Mapped[str] = mapped_column(String(255))
    experiment_types_json: Mapped[str] = mapped_column(Text, default="[]")
    peak_count: Mapped[int] = mapped_column(Integer, default=0)
    overall_score: Mapped[float] = mapped_column(Float, default=0.0)
    review_status: Mapped[str] = mapped_column(String(32), default="pending_review")
    peaks_json: Mapped[str] = mapped_column(Text, default="[]")
    report_json: Mapped[str] = mapped_column(Text)
    metadata_json: Mapped[str] = mapped_column(Text, default="{}")

    user: Mapped[UserORM | None] = relationship(back_populates="nmr2d_runs")
    analysis: Mapped[AnalysisORM | None] = relationship(back_populates="nmr2d_runs")


class AuditEventORM(Base):
    __tablename__ = "audit_events"
    __table_args__ = (
        Index("ix_audit_events_created", "created_at"),
        Index("ix_audit_events_type_created", "event_type", "created_at"),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
    event_type: Mapped[str] = mapped_column(String(64), index=True)
    message: Mapped[str] = mapped_column(Text)
    actor_user_id: Mapped[int | None] = mapped_column(ForeignKey("users.id", ondelete="SET NULL"), nullable=True, index=True)
    actor_email: Mapped[str | None] = mapped_column(String(255), nullable=True, index=True)
    entity_type: Mapped[str | None] = mapped_column(String(64), nullable=True)
    entity_id: Mapped[int | None] = mapped_column(Integer, nullable=True, index=True)
    metadata_json: Mapped[str] = mapped_column(Text, default="{}")

    actor_user: Mapped[UserORM | None] = relationship(back_populates="audit_events")


class AppMetricDailyORM(Base):
    __tablename__ = "app_metrics_daily"
    __table_args__ = (UniqueConstraint("metric_date", name="uq_app_metrics_daily_date"),)

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    metric_date: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow, index=True)
    analyses_count: Mapped[int] = mapped_column(Integer, default=0)
    jobs_count: Mapped[int] = mapped_column(Integer, default=0)
    reviews_count: Mapped[int] = mapped_column(Integer, default=0)
    overrides_count: Mapped[int] = mapped_column(Integer, default=0)
    hours_saved_estimate: Mapped[float] = mapped_column(Float, default=0.0)
