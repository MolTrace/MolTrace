from __future__ import annotations

import csv
import io
import json
import math
import re
from pathlib import Path
from typing import Any

from .nmr2d_models import NMR2DContourPoint, NMR2DExperiment, NMR2DPeak, NMR2DPreview

_FLOAT_RE = re.compile(r"[-+]?\d*\.?\d+(?:[eE][-+]?\d+)?")
_H_MIN, _H_MAX = -2.5, 16.5
_C_MIN, _C_MAX = -10.0, 240.0
_EXPERIMENT_ALIASES = {
    "cosy": "COSY",
    "1h-1h": "COSY",
    "h-h": "COSY",
    "hsqc": "HSQC",
    "hmqc": "HMQC",
    "hmbc": "HMBC",
}


class NMR2DParseError(ValueError):
    pass


def _safe_float(value: Any) -> float | None:
    if value is None:
        return None
    try:
        parsed = float(str(value).strip())
    except (TypeError, ValueError):
        return None
    return parsed if math.isfinite(parsed) else None


def _norm_key(value: str) -> str:
    return re.sub(r"[^a-z0-9]+", "", value.strip().lower())


def _normalize_experiment(value: Any, *, filename: str = "", fallback: str | None = None) -> NMR2DExperiment | None:
    text = str(value or fallback or filename or "").strip().lower()
    for key, label in _EXPERIMENT_ALIASES.items():
        if key in text:
            return label  # type: ignore[return-value]
    return None


def _sniff_delimiter(text: str, filename: str) -> str:
    if filename.lower().endswith(".tsv"):
        return "\t"
    sample = "\n".join(text.splitlines()[:10])
    try:
        return csv.Sniffer().sniff(sample, delimiters=",\t;").delimiter
    except Exception:
        return "\t" if "\t" in sample else (";" if ";" in sample else ",")


def _rows_from_upload(filename: str, content: bytes) -> list[dict[str, Any]]:
    text = content.decode("utf-8", errors="replace").lstrip("\ufeff")
    if not text.strip():
        raise NMR2DParseError("2D NMR upload is empty.")
    suffix = Path(filename.lower()).suffix
    if suffix == ".json":
        try:
            payload = json.loads(text)
        except json.JSONDecodeError as exc:
            raise NMR2DParseError("Invalid JSON 2D NMR peak table.") from exc
        if isinstance(payload, dict):
            payload = payload.get("peaks") or payload.get("cross_peaks") or payload.get("points")
        if not isinstance(payload, list):
            raise NMR2DParseError("2D NMR JSON must be a list or an object with peaks/cross_peaks.")
        return [row for row in payload if isinstance(row, dict)]
    delimiter = _sniff_delimiter(text, filename)
    reader = csv.DictReader(io.StringIO(text), delimiter=delimiter)
    if reader.fieldnames:
        return list(reader)
    rows: list[dict[str, Any]] = []
    for line in text.splitlines():
        values = [float(x) for x in _FLOAT_RE.findall(line)]
        if len(values) >= 2:
            rows.append({"f1": values[0], "f2": values[1], "intensity": values[2] if len(values) > 2 else None})
    return rows


def _row_value(row: dict[str, Any], *keys: str) -> Any:
    normalized = {_norm_key(str(key)): value for key, value in row.items()}
    for key in keys:
        value = normalized.get(_norm_key(key))
        if value not in {None, ""}:
            return value
    return None


def _looks_h(value: float | None) -> bool:
    return value is not None and _H_MIN <= value <= _H_MAX


def _looks_c(value: float | None) -> bool:
    return value is not None and _C_MIN <= value <= _C_MAX and not _looks_h(value)


def _infer_experiment(filename: str, row: dict[str, Any], f1: float, f2: float, hint: str | None) -> NMR2DExperiment:
    explicit = _normalize_experiment(_row_value(row, "experiment", "type", "spectrum"), filename=filename, fallback=hint)
    if explicit:
        return explicit
    if _looks_h(f1) and _looks_h(f2):
        return "COSY"
    if (_looks_h(f1) and _looks_c(f2)) or (_looks_h(f2) and _looks_c(f1)):
        return "HSQC"
    return "COSY"


def _make_peak(filename: str, row: dict[str, Any], experiment_hint: str | None) -> NMR2DPeak | None:
    f1 = _safe_float(_row_value(row, "f1_ppm", "f1", "x_ppm", "x", "h1_ppm", "proton1_ppm", "proton_ppm"))
    f2 = _safe_float(_row_value(row, "f2_ppm", "f2", "y_ppm", "y", "h2_ppm", "carbon_ppm", "c_ppm"))
    if f1 is None or f2 is None:
        return None
    experiment = _infer_experiment(filename, row, f1, f2, experiment_hint)
    intensity = _safe_float(_row_value(row, "intensity", "height", "volume", "amplitude"))
    assignment_raw = _row_value(row, "assignment", "label", "annotation")
    assignment = str(assignment_raw).strip() if assignment_raw not in {None, ""} else None
    notes: list[str] = []
    proton1 = proton2 = carbon = None
    if experiment == "COSY":
        proton1, proton2 = f1, f2
        if abs(f1 - f2) < 0.03:
            notes.append("Near-diagonal COSY peak; review whether this is a diagonal artifact.")
    else:
        if _looks_h(f1) and not _looks_h(f2):
            proton1, carbon = f1, f2
        elif _looks_h(f2) and not _looks_h(f1):
            proton1, carbon = f2, f1
        else:
            notes.append("Could not confidently assign proton/carbon axes from shift ranges.")
    return NMR2DPeak(
        experiment=experiment,
        f1_ppm=round(f1, 4),
        f2_ppm=round(f2, 4),
        intensity=intensity,
        assignment=assignment,
        proton1_ppm=round(proton1, 4) if proton1 is not None else None,
        proton2_ppm=round(proton2, 4) if proton2 is not None else None,
        carbon_ppm=round(carbon, 4) if carbon is not None else None,
        notes=notes,
    )


def parse_processed_2d_nmr(
    filename: str,
    content: bytes,
    *,
    experiment_hint: str | None = None,
    include_contour_preview: bool = False,
    contour_limit: int = 800,
) -> NMR2DPreview:
    rows = _rows_from_upload(filename, content)
    peaks: list[NMR2DPeak] = []
    contour: list[NMR2DContourPoint] = []
    warnings: list[str] = []
    for row in rows:
        peak = _make_peak(filename, row, experiment_hint)
        if peak is None:
            continue
        peaks.append(peak)
        if include_contour_preview and peak.intensity is not None and len(contour) < contour_limit:
            contour.append(NMR2DContourPoint(f1_ppm=peak.f1_ppm, f2_ppm=peak.f2_ppm, intensity=peak.intensity))
    if not peaks:
        raise NMR2DParseError("No valid 2D NMR cross-peaks could be parsed.")
    experiments = sorted({peak.experiment for peak in peaks})
    if len(experiments) > 1:
        warnings.append("Multiple 2D experiment types were detected in one upload; review grouping before final interpretation.")
    warnings.append("Processed 2D peak tables are evidence aids; human review is required for final assignment.")
    return NMR2DPreview(
        filename=filename,
        source_mode="processed_contour_table" if contour else "processed_peak_table",
        experiments=experiments,  # type: ignore[arg-type]
        peak_count=len(peaks),
        peaks=peaks,
        contour_preview=contour,
        warnings=warnings,
        metadata={
            "parser": "processed_2d_peak_table_v1",
            "experiment_hint": experiment_hint or "auto",
            "contour_preview_enabled": include_contour_preview,
            "raw_2d_fid_processing": "not_implemented_guarded_release",
        },
    )
