from __future__ import annotations

import hmac
import importlib.util
import io
import json
import zipfile
from collections.abc import AsyncIterator, Iterator
from contextlib import asynccontextmanager
from dataclasses import dataclass
from datetime import UTC, datetime
from html import escape as html_escape
from pathlib import Path

from fastapi import (
    APIRouter,
    BackgroundTasks,
    Depends,
    FastAPI,
    File,
    Form,
    Header,
    HTTPException,
    Query,
    Request,
    UploadFile,
    status,
)
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import HTMLResponse, StreamingResponse
from fastapi.security import OAuth2PasswordBearer, OAuth2PasswordRequestForm
from pydantic import ValidationError as PydanticValidationError
from sqlalchemy import select
from sqlalchemy.orm import Session, sessionmaker

from .analysis import analyze_inputs, validate_inputs
from .baseline import normalize_baseline_mode
from .carbon13 import (
    Carbon13ParseError,
    analyze_carbon13,
    analyze_carbon13_text,
    carbon13_peaks_from_shift_values,
    parse_carbon13_processed_spectrum,
    parse_carbon13_table,
    parse_carbon13_text,
    refine_carbon13_peaks_with_context,
)
from .chemistry import structure_summary_from_smiles
from .database import (
    audit_event,
    authenticate_user,
    build_evidence_report,
    build_fid_run_report,
    build_project_dashboard,
    compare_sample_analyses,
    consume_user_action_token,
    create_job,
    create_project,
    create_project_sample,
    create_report_from_analysis,
    create_session_factory,
    create_user,
    create_user_action_token,
    create_user_session,
    export_history_csv,
    export_job_csv,
    export_job_json,
    get_admin_system_summary,
    get_analysis_by_id,
    get_full_analysis_by_id,
    get_fid_run_by_id,
    get_raw_archive_by_id_or_sha,
    get_job_by_id,
    get_metrics_summary,
    get_project_by_id,
    get_report_by_id,
    get_sample_detail,
    get_sample_timeline,
    get_user_by_token,
    init_db,
    list_admin_users,
    list_audit_events,
    list_email_outbox,
    list_fid_run_review_decisions,
    list_fid_runs,
    list_fid_runs_for_raw_archive,
    list_job_analyses,
    list_jobs,
    list_project_samples,
    list_projects,
    list_recent_analyses,
    list_review_decisions,
    list_review_queue,
    list_sample_analyses,
    list_sample_reports,
    link_project_sample_analysis,
    mark_user_verified,
    queue_email,
    revoke_all_user_tokens,
    revoke_token,
    save_analysis,
    save_fid_run,
    save_raw_archive_preview,
    set_job_backend_id,
    set_user_admin_status,
    set_user_password,
    submit_review_decision,
    submit_fid_run_review_decision,
)
from .exceptions import StructureParseError
from .export_raw_package import export_raw_fid_analysis_package
from .fid import (
    FIDProcessingError,
    available_fid_presets,
    fid_settings_from_preset,
    normalize_phase_mode,
    process_bruker_1d_zip,
)
from .models import (
    AccessTokenResponse,
    AdminSystemSummary,
    AdminUserRecord,
    AnalysisInputs,
    AnalysisEvidenceReport,
    AnalysisReport,
    AnalysisValidationInputs,
    AsyncJobAccepted,
    AuditEventRecord,
    BatchAnalysisInputs,
    BatchAnalysisReport,
    Carbon13AnalysisReport,
    Carbon13Inputs,
    Carbon13UploadPreview,
    EmailActionRequest,
    EmailOutboxRecord,
    FIDPreviewReport,
    FIDProcessResult,
    FIDProcessingPreset,
    FIDProcessingSettings,
    FIDRunRecord,
    FIDRunReport,
    FIDRunReviewCreate,
    FIDRunReviewDecisionRecord,
    FullStoredAnalysisRecord,
    JobRecord,
    MessageResponse,
    MetricsSummary,
    PasswordResetConfirm,
    ProjectDashboardRecord,
    ProjectCreate,
    ProjectRecord,
    ProjectSampleAnalysisLink,
    ProjectSampleCreate,
    ProjectSampleRecord,
    ProtonEvidenceReport,
    QueueWorkerStatus,
    RawArchiveExportManifest,
    RawArchiveRecord,
    ReviewDecisionCreate,
    ReviewDecisionRecord,
    ReviewQueueItem,
    SampleAnalysisComparison,
    SampleDetailRecord,
    SampleReportsRecord,
    SampleTimelineRecord,
    SpectrumAnalyzeResult,
    SpectrumPreviewReport,
    StoredReportRecord,
    StoredAnalysisRecord,
    TokenActionPreview,
    UserCreate,
    UserLogin,
    UserPublic,
    ValidationReport,
)
from .proton import analyze_proton_evidence
from .queueing import enqueue_job_processing
from .raw_vault import (
    RAW_ARCHIVE_HASH_MISMATCH_MESSAGE,
    RawVaultError,
    build_raw_upload_provenance,
    load_raw_archive_bytes,
    verify_raw_archive_integrity,
    verify_stored_raw_upload,
)
from .settings import Settings, get_settings, validate_startup_settings
from .spectrum import SpectrumParseError, parse_processed_spectrum
from .upload import UploadParseError, parse_batch_upload

router = APIRouter()
oauth2_scheme = OAuth2PasswordBearer(tokenUrl="/auth/token", auto_error=False)


@dataclass(frozen=True)
class AccessContext:
    user: UserPublic | None = None
    system_api_key: bool = False
    raw_token: str | None = None

    @property
    def user_id(self) -> int | None:
        return self.user.id if self.user is not None else None


@dataclass(frozen=True)
class AppStateView:
    session_factory: sessionmaker[Session]
    api_key: str | None
    settings: Settings



def _state(request: Request) -> AppStateView:
    return AppStateView(
        session_factory=request.app.state.session_factory,
        api_key=request.app.state.api_key,
        settings=request.app.state.settings,
    )



def _stream_text(text: str) -> Iterator[bytes]:
    yield text.encode("utf-8")


def _raw_fid_upload_provenance(
    request: Request,
    *,
    filename: str,
    content: bytes,
    content_type: str | None = None,
    user_id: int | None = None,
) -> dict[str, object]:
    try:
        provenance = build_raw_upload_provenance(
            filename=filename,
            content=content,
            storage_dir=_state(request).settings.raw_data_vault_dir,
            max_bytes=_state(request).settings.raw_archive_max_bytes,
            max_files=_state(request).settings.raw_archive_max_files,
            allowed_extensions=_state(request).settings.raw_archive_allowed_extensions,
            immutable=_state(request).settings.raw_archive_immutable,
        )
    except RawVaultError as exc:
        raise HTTPException(
            status_code=400,
            detail=f"Raw FID vault rejected the upload: {exc}",
        ) from exc
    if provenance.get("storage_path"):
        raw_archive = save_raw_archive_preview(
            _state(request).session_factory,
            provenance=provenance,
            user_id=user_id,
            content_type=content_type,
        )
        provenance = dict(provenance)
        provenance["raw_archive_db_id"] = raw_archive.archive.id
        provenance["raw_archive_record"] = raw_archive.archive.model_dump(mode="json")
        provenance["raw_archive_db_already_stored"] = raw_archive.already_stored
    else:
        provenance = dict(provenance)
        warnings = list(provenance.get("warnings") or [])
        warnings.append("Raw archive was inspected without immutable vault storage; no database vault record was created.")
        provenance["warnings"] = warnings
    return provenance


def _metadata_only_raw_fid_provenance(
    request: Request,
    *,
    filename: str,
    content: bytes,
) -> dict[str, object]:
    try:
        provenance = build_raw_upload_provenance(
            filename=filename,
            content=content,
            storage_dir=None,
            max_bytes=_state(request).settings.raw_archive_max_bytes,
            max_files=_state(request).settings.raw_archive_max_files,
            allowed_extensions=_state(request).settings.raw_archive_allowed_extensions,
        )
    except RawVaultError as exc:
        raise HTTPException(
            status_code=400,
            detail=f"Raw FID preview rejected the upload: {exc}",
        ) from exc
    warnings = list(provenance.get("warnings") or [])
    warnings.append(
        "Legacy /fid/preview inspected this archive without permanent raw-vault storage. "
        "Use POST /raw-fid/upload followed by POST /raw-fid/{archive_id}/process for auditable processing."
    )
    provenance["warnings"] = warnings
    provenance["legacy_endpoint"] = "/fid/preview"
    provenance["recommended_workflow"] = "POST /raw-fid/upload then POST /raw-fid/{archive_id}/process"
    return provenance


def _raw_fid_archive_provenance_from_record(archive: RawArchiveRecord) -> dict[str, object]:
    provenance: dict[str, object] = {
        "raw_archive_id": archive.sha256,
        "raw_archive_db_id": archive.id,
        "raw_archive_record": archive.model_dump(mode="json"),
        "original_filename": archive.filename,
        "filename": archive.filename,
        "safe_filename": Path(archive.filename).name,
        "sha256": archive.sha256,
        "byte_size": archive.byte_size,
        "storage_path": archive.storage_path,
        "storage_backend": "local_raw_vault",
        "storage_status": "stored",
        "raw_data_immutable": archive.immutable,
        "raw_bytes_embedded_in_metadata": False,
        "vendor_detected": archive.vendor_detected,
        "dataset_root": archive.dataset_root,
        "required_files_present": archive.required_files_present,
        "files_found": list(archive.files_found),
        "acquisition_metadata": dict(archive.acquisition_metadata),
        "warnings": list(archive.warnings),
        "vault_record": True,
    }
    return provenance


def _raw_fid_user_scope_for_context(context: AccessContext) -> int | None:
    return _user_scope_for_context(context)


def _get_visible_raw_archive(request: Request, archive_id: str, context: AccessContext) -> RawArchiveRecord:
    user_id = _raw_fid_user_scope_for_context(context)
    archive = get_raw_archive_by_id_or_sha(
        _state(request).session_factory,
        archive_id=archive_id,
        user_id=user_id,
    )
    if archive is None:
        raise HTTPException(status_code=404, detail="Raw FID archive not found.")
    return archive


def _raw_archive_integrity(archive: RawArchiveRecord) -> dict[str, object]:
    report = verify_raw_archive_integrity(archive)
    return {
        "available": report.exists,
        "sha256_verified": report.sha256_verified,
        "byte_size_matches": report.byte_size_matches,
        "byte_size": report.actual_byte_size,
        "expected_byte_size": report.expected_byte_size,
        "actual_sha256": report.actual_sha256,
        "expected_sha256": report.expected_sha256,
        "ok": report.ok,
        "warning": report.warning,
        **({"error": report.warning} if report.warning else {}),
    }


def _load_raw_archive_bytes_or_conflict(archive: RawArchiveRecord) -> bytes:
    try:
        return load_raw_archive_bytes(_raw_fid_archive_provenance_from_record(archive))
    except RawVaultError as exc:
        raise HTTPException(
            status_code=409,
            detail=str(exc),
        ) from exc


def _load_raw_archive_bytes_for_request(
    request: Request,
    *,
    context: AccessContext,
    archive: RawArchiveRecord,
    action: str,
) -> bytes:
    try:
        raw_bytes = load_raw_archive_bytes(
            _raw_fid_archive_provenance_from_record(archive),
            require_hash_verification=_state(request).settings.raw_archive_require_hash_verification,
        )
    except RawVaultError as exc:
        is_hash_mismatch = str(exc) == RAW_ARCHIVE_HASH_MISMATCH_MESSAGE
        _audit_raw_fid_event(
            request,
            context=context,
            archive=archive,
            event_type="raw_fid.integrity_failure",
            message=RAW_ARCHIVE_HASH_MISMATCH_MESSAGE
            if is_hash_mismatch
            else "Raw FID archive integrity verification failed.",
            extra={"action": action, "error": str(exc)},
        )
        raise HTTPException(
            status_code=409,
            detail=str(exc),
        ) from exc
    _audit_raw_fid_event(
        request,
        context=context,
        archive=archive,
        event_type="raw_fid.hash_verified",
        message="Raw FID archive SHA-256 hash verified.",
        extra={"action": action, "byte_size": len(raw_bytes)},
    )
    return raw_bytes


def _upload_http_400(exc: Exception, *, operation: str) -> HTTPException:
    if isinstance(exc, PydanticValidationError):
        messages: list[str] = []
        for error in exc.errors()[:3]:
            loc = ".".join(str(item) for item in error.get("loc", ())) or "value"
            messages.append(f"{loc}: {error.get('msg', 'invalid value')}")
        detail = f"{operation} produced data outside the accepted upload range. " + "; ".join(messages)
    else:
        detail = str(exc) or f"{operation} failed."
    return HTTPException(status_code=400, detail=detail)


def _manual_carbon13_peaks_from_json(raw: str | None, *, solvent: str | None) -> list | None:
    if raw is None or not str(raw).strip():
        return None
    try:
        parsed = json.loads(raw)
    except json.JSONDecodeError as exc:
        raise Carbon13ParseError("Reviewed ¹³C peak list must be valid JSON.") from exc
    if isinstance(parsed, dict):
        parsed = parsed.get("peaks")
    if not isinstance(parsed, list):
        raise Carbon13ParseError("Reviewed ¹³C peak list must be a JSON list or an object with a peaks list.")
    shifts: list[float | tuple[float, float | None]] = []
    for item in parsed:
        if isinstance(item, dict):
            raw_shift = item.get("shift_ppm") or item.get("ppm") or item.get("shift") or item.get("delta")
            raw_intensity = item.get("intensity") or item.get("height") or item.get("area")
        elif isinstance(item, (list, tuple)) and item:
            raw_shift = item[0]
            raw_intensity = item[1] if len(item) > 1 else None
        else:
            raw_shift = item
            raw_intensity = None
        try:
            shift = float(str(raw_shift).strip())
        except (TypeError, ValueError):
            continue
        intensity: float | None = None
        if raw_intensity is not None:
            try:
                intensity = float(str(raw_intensity).strip())
            except (TypeError, ValueError):
                intensity = None
        shifts.append((shift, intensity))
    if not shifts:
        raise Carbon13ParseError("Reviewed ¹³C peak list did not contain any valid shifts.")
    return carbon13_peaks_from_shift_values(shifts, solvent=solvent)



def _maybe_record_email(request: Request, *, to_email: str, subject: str, body: str, purpose: str | None = None) -> None:
    state = _state(request)
    if state.settings.email_backend == "console":
        print(json.dumps({"to": to_email, "subject": subject, "body": body, "purpose": purpose}, indent=2))
        return
    queue_email(state.session_factory, to_email=to_email, subject=subject, body=body, purpose=purpose)



def _build_absolute_url(base_url: str, path_and_query: str) -> str:
    return f"{base_url.rstrip('/')}{path_and_query}"


def _pretty_nmr_label_text(text: str | None) -> str:
    return str(text or "").replace("13C", "¹³C").replace("1H", "¹H")


def _render_evidence_report_html(report: AnalysisEvidenceReport) -> str:
    analysis = report.analysis
    structure = report.structure
    peaks = report.parsed_peaks
    review_decisions = report.review_decisions
    audit_events = report.audit_events
    notes = report.confidence_notes
    impurity_candidates = report.impurity_candidates
    peak_rows = "".join(
        f"<tr><td>{html_escape(str(peak.shift_ppm))}</td><td>{html_escape(peak.multiplicity)}</td><td>{html_escape(', '.join(str(v) for v in peak.j_values_hz) or '—')}</td><td>{html_escape(str(peak.integration_h))}</td></tr>"
        for peak in peaks
    )
    notes_html = "".join(f"<li>{html_escape(note)}</li>" for note in notes) or "<li>No notes recorded.</li>"
    impurity_html = "".join(f"<li>{html_escape(note)}</li>" for note in impurity_candidates) or "<li>No likely impurity candidates were preserved in this stored record.</li>"
    decisions_html = "".join(
        f"<tr><td>{html_escape(decision.action)}</td><td>{html_escape(decision.new_status)}</td><td>{html_escape(decision.comment or '—')}</td><td>{html_escape(decision.created_at.isoformat())}</td></tr>"
        for decision in review_decisions
    ) or "<tr><td colspan='4'>No reviewer decisions recorded.</td></tr>"
    audit_html = "".join(
        f"<tr><td>{html_escape(event.event_type)}</td><td>{html_escape(event.message)}</td><td>{html_escape(event.created_at.isoformat())}</td></tr>"
        for event in audit_events
    ) or "<tr><td colspan='3'>No audit events recorded.</td></tr>"
    evidence_confidence_score = 0.0
    evidence_confidence_score += 0.25 if structure.formula else 0.0
    evidence_confidence_score += 0.25 if peaks else 0.0
    evidence_confidence_score += 0.2 if analysis.review_status == "approved" else 0.1
    evidence_confidence_score += min(float(analysis.confidence or 0), 1.0) * 0.3
    evidence_confidence_score = round(min(evidence_confidence_score, 1.0), 2)
    raw_fid_processing = report.audit_metadata.get("raw_fid_processing")
    fid_processing_html = ""
    if isinstance(raw_fid_processing, dict):
        processing_params = raw_fid_processing.get("processing_parameters")
        acquisition_params = raw_fid_processing.get("acquisition_parameters")
        files_found = raw_fid_processing.get("raw_dataset_files_found")
        extracted_peaks = raw_fid_processing.get("extracted_peak_list")
        qa_diagnostics = raw_fid_processing.get("qa_diagnostics")
        fid_rows = [
            ("Vendor format", raw_fid_processing.get("vendor_format_detected")),
            ("Processing preset", raw_fid_processing.get("selected_preset")),
            ("Nucleus", raw_fid_processing.get("nucleus")),
            ("Solvent", raw_fid_processing.get("solvent")),
            ("Reference ppm", raw_fid_processing.get("reference_ppm")),
            (
                "Raw dataset files found",
                json.dumps(files_found, sort_keys=True) if isinstance(files_found, dict) else None,
            ),
            (
                "Digital-filter correction",
                raw_fid_processing.get("digital_filter_correction_status"),
            ),
            ("Group delay correction", raw_fid_processing.get("group_delay_correction_applied")),
            ("Automatic phasing", raw_fid_processing.get("automatic_phase_correction")),
            (
                "Automatic baseline correction",
                raw_fid_processing.get("automatic_baseline_correction"),
            ),
            (
                "FID QA diagnostics",
                json.dumps(qa_diagnostics, sort_keys=True)
                if isinstance(qa_diagnostics, dict)
                else None,
            ),
            ("Reviewer signoff required", raw_fid_processing.get("reviewer_signoff_required")),
            ("Human review status", raw_fid_processing.get("human_review_status")),
            (
                "Extracted peaks",
                len(extracted_peaks) if isinstance(extracted_peaks, list) else None,
            ),
            (
                "Processing parameters",
                json.dumps(processing_params, sort_keys=True)
                if isinstance(processing_params, dict)
                else None,
            ),
            (
                "Acquisition parameters",
                json.dumps(acquisition_params, sort_keys=True)
                if isinstance(acquisition_params, dict)
                else None,
            ),
        ]
        fid_body = "".join(
            f"<tr><td>{html_escape(label)}</td><td>{html_escape(str(value if value is not None else '—'))}</td></tr>"
            for label, value in fid_rows
        )
        fid_processing_html = f"""
      <section class="card">
        <h2 style="margin-top:0;">Raw FID processing assumptions</h2>
        <table>
          <tbody>{fid_body}</tbody>
        </table>
      </section>"""
    return f"""<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>NMRCheck Evidence Report #{analysis.id}</title>
    <style>
      body {{ font-family: Inter, Arial, sans-serif; margin: 0; background: #f6f8fc; color: #172033; }}
      main {{ max-width: 1100px; margin: 0 auto; padding: 1.5rem; }}
      .hero {{ background: linear-gradient(135deg,#173a9a 0%,#2855d9 70%,#6a88ff 100%); color: white; border-radius: 22px; padding: 1.25rem 1.4rem; }}
      .grid {{ display: grid; grid-template-columns: repeat(auto-fit, minmax(180px, 1fr)); gap: .8rem; margin-top: 1rem; }}
      .card {{ background: white; border: 1px solid #dce2ee; border-radius: 16px; padding: 1rem; margin-top: 1rem; }}
      .metric {{ border: 1px solid #dce2ee; border-radius: 14px; padding: .8rem; background: #fff; }}
      .label {{ color: #5d6b82; font-size: .82rem; text-transform: uppercase; }}
      .value {{ margin-top: .35rem; font-size: 1.1rem; font-weight: 700; }}
      table {{ width: 100%; border-collapse: collapse; }}
      th, td {{ text-align: left; padding: .6rem .55rem; border-bottom: 1px solid #dce2ee; }}
      th {{ background: #f5f7fc; color: #5d6b82; }}
      code, pre {{ background: #0e1528; color: #d8e0ff; border-radius: 12px; padding: .8rem; display: block; overflow: auto; }}
    </style>
  </head>
  <body>
    <main>
      <section class="hero">
        <h1 style="margin:0 0 .35rem;">Evidence Report</h1>
        <p style="margin:.2rem 0 0;">Analysis #{analysis.id} · {html_escape(analysis.sample_id or 'Unlabeled sample')} · {html_escape(analysis.label)}</p>
      </section>
      <section class="grid">
        <div class="metric"><div class="label">Sample ID</div><div class="value">{html_escape(analysis.sample_id or '—')}</div></div>
        <div class="metric"><div class="label">Solvent</div><div class="value">{html_escape(analysis.solvent or '—')}</div></div>
        <div class="metric"><div class="label">Review status</div><div class="value">{html_escape(analysis.review_status)}</div></div>
        <div class="metric"><div class="label">Confidence</div><div class="value">{html_escape(str(analysis.confidence))}</div></div>
        <div class="metric"><div class="label">Time saved</div><div class="value">{html_escape(str(report.time_saved_estimate))} h</div></div>
        <div class="metric"><div class="label">Formula</div><div class="value">{html_escape(structure.formula)}</div></div>
      </section>
      <section class="card">
        <h2 style="margin-top:0;">Parsed ¹H NMR text</h2>
        <pre>{html_escape(_pretty_nmr_label_text(report.parsed_nmr_text))}</pre>
      </section>
      <section class="card">
        <h2 style="margin-top:0;">Structure summary</h2>
        <div class="grid">
          <div class="metric"><div class="label">Molecular weight</div><div class="value">{html_escape(str(structure.molecular_weight))}</div></div>
          <div class="metric"><div class="label">Total H</div><div class="value">{html_escape(str(structure.total_hydrogens))}</div></div>
          <div class="metric"><div class="label">Non-labile H</div><div class="value">{html_escape(str(structure.non_labile_hydrogens))}</div></div>
          <div class="metric"><div class="label">Aromatic H</div><div class="value">{html_escape(str(structure.aromatic_protons))}</div></div>
          <div class="metric"><div class="label">Aliphatic H</div><div class="value">{html_escape(str(structure.aliphatic_protons))}</div></div>
        </div>
      </section>
      <section class="card">
        <h2 style="margin-top:0;">Evidence confidence</h2>
        <div class="grid">
          <div class="metric"><div class="label">Confidence score</div><div class="value">{html_escape(str(evidence_confidence_score))}</div></div>
          <div class="metric"><div class="label">Structure parsed</div><div class="value">{html_escape('yes' if structure.formula else 'no')}</div></div>
          <div class="metric"><div class="label">NMR evidence parsed</div><div class="value">{html_escape('yes' if peaks else 'no')}</div></div>
          <div class="metric"><div class="label">Review status</div><div class="value">{html_escape(analysis.review_status)}</div></div>
          <div class="metric"><div class="label">Reviewer decisions</div><div class="value">{html_escape(str(len(review_decisions)))}</div></div>
        </div>
      </section>
      <section class="card">
        <h2 style="margin-top:0;">Matched peak list</h2>
        <table>
          <thead><tr><th>Shift (ppm)</th><th>Multiplicity</th><th>J values (Hz)</th><th>Integration</th></tr></thead>
          <tbody>{peak_rows or "<tr><td colspan='4'>No peaks available.</td></tr>"}</tbody>
        </table>
      </section>
      <section class="card">
        <h2 style="margin-top:0;">Confidence notes</h2>
        <ul>{notes_html}</ul>
      </section>
      {fid_processing_html}
      <section class="card">
        <h2 style="margin-top:0;">Unmatched / impurity candidates</h2>
        <ul>{impurity_html}</ul>
      </section>
      <section class="card">
        <h2 style="margin-top:0;">Reviewer decisions</h2>
        <table>
          <thead><tr><th>Action</th><th>Status</th><th>Comment</th><th>Created</th></tr></thead>
          <tbody>{decisions_html}</tbody>
        </table>
      </section>
      <section class="card">
        <h2 style="margin-top:0;">Audit trail</h2>
        <table>
          <thead><tr><th>Event</th><th>Message</th><th>Created</th></tr></thead>
          <tbody>{audit_html}</tbody>
        </table>
      </section>
    </main>
  </body>
</html>"""


def _render_fid_run_report_html(report: FIDRunReport) -> str:
    run = report.run
    metadata = run.processing_metadata
    qa = report.qa_diagnostics
    decision_rows = "".join(
        f"<tr><td>{html_escape(decision.action)}</td><td>{html_escape(decision.previous_status)}</td><td>{html_escape(decision.new_status)}</td><td>{html_escape(decision.comment or '—')}</td><td>{html_escape(decision.created_at.isoformat())}</td></tr>"
        for decision in report.review_decisions
    ) or "<tr><td colspan='5'>No FID-run reviewer decisions recorded.</td></tr>"
    peak_rows = "".join(
        f"<tr><td>{html_escape(str(peak.shift_ppm))}</td><td>{html_escape(peak.multiplicity)}</td><td>{html_escape(', '.join(str(v) for v in peak.j_values_hz) or '—')}</td><td>{html_escape(str(peak.integration_h))}</td></tr>"
        for peak in report.inferred_peak_list
    ) or "<tr><td colspan='4'>No peaks inferred.</td></tr>"
    provenance_rows = "".join(
        f"<tr><td>{html_escape(str(key))}</td><td>{html_escape(json.dumps(value, sort_keys=True) if isinstance(value, dict) else str(value))}</td></tr>"
        for key, value in report.raw_fid_provenance.items()
    )
    assumption_rows = "".join(
        f"<tr><td>{html_escape(str(key))}</td><td>{html_escape(json.dumps(value, sort_keys=True) if isinstance(value, dict) else str(value))}</td></tr>"
        for key, value in report.processing_assumptions.items()
    )
    qa_rows = "".join(
        f"<tr><td>{html_escape(label)}</td><td>{html_escape(str(value))}</td></tr>"
        for label, value in [
            ("Quality label", qa.quality_label),
            ("Quality score", qa.quality_score),
            ("Dynamic range", qa.dynamic_range),
            ("Noise estimate", qa.noise_estimate),
            ("Baseline offset ratio", qa.baseline_offset_ratio),
            ("Clipping proxy", qa.saturation_clipping_proxy),
            ("Point count", qa.point_count),
            ("Warnings", "; ".join(qa.warnings) or "—"),
        ]
    )
    reference_selection = json.dumps(metadata.reference_peak_selection, sort_keys=True)
    fid_evidence_confidence = round(
        min(
            1.0,
            float(qa.quality_score or 0) * 0.55
            + (0.2 if report.inferred_peak_list else 0.0)
            + (0.15 if run.review_status == "approved" else 0.05)
            + min(len(report.review_decisions), 2) * 0.05,
        ),
        2,
    )
    return f"""<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>NMRCheck FID Run Report #{run.id}</title>
    <style>
      body {{ font-family: Inter, Arial, sans-serif; margin: 0; background: #f6f8fc; color: #172033; }}
      main {{ max-width: 1100px; margin: 0 auto; padding: 1.5rem; }}
      .hero {{ background: #173a9a; color: white; border-radius: 18px; padding: 1.2rem 1.4rem; }}
      .grid {{ display: grid; grid-template-columns: repeat(auto-fit, minmax(180px, 1fr)); gap: .8rem; margin-top: 1rem; }}
      .card {{ background: white; border: 1px solid #dce2ee; border-radius: 12px; padding: 1rem; margin-top: 1rem; }}
      .metric {{ border: 1px solid #dce2ee; border-radius: 10px; padding: .8rem; background: #fff; }}
      .label {{ color: #5d6b82; font-size: .82rem; text-transform: uppercase; }}
      .value {{ margin-top: .35rem; font-size: 1.1rem; font-weight: 700; }}
      table {{ width: 100%; border-collapse: collapse; }}
      th, td {{ text-align: left; padding: .6rem .55rem; border-bottom: 1px solid #dce2ee; vertical-align: top; }}
      th {{ background: #f5f7fc; color: #5d6b82; }}
      pre {{ background: #0e1528; color: #d8e0ff; border-radius: 10px; padding: .8rem; overflow: auto; }}
    </style>
  </head>
  <body>
    <main>
      <section class="hero">
        <h1 style="margin:0 0 .35rem;">FID Run Evidence Report</h1>
        <p style="margin:.2rem 0 0;">Run #{run.id} · {html_escape(run.sample_id or 'Unlabeled sample')} · {html_escape(run.review_status)}</p>
      </section>
      <section class="grid">
        <div class="metric"><div class="label">Preset</div><div class="value">{html_escape(run.selected_preset)}</div></div>
        <div class="metric"><div class="label">Quality</div><div class="value">{html_escape(run.quality_label)}</div></div>
        <div class="metric"><div class="label">Review status</div><div class="value">{html_escape(run.review_status)}</div></div>
        <div class="metric"><div class="label">Reviewer</div><div class="value">{html_escape(str(run.reviewer_user_id or '—'))}</div></div>
        <div class="metric"><div class="label">Reviewed</div><div class="value">{html_escape(run.reviewed_at.isoformat() if run.reviewed_at else '—')}</div></div>
        <div class="metric"><div class="label">Decisions</div><div class="value">{html_escape(str(len(report.review_decisions)))}</div></div>
      </section>
      <section class="card">
        <h2 style="margin-top:0;">Reviewer comment</h2>
        <p>{html_escape(run.reviewer_comment or 'No reviewer comment recorded.')}</p>
      </section>
      <section class="card">
        <h2 style="margin-top:0;">Evidence confidence</h2>
        <div class="grid">
          <div class="metric"><div class="label">Confidence score</div><div class="value">{html_escape(str(fid_evidence_confidence))}</div></div>
          <div class="metric"><div class="label">Peak evidence</div><div class="value">{html_escape(str(len(report.inferred_peak_list)))}</div></div>
          <div class="metric"><div class="label">QA score</div><div class="value">{html_escape(str(qa.quality_score))}</div></div>
          <div class="metric"><div class="label">Review status</div><div class="value">{html_escape(run.review_status)}</div></div>
          <div class="metric"><div class="label">Reviewer decisions</div><div class="value">{html_escape(str(len(report.review_decisions)))}</div></div>
        </div>
      </section>
      <section class="card">
        <h2 style="margin-top:0;">Raw FID provenance</h2>
        <table><tbody>{provenance_rows}</tbody></table>
      </section>
      <section class="card">
        <h2 style="margin-top:0;">Processing assumptions</h2>
        <table><tbody>{assumption_rows}<tr><td>Single reference peak</td><td>{html_escape(reference_selection)}</td></tr></tbody></table>
      </section>
      <section class="card">
        <h2 style="margin-top:0;">QA diagnostics</h2>
        <table><tbody>{qa_rows}</tbody></table>
      </section>
      <section class="card">
        <h2 style="margin-top:0;">Inferred peak list</h2>
        <table>
          <thead><tr><th>Shift (ppm)</th><th>Multiplicity</th><th>J values (Hz)</th><th>Integration</th></tr></thead>
          <tbody>{peak_rows}</tbody>
        </table>
      </section>
      <section class="card">
        <h2 style="margin-top:0;">Reviewer decisions</h2>
        <table>
          <thead><tr><th>Action</th><th>Previous</th><th>New</th><th>Comment</th><th>Created</th></tr></thead>
          <tbody>{decision_rows}</tbody>
        </table>
      </section>
      <section class="card">
        <h2 style="margin-top:0;">Generated ¹H NMR text</h2>
        <pre>{html_escape(_pretty_nmr_label_text(run.preview.inferred_nmr_text or 'No generated peak text.'))}</pre>
      </section>
    </main>
  </body>
</html>"""


def _build_fid_run_package(report: FIDRunReport) -> tuple[bytes, bool]:
    metadata = report.run.processing_metadata
    provenance = dict(metadata.raw_upload_provenance)
    original_available = verify_stored_raw_upload(provenance)
    manifest = RawArchiveExportManifest(
        exported_at=datetime.now(UTC),
        raw_archive=provenance.get("raw_archive_record"),
        raw_archive_id=provenance.get("raw_archive_id"),
        sha256=provenance.get("sha256"),
        original_filename=provenance.get("original_filename") or provenance.get("filename"),
        storage_backend=provenance.get("storage_backend"),
        include_original_archive=original_available,
        sha256_verified=original_available,
        files=["analysis.json", "processing_metadata.json", "raw_upload_provenance.json"],
        warnings=list(provenance.get("warnings") or []),
    )
    buffer = io.BytesIO()
    original_included = False
    with zipfile.ZipFile(buffer, mode="w", compression=zipfile.ZIP_DEFLATED) as archive:
        archive.writestr(
            "analysis.json",
            json.dumps(report.model_dump(mode="json"), indent=2, sort_keys=True),
        )
        archive.writestr(
            "processing_metadata.json",
            json.dumps(metadata.model_dump(mode="json"), indent=2, sort_keys=True),
        )
        archive.writestr(
            "raw_upload_provenance.json",
            json.dumps(provenance, indent=2, sort_keys=True),
        )
        archive.writestr(
            "raw_archive_export_manifest.json",
            json.dumps(manifest.model_dump(mode="json"), indent=2, sort_keys=True),
        )
        archive.writestr(
            "README.txt",
            "\n".join(
                [
                    "NMRCheck raw FID evidence package",
                    "",
                    "The original raw FID archive is content-addressed by SHA-256.",
                    "Processing, phase correction, baseline correction, peak picking, and review decisions are derivative metadata.",
                    "The application does not overwrite the uploaded raw binary archive.",
                    "",
                    f"Raw SHA-256: {provenance.get('sha256') or 'not recorded'}",
                    f"Original included: {'yes' if original_available else 'no'}",
                ]
            ),
        )
        if original_available:
            path = Path(str(provenance["storage_path"])).expanduser()
            safe_name = str(provenance.get("safe_filename") or path.name)
            archive.write(path, f"original/{safe_name}")
            original_included = True
        else:
            archive.writestr(
                "original/RAW_UPLOAD_NOT_EMBEDDED.txt",
                "The original archive was not available in local immutable storage for this export. "
                "Use raw_upload_provenance.json to verify the expected SHA-256 and object key.",
            )
    return (buffer.getvalue(), original_included)


def _build_raw_archive_export_package(
    archive: RawArchiveRecord,
    *,
    latest_report: FIDRunReport | None,
    audit_trail: list[AuditEventRecord] | None = None,
    original_archive_bytes: bytes | None = None,
    original_archive_error: str | None = None,
) -> tuple[bytes, bool]:
    warnings = list(archive.warnings)
    if original_archive_error:
        warnings.append(original_archive_error)
    if original_archive_bytes is None and original_archive_error is None:
        try:
            original_archive_bytes = _load_raw_archive_bytes_or_conflict(archive)
        except HTTPException as exc:
            warnings.append(str(exc.detail))
    original_included = original_archive_bytes is not None
    run = latest_report.run if latest_report is not None else None
    analysis_payload = (
        latest_report.model_dump(mode="json")
        if latest_report is not None
        else {
            "raw_archive_id": archive.sha256,
            "message": "No derived FID processing run is available for this raw archive yet.",
        }
    )
    payload, _manifest = export_raw_fid_analysis_package(
        raw_archive=archive,
        original_archive_bytes=original_archive_bytes,
        original_filename=archive.filename,
        analysis=analysis_payload,
        processing_recipe=run.processing_recipe if run is not None else {},
        acquisition_metadata=archive.acquisition_metadata,
        peak_list=run.processing_metadata.extracted_peak_list if run is not None else [],
        spectrum_preview=run.preview if run is not None else {},
        evidence_report=latest_report
        or {
            "raw_archive": archive.model_dump(mode="json"),
            "processing_run_available": False,
        },
        audit_trail=audit_trail or [],
        warnings=warnings,
    )
    return payload, original_included


def _raw_archive_audit_trail(
    request: Request,
    *,
    context: AccessContext,
    archive: RawArchiveRecord,
    limit: int = 500,
) -> list[AuditEventRecord]:
    actor_user_id = _raw_fid_user_scope_for_context(context)
    events = list_audit_events(
        _state(request).session_factory,
        limit=limit,
        actor_user_id=actor_user_id,
    )
    return [
        event
        for event in events
        if event.metadata.get("raw_archive_id") == archive.sha256
        or event.metadata.get("sha256") == archive.sha256
        or event.metadata.get("raw_archive_db_id") == archive.id
    ]


async def get_optional_access_context(
    request: Request,
    x_api_key: str | None = Header(default=None, alias="x-api-key"),
    bearer_token: str | None = Depends(oauth2_scheme),
    access_token: str | None = Query(default=None, alias="access_token"),
) -> AccessContext | None:
    state = _state(request)
    if x_api_key is not None:
        if state.api_key and hmac.compare_digest(x_api_key, state.api_key):
            return AccessContext(system_api_key=True)
        raise HTTPException(status_code=401, detail="Invalid API key.")
    token_value = bearer_token or access_token
    if token_value:
        user = get_user_by_token(state.session_factory, token_value)
        if user is None:
            raise HTTPException(status_code=401, detail="Invalid or expired bearer token.")
        return AccessContext(user=user, raw_token=token_value)
    return None


async def require_access_context(context: AccessContext | None = Depends(get_optional_access_context)) -> AccessContext:
    if context is None:
        raise HTTPException(status_code=401, detail="Authentication required.")
    return context


async def require_authenticated_user(context: AccessContext = Depends(require_access_context)) -> UserPublic:
    if context.user is None:
        raise HTTPException(status_code=403, detail="A user bearer token is required for this endpoint.")
    return context.user


def _estimate_hours_saved(settings: Settings, *, parsed_peak_count: int) -> float:
    baseline_minutes = settings.default_analysis_minutes_saved
    if parsed_peak_count <= 0:
        return round(settings.default_validation_minutes_saved / 60.0, 2)
    scaled = baseline_minutes + min(parsed_peak_count, 12) * 0.25
    return round(scaled / 60.0, 2)


def _spectrum_structure_targets(smiles: str | None) -> tuple[int | None, int | None]:
    if smiles is None:
        return (None, None)
    candidate = smiles.strip()
    if not candidate:
        return (None, None)
    try:
        summary = structure_summary_from_smiles(candidate)
    except StructureParseError:
        return (None, None)
    return (summary.total_hydrogens, summary.non_labile_hydrogens)


def _validation_detail(errors: list[str]) -> str | list[str]:
    if not errors:
        return "Invalid analysis input."
    if len(errors) == 1:
        return errors[0]
    return errors


def _ensure_analysis_inputs_valid(payload: AnalysisInputs) -> ValidationReport:
    validation = validate_inputs(payload)
    if validation.errors or not validation.analysis_ready:
        errors = validation.errors or [
            "SMILES and ¹H NMR text must both validate and correspond before analysis."
        ]
        raise HTTPException(status_code=400, detail=_validation_detail(errors))
    return validation


def _ensure_batch_inputs_valid(items: list[AnalysisInputs]) -> None:
    failures: list[dict[str, object]] = []
    for index, item in enumerate(items):
        validation = validate_inputs(item)
        if validation.errors or not validation.analysis_ready:
            failures.append(
                {
                    "item_index": index,
                    "sample_id": item.sample_id,
                    "errors": validation.errors
                    or [
                        "SMILES and ¹H NMR text must both validate and correspond before analysis."
                    ],
                }
            )
    if failures:
        raise HTTPException(status_code=400, detail=failures)


def _audit_from_context(
    request: Request,
    *,
    context: AccessContext | None,
    event_type: str,
    message: str,
    entity_type: str | None = None,
    entity_id: int | None = None,
    metadata: dict[str, object] | None = None,
) -> None:
    actor_user_id = context.user.id if context and context.user else None
    actor_email = context.user.email if context and context.user else None
    audit_event(
        _state(request).session_factory,
        event_type=event_type,
        message=message,
        actor_user_id=actor_user_id,
        actor_email=actor_email,
        entity_type=entity_type,
        entity_id=entity_id,
        metadata=metadata,
    )


def _raw_fid_audit_metadata(
    archive: RawArchiveRecord,
    context: AccessContext,
    *,
    processing_run_id: int | None = None,
    extra: dict[str, object] | None = None,
) -> dict[str, object]:
    metadata: dict[str, object] = {
        "raw_archive_id": archive.sha256,
        "raw_archive_db_id": archive.id,
        "sha256": archive.sha256,
        "user_id": context.user_id,
        "filename": archive.filename,
        "vendor_detected": archive.vendor_detected,
        "processing_run_id": processing_run_id,
        "timestamp": datetime.now(UTC).isoformat(),
    }
    if extra:
        metadata.update(extra)
    return metadata


def _audit_raw_fid_event(
    request: Request,
    *,
    context: AccessContext,
    archive: RawArchiveRecord,
    event_type: str,
    message: str,
    entity_type: str = "raw_archive",
    entity_id: int | None = None,
    processing_run_id: int | None = None,
    extra: dict[str, object] | None = None,
) -> None:
    _audit_from_context(
        request,
        context=context,
        event_type=event_type,
        message=message,
        entity_type=entity_type,
        entity_id=archive.id if entity_id is None else entity_id,
        metadata=_raw_fid_audit_metadata(
            archive,
            context,
            processing_run_id=processing_run_id,
            extra=extra,
        ),
    )


def _user_scope_for_context(context: AccessContext) -> int | None:
    if context.system_api_key:
        return None
    if context.user is not None and context.user.is_admin:
        return None
    return context.user_id


def _health_response(request: Request | None = None) -> dict[str, object]:
    checks: dict[str, str] = {"app": "ok"}
    if request is not None:
        try:
            with _state(request).session_factory() as session:
                session.execute(select(1))
            checks["database"] = "ok"
        except Exception as exc:
            checks["database"] = f"error: {exc}"
    status_value = "ok" if all(value == "ok" for value in checks.values()) else "degraded"
    return {"status": status_value, "checks": checks}


def health() -> dict[str, object]:
    return _health_response()


@router.get("/health")
def health_route(request: Request) -> dict[str, object]:
    return _health_response(request)


async def require_admin(
    context: AccessContext = Depends(require_access_context),
) -> AccessContext:
    if context.system_api_key:
        return context
    if context.user is None or not context.user.is_admin:
        raise HTTPException(status_code=403, detail="Admin access required.")
    return context


@router.get("/queue/status", response_model=QueueWorkerStatus)
def queue_status(request: Request) -> QueueWorkerStatus:
    state = _state(request)
    return QueueWorkerStatus(
        backend="rq" if state.settings.redis_url else "fastapi-background",
        redis_configured=state.settings.redis_url is not None,
        queue_name=state.settings.queue_name,
        detail="RQ will be used when REDIS_URL is configured; otherwise FastAPI background tasks are used.",
    )


@router.post("/auth/register", response_model=UserPublic, status_code=status.HTTP_201_CREATED)
def register(payload: UserCreate, request: Request) -> UserPublic:
    state = _state(request)
    try:
        user = create_user(
            state.session_factory,
            email=payload.email,
            password=payload.password,
            is_verified=not state.settings.require_verified_email,
            is_admin=state.settings.is_admin_email(payload.email),
        )
    except ValueError as exc:
        raise HTTPException(status_code=409, detail=str(exc)) from exc

    if state.settings.require_verified_email:
        token_pair = create_user_action_token(
            state.session_factory,
            email=payload.email,
            purpose="verify_email",
            ttl_minutes=state.settings.email_verification_ttl_minutes,
        )
        if token_pair is not None:
            token, _expires_at = token_pair
            verification_link = _build_absolute_url(state.settings.base_url, f"/auth/verify-email?token={token}")
            _maybe_record_email(
                request,
                to_email=payload.email,
                subject="Verify your NMRCheck account",
                body=f"Use this link to verify your account: {verification_link}",
                purpose="verify_email",
            )
    _audit_from_context(request, context=AccessContext(user=user), event_type="auth.register", message="User registered.", entity_type="user", entity_id=user.id)
    return user


@router.post("/auth/login", response_model=AccessTokenResponse)
def login_json(payload: UserLogin, request: Request) -> AccessTokenResponse:
    state = _state(request)
    user = authenticate_user(
        state.session_factory,
        email=payload.email,
        password=payload.password,
        require_verified=state.settings.require_verified_email,
    )
    if user is None:
        raise HTTPException(status_code=401, detail="Incorrect email or password, or email not verified.")
    if state.settings.is_admin_email(user.email) and not user.is_admin:
        user = set_user_admin_status(state.session_factory, user_id=user.id, is_admin=True)
    token, expires_at = create_user_session(
        state.session_factory,
        user_id=user.id,
        ttl_minutes=state.settings.access_token_ttl_minutes,
    )
    _audit_from_context(request, context=AccessContext(user=user), event_type="auth.login", message="User logged in.", entity_type="user", entity_id=user.id)
    return AccessTokenResponse(access_token=token, expires_at=expires_at, user=user)


@router.post("/auth/token", response_model=AccessTokenResponse)
def login_form(request: Request, form_data: OAuth2PasswordRequestForm = Depends()) -> AccessTokenResponse:
    state = _state(request)
    user = authenticate_user(
        state.session_factory,
        email=form_data.username,
        password=form_data.password,
        require_verified=state.settings.require_verified_email,
    )
    if user is None:
        raise HTTPException(status_code=401, detail="Incorrect username or password, or email not verified.")
    if state.settings.is_admin_email(user.email) and not user.is_admin:
        user = set_user_admin_status(state.session_factory, user_id=user.id, is_admin=True)
    token, expires_at = create_user_session(
        state.session_factory,
        user_id=user.id,
        ttl_minutes=state.settings.access_token_ttl_minutes,
    )
    _audit_from_context(request, context=AccessContext(user=user), event_type="auth.login", message="User logged in via OAuth2 form.", entity_type="user", entity_id=user.id)
    return AccessTokenResponse(access_token=token, expires_at=expires_at, user=user)


@router.get("/auth/me", response_model=UserPublic)
def auth_me(user: UserPublic = Depends(require_authenticated_user)) -> UserPublic:
    return user


@router.post("/auth/logout", response_model=MessageResponse)
def auth_logout(request: Request, context: AccessContext = Depends(require_access_context)) -> MessageResponse:
    if context.raw_token is not None:
        revoke_token(_state(request).session_factory, context.raw_token)
    return MessageResponse(detail="Logged out.")


@router.post("/auth/request-email-verification", response_model=TokenActionPreview)
def request_email_verification(payload: EmailActionRequest, request: Request) -> TokenActionPreview:
    state = _state(request)
    token_pair = create_user_action_token(
        state.session_factory,
        email=payload.email,
        purpose="verify_email",
        ttl_minutes=state.settings.email_verification_ttl_minutes,
    )
    if token_pair is None:
        return TokenActionPreview(detail="If the account exists, a verification email has been queued.")
    token, expires_at = token_pair
    verification_link = _build_absolute_url(state.settings.base_url, f"/auth/verify-email?token={token}")
    _maybe_record_email(
        request,
        to_email=payload.email,
        subject="Verify your NMRCheck account",
        body=f"Use this link to verify your account: {verification_link}",
        purpose="verify_email",
    )
    preview_token = token if state.settings.app_env != "production" else None
    return TokenActionPreview(
        detail="If the account exists, a verification email has been queued.",
        token=preview_token,
        expires_at=expires_at,
    )


@router.get("/auth/verify-email", response_model=MessageResponse)
def verify_email(token: str, request: Request) -> MessageResponse:
    user = consume_user_action_token(_state(request).session_factory, token=token, purpose="verify_email")
    if user is None:
        raise HTTPException(status_code=400, detail="Verification token is invalid or expired.")
    mark_user_verified(_state(request).session_factory, user_id=user.id)
    return MessageResponse(detail="Email verified successfully.")


@router.post("/auth/request-password-reset", response_model=TokenActionPreview)
def request_password_reset(payload: EmailActionRequest, request: Request) -> TokenActionPreview:
    state = _state(request)
    token_pair = create_user_action_token(
        state.session_factory,
        email=payload.email,
        purpose="reset_password",
        ttl_minutes=state.settings.password_reset_ttl_minutes,
    )
    if token_pair is None:
        return TokenActionPreview(detail="If the account exists, a password reset email has been queued.")
    token, expires_at = token_pair
    reset_link = _build_absolute_url(state.settings.base_url, f"/reset-password?token={token}")
    _maybe_record_email(
        request,
        to_email=payload.email,
        subject="Reset your NMRCheck password",
        body=f"Use this link to reset your password: {reset_link}",
        purpose="reset_password",
    )
    preview_token = token if state.settings.app_env != "production" else None
    return TokenActionPreview(
        detail="If the account exists, a password reset email has been queued.",
        token=preview_token,
        expires_at=expires_at,
    )


@router.post("/auth/reset-password", response_model=MessageResponse)
def reset_password(payload: PasswordResetConfirm, request: Request) -> MessageResponse:
    state = _state(request)
    user = consume_user_action_token(state.session_factory, token=payload.token, purpose="reset_password")
    if user is None:
        raise HTTPException(status_code=400, detail="Reset token is invalid or expired.")
    set_user_password(state.session_factory, user_id=user.id, new_password=payload.new_password)
    revoke_all_user_tokens(state.session_factory, user.id)
    return MessageResponse(detail="Password reset successful. Existing sessions have been revoked.")


@router.get("/auth/outbox", response_model=list[EmailOutboxRecord], dependencies=[Depends(require_access_context)])
def auth_outbox(request: Request, limit: int = Query(default=20, ge=1, le=200)) -> list[EmailOutboxRecord]:
    state = _state(request)
    if state.settings.app_env == "production":
        raise HTTPException(status_code=404, detail="Not found.")
    return list_email_outbox(state.session_factory, limit=limit)


@router.post("/analyze/validate", response_model=ValidationReport, dependencies=[Depends(require_access_context)])
def validate(payload: AnalysisValidationInputs) -> ValidationReport:
    return validate_inputs(payload)


@router.post("/analyze", response_model=AnalysisReport, dependencies=[Depends(require_access_context)])
def analyze(
    payload: AnalysisInputs,
    request: Request,
    context: AccessContext = Depends(require_access_context),
) -> AnalysisReport:
    _ensure_analysis_inputs_valid(payload)
    report = analyze_inputs(payload)
    hours_saved = _estimate_hours_saved(_state(request).settings, parsed_peak_count=report.parsed_peak_count)
    analysis_id = save_analysis(_state(request).session_factory, report, payload, user_id=context.user_id, hours_saved_estimate=hours_saved)
    _audit_from_context(request, context=context, event_type="analysis.run", message="Single analysis completed.", entity_type="analysis", entity_id=analysis_id, metadata={"hours_saved_estimate": hours_saved})
    return report


@router.post("/analyze/batch", response_model=BatchAnalysisReport, dependencies=[Depends(require_access_context)])
def analyze_batch(
    payload: BatchAnalysisInputs,
    request: Request,
    context: AccessContext = Depends(require_access_context),
) -> BatchAnalysisReport:
    _ensure_batch_inputs_valid(payload.items)
    reports: list[AnalysisReport] = []
    session_factory = _state(request).session_factory
    for item in payload.items:
        report = analyze_inputs(item)
        save_analysis(session_factory, report, item, user_id=context.user_id, hours_saved_estimate=_estimate_hours_saved(_state(request).settings, parsed_peak_count=report.parsed_peak_count))
        reports.append(report)
    _audit_from_context(request, context=context, event_type="analysis.batch", message="Batch analysis completed.", metadata={"items": len(reports)})
    return BatchAnalysisReport(items=reports, total_items=len(reports))


@router.post("/analyze/upload", response_model=BatchAnalysisReport, dependencies=[Depends(require_access_context)])
async def analyze_upload(
    request: Request,
    file: UploadFile = File(...),
    context: AccessContext = Depends(require_access_context),
) -> BatchAnalysisReport:
    content = await file.read()
    filename = file.filename or "batch.json"
    try:
        payload = parse_batch_upload(filename=filename, content=content)
    except UploadParseError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    _ensure_batch_inputs_valid(payload.items)
    session_factory = _state(request).session_factory
    reports: list[AnalysisReport] = []
    for item in payload.items:
        report = analyze_inputs(item)
        save_analysis(session_factory, report, item, user_id=context.user_id, hours_saved_estimate=_estimate_hours_saved(_state(request).settings, parsed_peak_count=report.parsed_peak_count))
        reports.append(report)
    return BatchAnalysisReport(items=reports, total_items=len(reports))




@router.post("/spectrum/preview", response_model=SpectrumPreviewReport, dependencies=[Depends(require_access_context)])
async def spectrum_preview(
    request: Request,
    file: UploadFile = File(...),
    smiles: str | None = Form(default=None),
    solvent: str | None = Form(default=None),
    frequency_mhz: float | None = Form(default=None),
    reference_ppm: float | None = Form(default=None),
    reference_nmr_text: str | None = Form(default=None),
    peak_sensitivity: float | None = Form(default=None),
    mask_solvent_regions: bool = Form(default=False),
    display_mode: str = Form(default="real"),
    vertical_gain: float = Form(default=1.0),
    debug_preview: bool = Form(default=False),
    processed_baseline_correction: str = Form(default="none"),
    processed_baseline_order: int = Form(default=3),
    context: AccessContext = Depends(require_access_context),
) -> SpectrumPreviewReport:
    filename = file.filename or "spectrum.dat"
    content = await file.read()
    expected_total_h, expected_non_labile_h = _spectrum_structure_targets(smiles)
    display_mode_value = _unwrap_form_default(display_mode)
    vertical_gain_value = _coerce_optional_form_float(vertical_gain, default=1.0)
    debug_preview_value = _coerce_optional_form_bool(debug_preview, default=False)
    try:
        preview = parse_processed_spectrum(
            filename=filename,
            content=content,
            solvent=solvent,
            frequency_mhz=frequency_mhz,
            reference_ppm=reference_ppm,
            reference_nmr_text=reference_nmr_text,
            peak_sensitivity=peak_sensitivity,
            mask_solvent_regions=mask_solvent_regions,
            expected_total_h=expected_total_h,
            expected_non_labile_h=expected_non_labile_h,
            display_mode=display_mode_value,
            vertical_gain=vertical_gain_value,
            debug_preview=debug_preview_value,
            processed_baseline_correction=_unwrap_form_default(processed_baseline_correction),
            processed_baseline_order=int(_unwrap_form_default(processed_baseline_order) or 3),
        )
    except (SpectrumParseError, PydanticValidationError, ValueError) as exc:
        raise _upload_http_400(exc, operation="Processed spectrum preview") from exc
    _audit_from_context(
        request,
        context=context,
        event_type="spectrum.preview",
        message="Processed spectrum preview generated.",
        metadata={
            "filename": filename,
            "format": preview.format_detected,
            "mode": preview.source_mode,
            "peak_sensitivity": peak_sensitivity,
            "mask_solvent_regions": mask_solvent_regions,
            "display_mode": display_mode_value,
            "debug_preview": debug_preview_value,
            "reference_text_supplied": bool(reference_nmr_text and reference_nmr_text.strip()),
        },
    )
    return preview


@router.post("/spectrum/analyze", response_model=SpectrumAnalyzeResult, dependencies=[Depends(require_access_context)])
async def spectrum_analyze(
    request: Request,
    file: UploadFile = File(...),
    smiles: str = Form(...),
    sample_id: str | None = Form(default=None),
    solvent: str | None = Form(default=None),
    frequency_mhz: float | None = Form(default=None),
    reference_ppm: float | None = Form(default=None),
    reference_nmr_text: str | None = Form(default=None),
    manual_nmr_text: str | None = Form(default=None),
    peak_sensitivity: float | None = Form(default=None),
    mask_solvent_regions: bool = Form(default=False),
    display_mode: str = Form(default="real"),
    vertical_gain: float = Form(default=1.0),
    debug_preview: bool = Form(default=False),
    processed_baseline_correction: str = Form(default="none"),
    processed_baseline_order: int = Form(default=3),
    context: AccessContext = Depends(require_access_context),
) -> SpectrumAnalyzeResult:
    filename = file.filename or "spectrum.dat"
    content = await file.read()
    expected_total_h, expected_non_labile_h = _spectrum_structure_targets(smiles)
    display_mode_value = _unwrap_form_default(display_mode)
    vertical_gain_value = _coerce_optional_form_float(vertical_gain, default=1.0)
    debug_preview_value = _coerce_optional_form_bool(debug_preview, default=False)
    try:
        preview = parse_processed_spectrum(
            filename=filename,
            content=content,
            solvent=solvent,
            frequency_mhz=frequency_mhz,
            reference_ppm=reference_ppm,
            reference_nmr_text=reference_nmr_text,
            peak_sensitivity=peak_sensitivity,
            mask_solvent_regions=mask_solvent_regions,
            expected_total_h=expected_total_h,
            expected_non_labile_h=expected_non_labile_h,
            display_mode=display_mode_value,
            vertical_gain=vertical_gain_value,
            debug_preview=debug_preview_value,
            processed_baseline_correction=_unwrap_form_default(processed_baseline_correction),
            processed_baseline_order=int(_unwrap_form_default(processed_baseline_order) or 3),
        )
    except (SpectrumParseError, PydanticValidationError, ValueError) as exc:
        raise _upload_http_400(exc, operation="Processed spectrum analysis") from exc

    reviewed_nmr_text = (
        manual_nmr_text.strip()
        if manual_nmr_text is not None and manual_nmr_text.strip()
        else preview.inferred_nmr_text
    )
    if not reviewed_nmr_text.strip():
        raise HTTPException(
            status_code=400,
            detail="Raw FID processing did not infer any peaks; review FID QA diagnostics before processing.",
        )
    generated_inputs = AnalysisInputs(
        sample_id=sample_id,
        smiles=smiles,
        nmr_text=reviewed_nmr_text,
        solvent=solvent,
    )
    _ensure_analysis_inputs_valid(generated_inputs)
    report = analyze_inputs(generated_inputs)
    combined_notes = list(report.notes)
    if reviewed_nmr_text != preview.inferred_nmr_text:
        combined_notes.insert(
            0,
            "Reviewer-adjusted peak acceptance/exclusion decisions were used for the final processed-spectrum analysis.",
        )
    for warning in preview.warnings:
        if warning not in combined_notes:
            combined_notes.append(warning)
    report = report.model_copy(update={"notes": combined_notes})
    hours_saved = _estimate_hours_saved(_state(request).settings, parsed_peak_count=report.parsed_peak_count)
    analysis_id = save_analysis(_state(request).session_factory, report, generated_inputs, user_id=context.user_id, hours_saved_estimate=hours_saved)
    _audit_from_context(
        request,
        context=context,
        event_type="spectrum.analyze",
        message="Processed spectrum analyzed through inferred peak list.",
        entity_type="analysis",
        entity_id=analysis_id,
        metadata={
            "filename": filename,
            "format": preview.format_detected,
            "mode": preview.source_mode,
            "hours_saved_estimate": hours_saved,
            "peak_sensitivity": peak_sensitivity,
            "mask_solvent_regions": mask_solvent_regions,
            "reference_text_supplied": bool(reference_nmr_text and reference_nmr_text.strip()),
            "manual_nmr_text_supplied": reviewed_nmr_text != preview.inferred_nmr_text,
        },
    )
    return SpectrumAnalyzeResult(preview=preview, generated_inputs=generated_inputs, analysis=report)


def _unwrap_form_default(value: Any) -> Any:
    return getattr(value, "default", value)


def _coerce_optional_form_bool(value: Any, *, default: bool) -> bool:
    value = _unwrap_form_default(value)
    if isinstance(value, bool):
        return value
    if isinstance(value, str):
        normalized = value.strip().lower()
        if normalized in {"1", "true", "yes", "on"}:
            return True
        if normalized in {"0", "false", "no", "off"}:
            return False
    return default


def _coerce_optional_form_float(value: Any, *, default: float) -> float:
    value = _unwrap_form_default(value)
    try:
        return float(value)
    except (TypeError, ValueError):
        return default


def _coerce_display_mode(value: Any) -> str:
    value = _unwrap_form_default(value)
    normalized = str(value or "real").strip().lower().replace("-", "_").replace(" ", "_")
    if normalized in {"weak_peak_magnifier", "weak_peak_magnifier_view"}:
        return "magnifier"
    return normalized if normalized in {"real", "magnifier"} else "real"


def _fid_settings_from_form(
    *,
    selected_preset: str | None,
    processing_preset: str | None,
    zero_fill_factor: int | None,
    line_broadening_hz: float | None,
    apodization_mode: str = "exponential",
    apply_group_delay: bool,
    auto_phase: bool,
    auto_baseline: bool,
    phase_mode: str,
    phase_p0: float,
    phase_p1: float,
    baseline_correction: str,
    baseline_order: int,
    baseline_lock: bool | None,
    peak_sensitivity: float | None,
    mask_solvent_regions: bool,
    display_mode: str = "real",
    vertical_gain: float = 1.0,
    debug_preview: bool = False,
) -> FIDProcessingSettings:
    display_mode = _coerce_display_mode(display_mode)
    apply_group_delay = _coerce_optional_form_bool(apply_group_delay, default=True)
    auto_phase = _coerce_optional_form_bool(auto_phase, default=True)
    auto_baseline = _coerce_optional_form_bool(auto_baseline, default=True)
    mask_solvent_regions = _coerce_optional_form_bool(mask_solvent_regions, default=True)
    phase_mode = normalize_phase_mode(_unwrap_form_default(phase_mode))
    apodization_mode = _unwrap_form_default(apodization_mode) or "exponential"
    phase_p0 = _coerce_optional_form_float(phase_p0, default=0.0)
    phase_p1 = _coerce_optional_form_float(phase_p1, default=0.0)
    baseline_correction = normalize_baseline_mode(_unwrap_form_default(baseline_correction))
    try:
        baseline_order = max(1, min(8, int(_unwrap_form_default(baseline_order))))
    except (TypeError, ValueError):
        baseline_order = 3
    vertical_gain = _coerce_optional_form_float(vertical_gain, default=1.0)
    debug_preview = _coerce_optional_form_bool(debug_preview, default=False)
    processing_preset = _unwrap_form_default(processing_preset)
    baseline_lock = _unwrap_form_default(baseline_lock)
    effective_preset = processing_preset or selected_preset
    baseline_lock_visual_only = (
        _coerce_optional_form_bool(baseline_lock, default=True)
        if baseline_lock is not None
        else True
    )
    return fid_settings_from_preset(
        selected_preset=effective_preset,
        zero_fill_factor=zero_fill_factor,
        apodization_mode=apodization_mode,
        line_broadening_hz=line_broadening_hz,
        apply_group_delay=apply_group_delay,
        auto_phase=auto_phase,
        auto_baseline=auto_baseline,
        phase_mode=phase_mode,
        phase_p0=phase_p0,
        phase_p1=phase_p1,
        baseline_correction=baseline_correction,
        baseline_order=baseline_order,
        baseline_lock_visual_only=baseline_lock_visual_only,
        peak_sensitivity=peak_sensitivity,
        mask_solvent_regions=mask_solvent_regions,
        display_mode=display_mode,
        vertical_gain=vertical_gain,
        debug_preview=debug_preview,
    )


def _fid_processing_notes(preview: FIDPreviewReport, *, manual_review_used: bool) -> list[str]:
    metadata = preview.processing_metadata
    peak_text = ", ".join(
        f"{peak.shift_ppm:.2f} ppm/{peak.integration_h:g}H"
        for peak in metadata.extracted_peak_list[:12]
    )
    files_found = ", ".join(
        f"{name}={'yes' if present else 'no'}"
        for name, present in sorted(metadata.raw_dataset_files_found.items())
    )
    notes = [
        f"Raw FID beta source detected as {metadata.vendor_format_detected}.",
        f"FID processing preset: {metadata.selected_preset}.",
        f"Raw dataset files found: {files_found or 'not recorded'}.",
        f"FID processing parameters: zero_fill_factor={metadata.processing_parameters.get('zero_fill_factor')}, line_broadening_hz={metadata.processing_parameters.get('line_broadening_hz')}.",
        f"FID QA result: {metadata.qa_diagnostics.quality_label} ({metadata.qa_diagnostics.quality_score:g}).",
        f"Group delay correction applied: {'yes' if metadata.group_delay_correction_applied else 'no'}.",
        f"Automatic phasing: {'yes' if metadata.automatic_phase_correction else 'no'}; automatic baseline correction: {'yes' if metadata.automatic_baseline_correction else 'no'}.",
        f"Reference ppm used: {metadata.reference_ppm if metadata.reference_ppm is not None else 'not supplied'}.",
        f"Solvent context used for FID processing: {metadata.solvent or 'not supplied'}.",
        f"Raw FID extracted peak list: {peak_text or 'no peaks inferred'}.",
        f"Human review status: {metadata.human_review_status}.",
        "Human reviewer signoff is required because raw FID processing can change spectrum appearance.",
    ]
    if manual_review_used:
        notes.insert(0, "Reviewer-adjusted peak acceptance/exclusion decisions were used for the final raw FID-derived analysis.")
    for warning in preview.warnings:
        if warning not in notes:
            notes.append(warning)
    return notes


@router.get("/fid/presets", response_model=list[FIDProcessingPreset])
def fid_presets() -> list[FIDProcessingPreset]:
    return available_fid_presets()


@router.post("/raw-fid/upload", response_model=RawArchiveRecord, dependencies=[Depends(require_access_context)])
async def raw_fid_upload(
    request: Request,
    file: UploadFile = File(...),
    context: AccessContext = Depends(require_access_context),
) -> RawArchiveRecord:
    filename = file.filename or "raw_fid_archive.zip"
    content = await file.read()
    provenance = _raw_fid_upload_provenance(
        request,
        filename=filename,
        content=content,
        content_type=file.content_type,
        user_id=context.user_id,
    )
    record_payload = provenance.get("raw_archive_record")
    if not isinstance(record_payload, dict):
        raise HTTPException(status_code=500, detail="Raw FID vault storage is not configured.")
    archive = RawArchiveRecord.model_validate(record_payload)
    _audit_raw_fid_event(
        request,
        context=context,
        archive=archive,
        event_type="raw_fid.uploaded",
        message="Raw FID archive uploaded to immutable vault.",
        extra={
            "byte_size": archive.byte_size,
            "content_type": file.content_type,
        },
    )
    _audit_raw_fid_event(
        request,
        context=context,
        archive=archive,
        event_type="raw_fid.hash_verified",
        message="Raw FID archive SHA-256 hash verified after upload.",
        extra={"action": "upload", "byte_size": archive.byte_size},
    )
    _audit_raw_fid_event(
        request,
        context=context,
        archive=archive,
        event_type="raw_fid.metadata_extracted",
        message="Raw FID acquisition metadata extracted from immutable upload.",
        extra={
            "dataset_root": archive.dataset_root,
            "required_files_present": archive.required_files_present,
            "acquisition_metadata_keys": sorted(archive.acquisition_metadata.keys()),
        },
    )
    return archive


@router.get("/raw-fid/{archive_id}", dependencies=[Depends(require_access_context)])
def raw_fid_archive_detail(
    archive_id: str,
    request: Request,
    context: AccessContext = Depends(require_access_context),
) -> dict[str, object]:
    archive = _get_visible_raw_archive(request, archive_id, context)
    integrity = _raw_archive_integrity(archive)
    if integrity.get("sha256_verified"):
        _audit_raw_fid_event(
            request,
            context=context,
            archive=archive,
            event_type="raw_fid.hash_verified",
            message="Raw FID archive SHA-256 hash verified during metadata lookup.",
            extra={"action": "metadata_lookup"},
        )
    else:
        _audit_raw_fid_event(
            request,
            context=context,
            archive=archive,
            event_type="raw_fid.integrity_failure",
            message="Raw FID archive integrity check failed during metadata lookup.",
            extra={"action": "metadata_lookup", "error": str(integrity.get("error") or "unknown")},
        )
    return {
        "archive": archive.model_dump(mode="json"),
        "integrity": integrity,
        "raw_bytes_returned": False,
    }


@router.get("/raw-fid/{archive_id}/download", dependencies=[Depends(require_access_context)])
def raw_fid_archive_download(
    archive_id: str,
    request: Request,
    context: AccessContext = Depends(require_access_context),
) -> StreamingResponse:
    archive = _get_visible_raw_archive(request, archive_id, context)
    raw_bytes = _load_raw_archive_bytes_for_request(
        request,
        context=context,
        archive=archive,
        action="download",
    )
    headers = {
        "Content-Disposition": f'attachment; filename="{Path(archive.filename).name or "raw_fid_archive"}"'
    }
    return StreamingResponse(io.BytesIO(raw_bytes), media_type="application/octet-stream", headers=headers)


@router.post("/raw-fid/{archive_id}/preview", response_model=FIDPreviewReport, dependencies=[Depends(require_access_context)])
def raw_fid_archive_preview(
    archive_id: str,
    request: Request,
    sample_id: str | None = Form(default=None),
    solvent: str | None = Form(default=None),
    nucleus: str = Form(default="1H"),
    reference_ppm: float | None = Form(default=None),
    smiles: str | None = Form(default=None),
    reference_nmr_text: str | None = Form(default=None),
    selected_preset: str | None = Form(default="balanced"),
    processing_preset: str | None = Form(default=None),
    zero_fill_factor: int | None = Form(default=None),
    line_broadening_hz: float | None = Form(default=None),
    apodization_mode: str = Form(default="exponential"),
    apply_group_delay: bool = Form(default=True),
    auto_phase: bool = Form(default=True),
    auto_baseline: bool = Form(default=True),
    phase_mode: str = Form(default="auto"),
    phase_p0: float = Form(default=0.0),
    phase_p1: float = Form(default=0.0),
    baseline_correction: str = Form(default="bernstein"),
    baseline_order: int = Form(default=3),
    baseline_lock: bool | None = Form(default=None),
    peak_sensitivity: float | None = Form(default=None),
    mask_solvent_regions: bool = Form(default=True),
    display_mode: str = Form(default="real"),
    vertical_gain: float = Form(default=1.0),
    debug_preview: bool = Form(default=False),
    save_run: bool = Form(default=False),
    context: AccessContext = Depends(require_access_context),
) -> FIDPreviewReport:
    archive = _get_visible_raw_archive(request, archive_id, context)
    raw_bytes = _load_raw_archive_bytes_for_request(
        request,
        context=context,
        archive=archive,
        action="preview",
    )
    expected_total_h, expected_non_labile_h = _spectrum_structure_targets(smiles)
    settings = _fid_settings_from_form(
        selected_preset=selected_preset,
        processing_preset=processing_preset,
        zero_fill_factor=zero_fill_factor,
        line_broadening_hz=line_broadening_hz,
        apodization_mode=apodization_mode,
        apply_group_delay=apply_group_delay,
        auto_phase=auto_phase,
        auto_baseline=auto_baseline,
        phase_mode=phase_mode,
        phase_p0=phase_p0,
        phase_p1=phase_p1,
        baseline_correction=baseline_correction,
        baseline_order=baseline_order,
        baseline_lock=baseline_lock,
        peak_sensitivity=peak_sensitivity,
        mask_solvent_regions=mask_solvent_regions,
        display_mode=display_mode,
        vertical_gain=vertical_gain,
        debug_preview=debug_preview,
    )
    try:
        preview = process_bruker_1d_zip(
            filename=archive.filename,
            content=raw_bytes,
            solvent=solvent,
            nucleus=nucleus,
            reference_ppm=reference_ppm,
            reference_nmr_text=reference_nmr_text,
            settings=settings,
            expected_total_h=expected_total_h,
            expected_non_labile_h=expected_non_labile_h,
            raw_upload_provenance=_raw_fid_archive_provenance_from_record(archive),
        )
    except (FIDProcessingError, PydanticValidationError, ValueError) as exc:
        raise _upload_http_400(exc, operation="Raw FID vault preview") from exc
    if save_run:
        fid_run = save_fid_run(
            _state(request).session_factory,
            preview,
            user_id=context.user_id,
            analysis_id=None,
            sample_id=sample_id,
        )
        preview = fid_run.preview
    _audit_raw_fid_event(
        request,
        context=context,
        archive=archive,
        event_type="raw_fid.previewed",
        message="Immutable raw FID archive previewed without modifying the archive.",
        processing_run_id=preview.fid_run_id,
        extra={"save_run": save_run},
    )
    return preview


@router.post("/raw-fid/{archive_id}/process", response_model=FIDProcessResult, dependencies=[Depends(require_access_context)])
def raw_fid_archive_process(
    archive_id: str,
    request: Request,
    smiles: str = Form(...),
    sample_id: str | None = Form(default=None),
    solvent: str | None = Form(default=None),
    nucleus: str = Form(default="1H"),
    reference_ppm: float | None = Form(default=None),
    reference_nmr_text: str | None = Form(default=None),
    manual_nmr_text: str | None = Form(default=None),
    selected_preset: str | None = Form(default="balanced"),
    processing_preset: str | None = Form(default=None),
    zero_fill_factor: int | None = Form(default=None),
    line_broadening_hz: float | None = Form(default=None),
    apodization_mode: str = Form(default="exponential"),
    apply_group_delay: bool = Form(default=True),
    auto_phase: bool = Form(default=True),
    auto_baseline: bool = Form(default=True),
    phase_mode: str = Form(default="auto"),
    phase_p0: float = Form(default=0.0),
    phase_p1: float = Form(default=0.0),
    baseline_correction: str = Form(default="bernstein"),
    baseline_order: int = Form(default=3),
    baseline_lock: bool | None = Form(default=None),
    peak_sensitivity: float | None = Form(default=None),
    mask_solvent_regions: bool = Form(default=True),
    display_mode: str = Form(default="real"),
    vertical_gain: float = Form(default=1.0),
    debug_preview: bool = Form(default=False),
    context: AccessContext = Depends(require_access_context),
) -> FIDProcessResult:
    archive = _get_visible_raw_archive(request, archive_id, context)
    raw_bytes = _load_raw_archive_bytes_for_request(
        request,
        context=context,
        archive=archive,
        action="process",
    )
    expected_total_h, expected_non_labile_h = _spectrum_structure_targets(smiles)
    settings = _fid_settings_from_form(
        selected_preset=selected_preset,
        processing_preset=processing_preset,
        zero_fill_factor=zero_fill_factor,
        line_broadening_hz=line_broadening_hz,
        apodization_mode=apodization_mode,
        apply_group_delay=apply_group_delay,
        auto_phase=auto_phase,
        auto_baseline=auto_baseline,
        phase_mode=phase_mode,
        phase_p0=phase_p0,
        phase_p1=phase_p1,
        baseline_correction=baseline_correction,
        baseline_order=baseline_order,
        baseline_lock=baseline_lock,
        peak_sensitivity=peak_sensitivity,
        mask_solvent_regions=mask_solvent_regions,
        display_mode=display_mode,
        vertical_gain=vertical_gain,
        debug_preview=debug_preview,
    )
    try:
        preview = process_bruker_1d_zip(
            filename=archive.filename,
            content=raw_bytes,
            solvent=solvent,
            nucleus=nucleus,
            reference_ppm=reference_ppm,
            reference_nmr_text=reference_nmr_text,
            settings=settings,
            expected_total_h=expected_total_h,
            expected_non_labile_h=expected_non_labile_h,
            raw_upload_provenance=_raw_fid_archive_provenance_from_record(archive),
        )
    except (FIDProcessingError, PydanticValidationError, ValueError) as exc:
        raise _upload_http_400(exc, operation="Raw FID vault processing") from exc
    reviewed_nmr_text = (
        manual_nmr_text.strip()
        if manual_nmr_text is not None and manual_nmr_text.strip()
        else preview.inferred_nmr_text
    )
    generated_inputs = AnalysisInputs(
        sample_id=sample_id,
        smiles=smiles,
        nmr_text=reviewed_nmr_text,
        solvent=solvent,
    )
    _ensure_analysis_inputs_valid(generated_inputs)
    report = analyze_inputs(generated_inputs)
    combined_notes = list(report.notes)
    for note in reversed(_fid_processing_notes(preview, manual_review_used=reviewed_nmr_text != preview.inferred_nmr_text)):
        if note not in combined_notes:
            combined_notes.insert(0, note)
    report = report.model_copy(update={"notes": combined_notes})
    hours_saved = _estimate_hours_saved(_state(request).settings, parsed_peak_count=report.parsed_peak_count)
    analysis_id = save_analysis(
        _state(request).session_factory,
        report,
        generated_inputs,
        user_id=context.user_id,
        hours_saved_estimate=hours_saved,
    )
    fid_run = save_fid_run(
        _state(request).session_factory,
        preview,
        user_id=context.user_id,
        analysis_id=analysis_id,
        sample_id=sample_id,
    )
    preview = fid_run.preview
    _audit_raw_fid_event(
        request,
        context=context,
        archive=archive,
        event_type="raw_fid.processed",
        message="Immutable raw FID archive processed into an analysis.",
        entity_type="fid_run",
        entity_id=fid_run.id,
        processing_run_id=fid_run.id,
        extra={
            "analysis_id": analysis_id,
            "manual_nmr_text_supplied": reviewed_nmr_text != preview.inferred_nmr_text,
        },
    )
    return FIDProcessResult(preview=preview, generated_inputs=generated_inputs, analysis=report)


@router.get("/raw-fid/{archive_id}/runs", response_model=list[FIDRunRecord], dependencies=[Depends(require_access_context)])
def raw_fid_archive_runs(
    archive_id: str,
    request: Request,
    context: AccessContext = Depends(require_access_context),
    limit: int = Query(default=100, ge=1, le=500),
) -> list[FIDRunRecord]:
    archive = _get_visible_raw_archive(request, archive_id, context)
    return list_fid_runs_for_raw_archive(
        _state(request).session_factory,
        raw_archive_id=archive.id,
        raw_sha256=archive.sha256,
        limit=limit,
        user_id=_raw_fid_user_scope_for_context(context),
    )


@router.get("/raw-fid/{archive_id}/export", dependencies=[Depends(require_access_context)])
def raw_fid_archive_export(
    archive_id: str,
    request: Request,
    context: AccessContext = Depends(require_access_context),
) -> StreamingResponse:
    archive = _get_visible_raw_archive(request, archive_id, context)
    user_id = _raw_fid_user_scope_for_context(context)
    runs = list_fid_runs_for_raw_archive(
        _state(request).session_factory,
        raw_archive_id=archive.id,
        raw_sha256=archive.sha256,
        limit=1,
        user_id=user_id,
    )
    latest_report = None
    if runs:
        latest_report = build_fid_run_report(
            _state(request).session_factory,
            run_id=runs[0].id,
            user_id=user_id,
        )
    original_archive_bytes = _load_raw_archive_bytes_for_request(
        request,
        context=context,
        archive=archive,
        action="export",
    )
    _audit_raw_fid_event(
        request,
        context=context,
        archive=archive,
        event_type="raw_fid.exported",
        message="Raw FID archive evidence export generated.",
        processing_run_id=runs[0].id if runs else None,
        extra={"latest_run_id": runs[0].id if runs else None},
    )
    audit_trail = _raw_archive_audit_trail(
        request,
        context=context,
        archive=archive,
    )
    payload, original_included = _build_raw_archive_export_package(
        archive,
        latest_report=latest_report,
        audit_trail=audit_trail,
        original_archive_bytes=original_archive_bytes,
    )
    headers = {
        "Content-Disposition": f'attachment; filename="raw-fid-{archive.sha256[:12]}-export.zip"'
    }
    return StreamingResponse(io.BytesIO(payload), media_type="application/zip", headers=headers)


@router.post("/fid/preview", response_model=FIDPreviewReport, dependencies=[Depends(require_access_context)])
async def fid_preview(
    request: Request,
    file: UploadFile = File(...),
    sample_id: str | None = Form(default=None),
    workspace_sample_record_id: int | None = Form(default=None),
    solvent: str | None = Form(default=None),
    nucleus: str = Form(default="1H"),
    reference_ppm: float | None = Form(default=None),
    smiles: str | None = Form(default=None),
    reference_nmr_text: str | None = Form(default=None),
    selected_preset: str | None = Form(default="balanced"),
    processing_preset: str | None = Form(default=None),
    zero_fill_factor: int | None = Form(default=None),
    line_broadening_hz: float | None = Form(default=None),
    apodization_mode: str = Form(default="exponential"),
    apply_group_delay: bool = Form(default=True),
    auto_phase: bool = Form(default=True),
    auto_baseline: bool = Form(default=True),
    phase_mode: str = Form(default="auto"),
    phase_p0: float = Form(default=0.0),
    phase_p1: float = Form(default=0.0),
    baseline_correction: str = Form(default="bernstein"),
    baseline_order: int = Form(default=3),
    baseline_lock: bool | None = Form(default=None),
    peak_sensitivity: float | None = Form(default=None),
    mask_solvent_regions: bool = Form(default=True),
    display_mode: str = Form(default="real"),
    vertical_gain: float = Form(default=1.0),
    debug_preview: bool = Form(default=False),
    context: AccessContext = Depends(require_access_context),
) -> FIDPreviewReport:
    filename = file.filename or "bruker_dataset.zip"
    content = await file.read()
    raw_upload_provenance = _metadata_only_raw_fid_provenance(
        request,
        filename=filename,
        content=content,
    )
    expected_total_h, expected_non_labile_h = _spectrum_structure_targets(smiles)
    settings = _fid_settings_from_form(
        selected_preset=selected_preset,
        processing_preset=processing_preset,
        zero_fill_factor=zero_fill_factor,
        line_broadening_hz=line_broadening_hz,
        apodization_mode=apodization_mode,
        apply_group_delay=apply_group_delay,
        auto_phase=auto_phase,
        auto_baseline=auto_baseline,
        phase_mode=phase_mode,
        phase_p0=phase_p0,
        phase_p1=phase_p1,
        baseline_correction=baseline_correction,
        baseline_order=baseline_order,
        baseline_lock=baseline_lock,
        peak_sensitivity=peak_sensitivity,
        mask_solvent_regions=mask_solvent_regions,
        display_mode=display_mode,
        vertical_gain=vertical_gain,
        debug_preview=debug_preview,
    )
    try:
        preview = process_bruker_1d_zip(
            filename=filename,
            content=content,
            solvent=solvent,
            nucleus=nucleus,
            reference_ppm=reference_ppm,
            reference_nmr_text=reference_nmr_text,
            settings=settings,
            expected_total_h=expected_total_h,
            expected_non_labile_h=expected_non_labile_h,
            raw_upload_provenance=raw_upload_provenance,
        )
    except (FIDProcessingError, PydanticValidationError, ValueError) as exc:
        raise _upload_http_400(exc, operation="Raw FID preview") from exc
    _audit_from_context(
        request,
        context=context,
        event_type="fid.preview.legacy",
        message="Legacy raw FID beta preview generated without permanent vault storage or run creation.",
        metadata={
            "filename": filename,
            "sample_id": sample_id,
            "workspace_sample_record_id": workspace_sample_record_id,
            "reference_text_supplied": bool(reference_nmr_text and reference_nmr_text.strip()),
            "fid_processing": preview.processing_metadata.model_dump(mode="json"),
            "legacy_endpoint": "/fid/preview",
            "recommended_workflow": "POST /raw-fid/upload then POST /raw-fid/{archive_id}/process",
        },
    )
    return preview


@router.post("/fid/process", response_model=FIDProcessResult, dependencies=[Depends(require_access_context)])
async def fid_process(
    request: Request,
    file: UploadFile = File(...),
    smiles: str = Form(...),
    sample_id: str | None = Form(default=None),
    workspace_project_id: int | None = Form(default=None),
    workspace_sample_record_id: int | None = Form(default=None),
    solvent: str | None = Form(default=None),
    nucleus: str = Form(default="1H"),
    reference_ppm: float | None = Form(default=None),
    reference_nmr_text: str | None = Form(default=None),
    manual_nmr_text: str | None = Form(default=None),
    selected_preset: str | None = Form(default="balanced"),
    processing_preset: str | None = Form(default=None),
    zero_fill_factor: int | None = Form(default=None),
    line_broadening_hz: float | None = Form(default=None),
    apodization_mode: str = Form(default="exponential"),
    apply_group_delay: bool = Form(default=True),
    auto_phase: bool = Form(default=True),
    auto_baseline: bool = Form(default=True),
    phase_mode: str = Form(default="auto"),
    phase_p0: float = Form(default=0.0),
    phase_p1: float = Form(default=0.0),
    baseline_correction: str = Form(default="bernstein"),
    baseline_order: int = Form(default=3),
    baseline_lock: bool | None = Form(default=None),
    peak_sensitivity: float | None = Form(default=None),
    mask_solvent_regions: bool = Form(default=True),
    display_mode: str = Form(default="real"),
    vertical_gain: float = Form(default=1.0),
    debug_preview: bool = Form(default=False),
    context: AccessContext = Depends(require_access_context),
) -> FIDProcessResult:
    filename = file.filename or "bruker_dataset.zip"
    content = await file.read()
    raw_upload_provenance = _raw_fid_upload_provenance(
        request,
        filename=filename,
        content=content,
        content_type=file.content_type,
        user_id=context.user_id,
    )
    raw_upload_provenance = dict(raw_upload_provenance)
    legacy_warnings = list(raw_upload_provenance.get("warnings") or [])
    legacy_warnings.append(
        "Legacy /fid/process stored this upload in the immutable raw vault before processing. "
        "Prefer POST /raw-fid/upload followed by POST /raw-fid/{archive_id}/process for explicit provenance."
    )
    raw_upload_provenance["warnings"] = legacy_warnings
    raw_upload_provenance["legacy_endpoint"] = "/fid/process"
    raw_upload_provenance["recommended_workflow"] = "POST /raw-fid/upload then POST /raw-fid/{archive_id}/process"
    expected_total_h, expected_non_labile_h = _spectrum_structure_targets(smiles)
    settings = _fid_settings_from_form(
        selected_preset=selected_preset,
        processing_preset=processing_preset,
        zero_fill_factor=zero_fill_factor,
        line_broadening_hz=line_broadening_hz,
        apodization_mode=apodization_mode,
        apply_group_delay=apply_group_delay,
        auto_phase=auto_phase,
        auto_baseline=auto_baseline,
        phase_mode=phase_mode,
        phase_p0=phase_p0,
        phase_p1=phase_p1,
        baseline_correction=baseline_correction,
        baseline_order=baseline_order,
        baseline_lock=baseline_lock,
        peak_sensitivity=peak_sensitivity,
        mask_solvent_regions=mask_solvent_regions,
        display_mode=display_mode,
        vertical_gain=vertical_gain,
        debug_preview=debug_preview,
    )
    try:
        preview = process_bruker_1d_zip(
            filename=filename,
            content=content,
            solvent=solvent,
            nucleus=nucleus,
            reference_ppm=reference_ppm,
            reference_nmr_text=reference_nmr_text,
            settings=settings,
            expected_total_h=expected_total_h,
            expected_non_labile_h=expected_non_labile_h,
            raw_upload_provenance=raw_upload_provenance,
        )
    except (FIDProcessingError, PydanticValidationError, ValueError) as exc:
        raise _upload_http_400(exc, operation="Raw FID analysis") from exc

    resolved_sample_id = sample_id
    if not resolved_sample_id and workspace_sample_record_id is not None and context.user_id is not None:
        detail = get_sample_detail(
            _state(request).session_factory,
            user_id=context.user_id,
            sample_identity=str(workspace_sample_record_id),
        )
        if detail is not None:
            resolved_sample_id = detail.sample.sample_id
    reviewed_nmr_text = (
        manual_nmr_text.strip()
        if manual_nmr_text is not None and manual_nmr_text.strip()
        else preview.inferred_nmr_text
    )
    generated_inputs = AnalysisInputs(
        sample_id=resolved_sample_id,
        smiles=smiles,
        nmr_text=reviewed_nmr_text,
        solvent=solvent,
    )
    _ensure_analysis_inputs_valid(generated_inputs)
    report = analyze_inputs(generated_inputs)
    combined_notes = list(report.notes)
    for note in reversed(_fid_processing_notes(preview, manual_review_used=reviewed_nmr_text != preview.inferred_nmr_text)):
        if note not in combined_notes:
            combined_notes.insert(0, note)
    report = report.model_copy(update={"notes": combined_notes})
    hours_saved = _estimate_hours_saved(_state(request).settings, parsed_peak_count=report.parsed_peak_count)
    analysis_id = save_analysis(
        _state(request).session_factory,
        report,
        generated_inputs,
        user_id=context.user_id,
        hours_saved_estimate=hours_saved,
    )
    fid_run = save_fid_run(
        _state(request).session_factory,
        preview,
        user_id=context.user_id,
        analysis_id=analysis_id,
        sample_id=resolved_sample_id,
    )
    preview = fid_run.preview
    if workspace_project_id is not None and workspace_sample_record_id is not None and context.user_id is not None:
        try:
            link_project_sample_analysis(
                _state(request).session_factory,
                user_id=context.user_id,
                project_id=workspace_project_id,
                sample_record_id=workspace_sample_record_id,
                analysis_id=analysis_id,
            )
        except ValueError as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc
    _audit_from_context(
        request,
        context=context,
        event_type="fid.process",
        message="Raw FID beta processed into an analysis.",
        entity_type="analysis",
        entity_id=analysis_id,
        metadata={
            "filename": filename,
            "sample_id": resolved_sample_id,
            "workspace_project_id": workspace_project_id,
            "workspace_sample_record_id": workspace_sample_record_id,
            "hours_saved_estimate": hours_saved,
            "manual_nmr_text_supplied": reviewed_nmr_text != preview.inferred_nmr_text,
            "reference_text_supplied": bool(reference_nmr_text and reference_nmr_text.strip()),
            "fid_processing": preview.processing_metadata.model_dump(mode="json"),
            "fid_run_id": fid_run.id,
        },
    )
    return FIDProcessResult(preview=preview, generated_inputs=generated_inputs, analysis=report)


def _fid_user_scope_for_context(context: AccessContext) -> int | None:
    return _user_scope_for_context(context)


def _get_visible_fid_run(request: Request, run_id: int, context: AccessContext) -> FIDRunRecord:
    user_id = _fid_user_scope_for_context(context)
    run = get_fid_run_by_id(_state(request).session_factory, run_id=run_id, user_id=user_id)
    if run is None:
        raise HTTPException(status_code=404, detail="FID run not found.")
    return run


@router.get("/fid/runs", response_model=list[FIDRunRecord], dependencies=[Depends(require_access_context)])
def fid_runs(
    request: Request,
    context: AccessContext = Depends(require_access_context),
    limit: int = Query(default=20, ge=1, le=200),
) -> list[FIDRunRecord]:
    user_id = _fid_user_scope_for_context(context)
    return list_fid_runs(_state(request).session_factory, limit=limit, user_id=user_id)


@router.get("/fid/runs/{run_id}", response_model=FIDRunRecord, dependencies=[Depends(require_access_context)])
def fid_run_detail(
    run_id: int,
    request: Request,
    context: AccessContext = Depends(require_access_context),
) -> FIDRunRecord:
    return _get_visible_fid_run(request, run_id, context)


@router.get(
    "/fid/runs/{run_id}/review-decisions",
    response_model=list[FIDRunReviewDecisionRecord],
    dependencies=[Depends(require_access_context)],
)
def fid_run_review_decisions(
    run_id: int,
    request: Request,
    context: AccessContext = Depends(require_access_context),
) -> list[FIDRunReviewDecisionRecord]:
    _get_visible_fid_run(request, run_id, context)
    return list_fid_run_review_decisions(_state(request).session_factory, run_id=run_id, limit=200)


def _submit_fid_run_review(
    *,
    run_id: int,
    payload: FIDRunReviewCreate,
    request: Request,
    context: AccessContext,
    action: str,
) -> FIDRunReviewDecisionRecord:
    try:
        decision = submit_fid_run_review_decision(
            _state(request).session_factory,
            run_id=run_id,
            reviewer_user_id=context.user.id if context.user else 0,
            action=action,
            comment=payload.comment,
        )
    except ValueError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
    _audit_from_context(
        request,
        context=context,
        event_type="fid.review",
        message=f"FID run {action} decision submitted.",
        entity_type="fid_run",
        entity_id=run_id,
        metadata={"action": action, "comment_supplied": bool(payload.comment)},
    )
    return decision


@router.post(
    "/fid/runs/{run_id}/review",
    response_model=FIDRunReviewDecisionRecord,
    dependencies=[Depends(require_admin)],
)
def fid_run_review(
    run_id: int,
    payload: FIDRunReviewCreate,
    request: Request,
    context: AccessContext = Depends(require_admin),
) -> FIDRunReviewDecisionRecord:
    return _submit_fid_run_review(
        run_id=run_id,
        payload=payload,
        request=request,
        context=context,
        action=payload.action or "review",
    )


@router.post(
    "/fid/runs/{run_id}/approve",
    response_model=FIDRunReviewDecisionRecord,
    dependencies=[Depends(require_admin)],
)
def fid_run_approve(
    run_id: int,
    payload: FIDRunReviewCreate,
    request: Request,
    context: AccessContext = Depends(require_admin),
) -> FIDRunReviewDecisionRecord:
    return _submit_fid_run_review(
        run_id=run_id,
        payload=payload,
        request=request,
        context=context,
        action="approve",
    )


@router.post(
    "/fid/runs/{run_id}/reject",
    response_model=FIDRunReviewDecisionRecord,
    dependencies=[Depends(require_admin)],
)
def fid_run_reject(
    run_id: int,
    payload: FIDRunReviewCreate,
    request: Request,
    context: AccessContext = Depends(require_admin),
) -> FIDRunReviewDecisionRecord:
    return _submit_fid_run_review(
        run_id=run_id,
        payload=payload,
        request=request,
        context=context,
        action="reject",
    )


@router.post(
    "/fid/runs/{run_id}/request-changes",
    response_model=FIDRunReviewDecisionRecord,
    dependencies=[Depends(require_admin)],
)
def fid_run_request_changes(
    run_id: int,
    payload: FIDRunReviewCreate,
    request: Request,
    context: AccessContext = Depends(require_admin),
) -> FIDRunReviewDecisionRecord:
    return _submit_fid_run_review(
        run_id=run_id,
        payload=payload,
        request=request,
        context=context,
        action="request_changes",
    )


@router.get(
    "/fid/runs/{run_id}/report",
    response_model=FIDRunReport,
    dependencies=[Depends(require_access_context)],
)
def fid_run_report(
    run_id: int,
    request: Request,
    context: AccessContext = Depends(require_access_context),
) -> FIDRunReport:
    user_id = _fid_user_scope_for_context(context)
    report = build_fid_run_report(_state(request).session_factory, run_id=run_id, user_id=user_id)
    if report is None:
        raise HTTPException(status_code=404, detail="FID run report not found.")
    _audit_from_context(
        request,
        context=context,
        event_type="fid.report.view_json",
        message="FID run report JSON opened.",
        entity_type="fid_run",
        entity_id=run_id,
    )
    return report


@router.get(
    "/fid/runs/{run_id}/report.html",
    response_class=HTMLResponse,
    dependencies=[Depends(require_access_context)],
)
def fid_run_report_html(
    run_id: int,
    request: Request,
    context: AccessContext = Depends(require_access_context),
) -> HTMLResponse:
    user_id = _fid_user_scope_for_context(context)
    report = build_fid_run_report(_state(request).session_factory, run_id=run_id, user_id=user_id)
    if report is None:
        raise HTTPException(status_code=404, detail="FID run report not found.")
    _audit_from_context(
        request,
        context=context,
        event_type="fid.report.view_html",
        message="FID run report HTML opened.",
        entity_type="fid_run",
        entity_id=run_id,
    )
    return HTMLResponse(_render_fid_run_report_html(report))


@router.get(
    "/fid/runs/{run_id}/package",
    dependencies=[Depends(require_access_context)],
)
def fid_run_package(
    run_id: int,
    request: Request,
    context: AccessContext = Depends(require_access_context),
) -> StreamingResponse:
    user_id = _fid_user_scope_for_context(context)
    report = build_fid_run_report(_state(request).session_factory, run_id=run_id, user_id=user_id)
    if report is None:
        raise HTTPException(status_code=404, detail="FID run report not found.")
    payload, original_included = _build_fid_run_package(report)
    _audit_from_context(
        request,
        context=context,
        event_type="fid.report.package",
        message="FID run evidence package exported.",
        entity_type="fid_run",
        entity_id=run_id,
        metadata={"original_archive_included": original_included},
    )
    headers = {
        "Content-Disposition": f'attachment; filename="fid-run-{run_id}-evidence-package.zip"'
    }
    return StreamingResponse(
        io.BytesIO(payload),
        media_type="application/zip",
        headers=headers,
    )


@router.post("/jobs/submit", response_model=AsyncJobAccepted, status_code=status.HTTP_202_ACCEPTED, dependencies=[Depends(require_access_context)])
def submit_job(
    payload: BatchAnalysisInputs,
    request: Request,
    background_tasks: BackgroundTasks,
    context: AccessContext = Depends(require_access_context),
    job_name: str | None = Query(default=None, min_length=1, max_length=255),
) -> AsyncJobAccepted:
    _ensure_batch_inputs_valid(payload.items)
    state = _state(request)
    job = create_job(
        state.session_factory,
        total_items=len(payload.items),
        job_name=job_name,
        user_id=context.user_id,
        queue_name=state.settings.queue_name,
    )
    enqueue_result = enqueue_job_processing(
        settings=state.settings,
        database_url=state.settings.database_url,
        session_factory=state.session_factory,
        background_tasks=background_tasks,
        job_id=job.id,
        items=payload.items,
        user_id=context.user_id,
    )
    if enqueue_result.backend_job_id is not None:
        set_job_backend_id(state.session_factory, job.id, backend_job_id=enqueue_result.backend_job_id, status="queued")
        job = get_job_by_id(state.session_factory, job.id, user_id=context.user_id) or job
    _audit_from_context(request, context=context, event_type="job.submit", message="Background job submitted.", entity_type="job", entity_id=job.id, metadata={"items": len(payload.items), "backend": enqueue_result.backend})
    return AsyncJobAccepted(job=job, queue_backend=enqueue_result.backend)


@router.post("/jobs/upload", response_model=AsyncJobAccepted, status_code=status.HTTP_202_ACCEPTED, dependencies=[Depends(require_access_context)])
async def jobs_upload(
    request: Request,
    background_tasks: BackgroundTasks,
    file: UploadFile = File(...),
    job_name: str | None = Form(default=None),
    context: AccessContext = Depends(require_access_context),
) -> AsyncJobAccepted:
    content = await file.read()
    filename = file.filename or "batch.json"
    try:
        payload = parse_batch_upload(filename=filename, content=content)
    except UploadParseError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    _ensure_batch_inputs_valid(payload.items)

    state = _state(request)
    job = create_job(
        state.session_factory,
        total_items=len(payload.items),
        job_name=job_name,
        uploaded_filename=filename,
        user_id=context.user_id,
        queue_name=state.settings.queue_name,
    )
    enqueue_result = enqueue_job_processing(
        settings=state.settings,
        database_url=state.settings.database_url,
        session_factory=state.session_factory,
        background_tasks=background_tasks,
        job_id=job.id,
        items=payload.items,
        user_id=context.user_id,
    )
    if enqueue_result.backend_job_id is not None:
        set_job_backend_id(state.session_factory, job.id, backend_job_id=enqueue_result.backend_job_id, status="queued")
        job = get_job_by_id(state.session_factory, job.id, user_id=context.user_id) or job
    _audit_from_context(request, context=context, event_type="job.upload", message="Upload job submitted.", entity_type="job", entity_id=job.id, metadata={"filename": filename, "items": len(payload.items), "backend": enqueue_result.backend})
    return AsyncJobAccepted(job=job, queue_backend=enqueue_result.backend)


@router.get("/workspaces/projects", response_model=list[ProjectRecord], dependencies=[Depends(require_access_context)])
def workspace_projects(
    request: Request,
    limit: int = Query(default=200, ge=1, le=500),
    user: UserPublic = Depends(require_authenticated_user),
) -> list[ProjectRecord]:
    return list_projects(_state(request).session_factory, user_id=user.id, limit=limit)


@router.post("/workspaces/projects", response_model=ProjectRecord, status_code=status.HTTP_201_CREATED, dependencies=[Depends(require_access_context)])
def workspace_create_project(
    payload: ProjectCreate,
    request: Request,
    user: UserPublic = Depends(require_authenticated_user),
) -> ProjectRecord:
    try:
        record = create_project(
            _state(request).session_factory,
            user_id=user.id,
            name=payload.name,
            description=payload.description,
        )
    except ValueError as exc:
        raise HTTPException(status_code=409, detail=str(exc)) from exc
    _audit_from_context(
        request,
        context=AccessContext(user=user),
        event_type="workspace.project.create",
        message="Workspace project created.",
        entity_type="project",
        entity_id=record.id,
        metadata={"name": record.name},
    )
    return record


@router.get("/workspaces/projects/{project_id}/samples", response_model=list[ProjectSampleRecord], dependencies=[Depends(require_access_context)])
def workspace_project_samples(
    project_id: int,
    request: Request,
    limit: int = Query(default=200, ge=1, le=500),
    user: UserPublic = Depends(require_authenticated_user),
) -> list[ProjectSampleRecord]:
    if get_project_by_id(_state(request).session_factory, project_id, user_id=user.id) is None:
        raise HTTPException(status_code=404, detail="Project not found.")
    return list_project_samples(_state(request).session_factory, user_id=user.id, project_id=project_id, limit=limit)


@router.post("/workspaces/projects/{project_id}/samples", response_model=ProjectSampleRecord, status_code=status.HTTP_201_CREATED, dependencies=[Depends(require_access_context)])
def workspace_create_project_sample(
    project_id: int,
    payload: ProjectSampleCreate,
    request: Request,
    user: UserPublic = Depends(require_authenticated_user),
) -> ProjectSampleRecord:
    try:
        record = create_project_sample(_state(request).session_factory, user_id=user.id, project_id=project_id, payload=payload)
    except KeyError as exc:
        raise HTTPException(status_code=404, detail="Project not found.") from exc
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    _audit_from_context(
        request,
        context=AccessContext(user=user),
        event_type="workspace.sample.create",
        message="Workspace sample created.",
        entity_type="project_sample",
        entity_id=record.id,
        metadata={"project_id": project_id, "analysis_id": payload.analysis_id},
    )
    return record


@router.post("/workspaces/projects/{project_id}/samples/{sample_record_id}/link-analysis", response_model=ProjectSampleRecord, dependencies=[Depends(require_access_context)])
def workspace_link_project_sample_analysis(
    project_id: int,
    sample_record_id: int,
    payload: ProjectSampleAnalysisLink,
    request: Request,
    user: UserPublic = Depends(require_authenticated_user),
) -> ProjectSampleRecord:
    try:
        record = link_project_sample_analysis(
            _state(request).session_factory,
            user_id=user.id,
            project_id=project_id,
            sample_record_id=sample_record_id,
            analysis_id=payload.analysis_id,
        )
    except KeyError as exc:
        raise HTTPException(status_code=404, detail="Project sample not found.") from exc
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    _audit_from_context(
        request,
        context=AccessContext(user=user),
        event_type="workspace.sample.link_analysis",
        message="Workspace sample linked to an analysis.",
        entity_type="project_sample",
        entity_id=record.id,
        metadata={"project_id": project_id, "analysis_id": payload.analysis_id},
    )
    return record


@router.get("/projects/{project_id}/dashboard", response_model=ProjectDashboardRecord, dependencies=[Depends(require_access_context)])
def project_dashboard(
    project_id: int,
    request: Request,
    user: UserPublic = Depends(require_authenticated_user),
) -> ProjectDashboardRecord:
    dashboard = build_project_dashboard(_state(request).session_factory, user_id=user.id, project_id=project_id)
    if dashboard is None:
        raise HTTPException(status_code=404, detail="Project not found.")
    return dashboard


@router.get("/samples/{sample_id}/analyses", response_model=list[StoredAnalysisRecord], dependencies=[Depends(require_access_context)])
def sample_analyses(
    sample_id: str,
    request: Request,
    user: UserPublic = Depends(require_authenticated_user),
) -> list[StoredAnalysisRecord]:
    records = list_sample_analyses(_state(request).session_factory, user_id=user.id, sample_identity=sample_id)
    if records is None:
        raise HTTPException(status_code=404, detail="Sample not found.")
    return records


@router.get("/samples/{sample_id}/timeline", response_model=SampleTimelineRecord, dependencies=[Depends(require_access_context)])
def sample_timeline(
    sample_id: str,
    request: Request,
    user: UserPublic = Depends(require_authenticated_user),
) -> SampleTimelineRecord:
    record = get_sample_timeline(_state(request).session_factory, user_id=user.id, sample_identity=sample_id)
    if record is None:
        raise HTTPException(status_code=404, detail="Sample not found.")
    return record


@router.get("/samples/{sample_id}/reports", response_model=SampleReportsRecord, dependencies=[Depends(require_access_context)])
def sample_reports(
    sample_id: str,
    request: Request,
    user: UserPublic = Depends(require_authenticated_user),
) -> SampleReportsRecord:
    record = list_sample_reports(_state(request).session_factory, user_id=user.id, sample_identity=sample_id)
    if record is None:
        raise HTTPException(status_code=404, detail="Sample not found.")
    return record


@router.get("/samples/{sample_id}/compare", response_model=SampleAnalysisComparison, dependencies=[Depends(require_access_context)])
def sample_compare(
    sample_id: str,
    request: Request,
    user: UserPublic = Depends(require_authenticated_user),
) -> SampleAnalysisComparison:
    record = compare_sample_analyses(_state(request).session_factory, user_id=user.id, sample_identity=sample_id)
    if record is None:
        raise HTTPException(status_code=404, detail="Sample not found.")
    return record


@router.get("/samples/{sample_id}", response_model=SampleDetailRecord, dependencies=[Depends(require_access_context)])
def sample_detail(
    sample_id: str,
    request: Request,
    user: UserPublic = Depends(require_authenticated_user),
) -> SampleDetailRecord:
    record = get_sample_detail(_state(request).session_factory, user_id=user.id, sample_identity=sample_id)
    if record is None:
        raise HTTPException(status_code=404, detail="Sample not found.")
    return record


@router.post("/reports/from-analysis/{analysis_id}", response_model=StoredReportRecord, status_code=status.HTTP_201_CREATED, dependencies=[Depends(require_access_context)])
def report_from_analysis(
    analysis_id: int,
    request: Request,
    context: AccessContext = Depends(require_access_context),
) -> StoredReportRecord:
    user_id = _user_scope_for_context(context)
    record = create_report_from_analysis(_state(request).session_factory, analysis_id=analysis_id, user_id=user_id)
    if record is None:
        raise HTTPException(status_code=404, detail="Analysis report not found.")
    _audit_from_context(
        request,
        context=context,
        event_type="report.generate",
        message="Versioned report generated from analysis.",
        entity_type="analysis",
        entity_id=analysis_id,
        metadata={"report_id": record.id, "version": record.version},
    )
    return record


@router.get("/reports/{analysis_id}.json", response_model=AnalysisEvidenceReport, dependencies=[Depends(require_access_context)])
def evidence_report_json(
    analysis_id: int,
    request: Request,
    context: AccessContext = Depends(require_access_context),
) -> AnalysisEvidenceReport:
    user_id = _user_scope_for_context(context)
    report = build_evidence_report(_state(request).session_factory, analysis_id=analysis_id, user_id=user_id)
    if report is None:
        raise HTTPException(status_code=404, detail="Analysis report not found.")
    _audit_from_context(
        request,
        context=context,
        event_type="report.view_json",
        message="Evidence report JSON opened.",
        entity_type="analysis",
        entity_id=analysis_id,
    )
    return report


@router.get("/reports/{analysis_id}.html", response_class=HTMLResponse, dependencies=[Depends(require_access_context)])
def evidence_report_html(
    analysis_id: int,
    request: Request,
    context: AccessContext = Depends(require_access_context),
) -> HTMLResponse:
    user_id = _user_scope_for_context(context)
    stored_report = get_report_by_id(_state(request).session_factory, report_id=analysis_id, user_id=user_id)
    if stored_report is not None:
        _audit_from_context(
            request,
            context=context,
            event_type="report.view_versioned_html",
            message="Versioned report HTML opened.",
            entity_type="analysis",
            entity_id=stored_report.analysis_id,
            metadata={"report_id": stored_report.id, "version": stored_report.version},
        )
        return HTMLResponse(_render_evidence_report_html(stored_report.report))
    report = build_evidence_report(_state(request).session_factory, analysis_id=analysis_id, user_id=user_id)
    if report is None:
        raise HTTPException(status_code=404, detail="Analysis report not found.")
    _audit_from_context(
        request,
        context=context,
        event_type="report.view_html",
        message="Evidence report HTML opened.",
        entity_type="analysis",
        entity_id=analysis_id,
    )
    return HTMLResponse(_render_evidence_report_html(report))


@router.get("/reports/{report_id}", response_model=StoredReportRecord, dependencies=[Depends(require_access_context)])
def report_detail(
    report_id: int,
    request: Request,
    context: AccessContext = Depends(require_access_context),
) -> StoredReportRecord:
    user_id = _user_scope_for_context(context)
    record = get_report_by_id(_state(request).session_factory, report_id=report_id, user_id=user_id)
    if record is None:
        raise HTTPException(status_code=404, detail="Report not found.")
    _audit_from_context(
        request,
        context=context,
        event_type="report.view_versioned_json",
        message="Versioned report JSON opened.",
        entity_type="analysis",
        entity_id=record.analysis_id,
        metadata={"report_id": record.id, "version": record.version},
    )
    return record


@router.get("/history", response_model=list[StoredAnalysisRecord], dependencies=[Depends(require_access_context)])
def history(
    request: Request,
    limit: int = Query(default=20, ge=1, le=200),
    context: AccessContext = Depends(require_access_context),
) -> list[StoredAnalysisRecord]:
    user_id = None if context.system_api_key else context.user_id
    return list_recent_analyses(_state(request).session_factory, limit=limit, user_id=user_id)


@router.get("/history/export.csv", dependencies=[Depends(require_access_context)])
def history_export_csv(
    request: Request,
    limit: int | None = Query(default=None, ge=1, le=10_000),
    context: AccessContext = Depends(require_access_context),
) -> StreamingResponse:
    user_id = None if context.system_api_key else context.user_id
    csv_text = export_history_csv(_state(request).session_factory, limit=limit, user_id=user_id)
    headers = {"Content-Disposition": 'attachment; filename="nmrcheck-history.csv"'}
    return StreamingResponse(_stream_text(csv_text), media_type="text/csv", headers=headers)


@router.get("/history/{analysis_id}/full", response_model=FullStoredAnalysisRecord, dependencies=[Depends(require_access_context)])
def history_detail_full(analysis_id: int, request: Request, context: AccessContext = Depends(require_access_context)) -> FullStoredAnalysisRecord:
    user_id = None if context.system_api_key else context.user_id
    record = get_full_analysis_by_id(_state(request).session_factory, analysis_id=analysis_id, user_id=user_id)
    if record is None:
        raise HTTPException(status_code=404, detail="Analysis record not found.")
    return record


@router.get("/history/{analysis_id}", response_model=StoredAnalysisRecord, dependencies=[Depends(require_access_context)])
def history_detail(analysis_id: int, request: Request, context: AccessContext = Depends(require_access_context)) -> StoredAnalysisRecord:
    user_id = None if context.system_api_key else context.user_id
    record = get_analysis_by_id(_state(request).session_factory, analysis_id=analysis_id, user_id=user_id)
    if record is None:
        raise HTTPException(status_code=404, detail="Analysis record not found.")
    return record


@router.get("/jobs", response_model=list[JobRecord], dependencies=[Depends(require_access_context)])
def jobs(request: Request, limit: int = Query(default=20, ge=1, le=200), context: AccessContext = Depends(require_access_context)) -> list[JobRecord]:
    user_id = None if context.system_api_key else context.user_id
    return list_jobs(_state(request).session_factory, limit=limit, user_id=user_id)


@router.get("/jobs/{job_id}", response_model=JobRecord, dependencies=[Depends(require_access_context)])
def job_detail(job_id: int, request: Request, context: AccessContext = Depends(require_access_context)) -> JobRecord:
    user_id = None if context.system_api_key else context.user_id
    record = get_job_by_id(_state(request).session_factory, job_id=job_id, user_id=user_id)
    if record is None:
        raise HTTPException(status_code=404, detail="Job not found.")
    return record


@router.get("/jobs/{job_id}/items", response_model=list[StoredAnalysisRecord], dependencies=[Depends(require_access_context)])
def job_items(job_id: int, request: Request, context: AccessContext = Depends(require_access_context)) -> list[StoredAnalysisRecord]:
    user_id = None if context.system_api_key else context.user_id
    if get_job_by_id(_state(request).session_factory, job_id=job_id, user_id=user_id) is None:
        raise HTTPException(status_code=404, detail="Job not found.")
    return list_job_analyses(_state(request).session_factory, job_id=job_id, user_id=user_id)


@router.get("/jobs/{job_id}/export.csv", dependencies=[Depends(require_access_context)])
def job_export_csv(job_id: int, request: Request, context: AccessContext = Depends(require_access_context)) -> StreamingResponse:
    user_id = None if context.system_api_key else context.user_id
    try:
        csv_text = export_job_csv(_state(request).session_factory, job_id=job_id, user_id=user_id)
    except KeyError as exc:
        raise HTTPException(status_code=404, detail="Job not found.") from exc
    headers = {"Content-Disposition": f'attachment; filename="nmrcheck-job-{job_id}.csv"'}
    return StreamingResponse(_stream_text(csv_text), media_type="text/csv", headers=headers)


@router.get("/jobs/{job_id}/export.json", dependencies=[Depends(require_access_context)])
def job_export_json(job_id: int, request: Request, context: AccessContext = Depends(require_access_context)) -> StreamingResponse:
    user_id = None if context.system_api_key else context.user_id
    try:
        json_text = export_job_json(_state(request).session_factory, job_id=job_id, user_id=user_id)
    except KeyError as exc:
        raise HTTPException(status_code=404, detail="Job not found.") from exc
    headers = {"Content-Disposition": f'attachment; filename="nmrcheck-job-{job_id}.json"'}
    return StreamingResponse(_stream_text(json_text), media_type="application/json", headers=headers)




@router.get("/reviews", response_model=list[ReviewQueueItem], dependencies=[Depends(require_admin)])
def reviews(
    request: Request,
    context: AccessContext = Depends(require_admin),
    review_status: str | None = Query(default=None),
    limit: int = Query(default=50, ge=1, le=200),
) -> list[ReviewQueueItem]:
    _audit_from_context(request, context=context, event_type="review.list", message="Review queue opened.", metadata={"status": review_status, "limit": limit})
    return list_review_queue(_state(request).session_factory, limit=limit, review_status=review_status)


@router.post("/reviews/{analysis_id}/approve", response_model=ReviewDecisionRecord, dependencies=[Depends(require_admin)])
def review_approve(
    analysis_id: int,
    payload: ReviewDecisionCreate,
    request: Request,
    context: AccessContext = Depends(require_admin),
) -> ReviewDecisionRecord:
    decision = submit_review_decision(
        _state(request).session_factory,
        analysis_id=analysis_id,
        reviewer_user_id=context.user.id if context.user else 0,
        action="approve",
        comment=payload.comment,
        final_label=payload.final_label,
        hours_saved_estimate=payload.hours_saved_estimate,
    )
    return decision


@router.post("/reviews/{analysis_id}/reject", response_model=ReviewDecisionRecord, dependencies=[Depends(require_admin)])
def review_reject(
    analysis_id: int,
    payload: ReviewDecisionCreate,
    request: Request,
    context: AccessContext = Depends(require_admin),
) -> ReviewDecisionRecord:
    return submit_review_decision(
        _state(request).session_factory,
        analysis_id=analysis_id,
        reviewer_user_id=context.user.id if context.user else 0,
        action="reject",
        comment=payload.comment,
        final_label=payload.final_label,
        hours_saved_estimate=payload.hours_saved_estimate,
    )


@router.post("/reviews/{analysis_id}/override", response_model=ReviewDecisionRecord, dependencies=[Depends(require_admin)])
def review_override(
    analysis_id: int,
    payload: ReviewDecisionCreate,
    request: Request,
    context: AccessContext = Depends(require_admin),
) -> ReviewDecisionRecord:
    return submit_review_decision(
        _state(request).session_factory,
        analysis_id=analysis_id,
        reviewer_user_id=context.user.id if context.user else 0,
        action="override",
        comment=payload.comment,
        final_label=payload.final_label,
        hours_saved_estimate=payload.hours_saved_estimate,
    )


@router.get("/reviews/{analysis_id}/decisions", response_model=list[ReviewDecisionRecord], dependencies=[Depends(require_access_context)])
def review_decisions(
    analysis_id: int,
    request: Request,
    context: AccessContext = Depends(require_access_context),
) -> list[ReviewDecisionRecord]:
    state = _state(request)
    if not context.system_api_key and not (context.user and context.user.is_admin):
        if get_analysis_by_id(state.session_factory, analysis_id=analysis_id, user_id=context.user_id) is None:
            raise HTTPException(status_code=404, detail="Analysis record not found.")
    return list_review_decisions(state.session_factory, analysis_id=analysis_id)


@router.get("/audit", response_model=list[AuditEventRecord], dependencies=[Depends(require_access_context)])
def audit_log(
    request: Request,
    context: AccessContext = Depends(require_access_context),
    limit: int = Query(default=100, ge=1, le=500),
    event_type: str | None = Query(default=None),
    entity_type: str | None = Query(default=None),
    entity_id: int | None = Query(default=None),
) -> list[AuditEventRecord]:
    state = _state(request)
    limit_value = limit if isinstance(limit, int) else 100
    event_type_value = event_type if isinstance(event_type, str) else None
    entity_type_value = entity_type if isinstance(entity_type, str) else None
    entity_id_value = entity_id if isinstance(entity_id, int) else None
    if not context.system_api_key and not (context.user and context.user.is_admin):
        if entity_type_value != "analysis" or entity_id_value is None:
            raise HTTPException(status_code=403, detail="Admin access required for unscoped audit events.")
        if get_analysis_by_id(state.session_factory, analysis_id=entity_id_value, user_id=context.user_id) is None:
            raise HTTPException(status_code=404, detail="Analysis record not found.")
    return list_audit_events(
        state.session_factory,
        limit=limit_value,
        event_type=event_type_value,
        entity_type=entity_type_value,
        entity_id=entity_id_value,
    )


@router.get("/metrics/summary", response_model=MetricsSummary, dependencies=[Depends(require_admin)])
def metrics_summary(
    request: Request,
    context: AccessContext = Depends(require_admin),
) -> MetricsSummary:
    return get_metrics_summary(_state(request).session_factory)


@router.get("/metrics/dashboard", response_model=MetricsSummary, dependencies=[Depends(require_admin)])
def metrics_dashboard(
    request: Request,
    context: AccessContext = Depends(require_admin),
) -> MetricsSummary:
    return get_metrics_summary(_state(request).session_factory)


@router.get("/admin/users", response_model=list[AdminUserRecord], dependencies=[Depends(require_admin)])
def admin_users(
    request: Request,
    context: AccessContext = Depends(require_admin),
    limit: int = Query(default=100, ge=1, le=500),
) -> list[AdminUserRecord]:
    return list_admin_users(_state(request).session_factory, limit=limit)


@router.post("/admin/users/{user_id}/promote", response_model=UserPublic, dependencies=[Depends(require_admin)])
def admin_promote_user(
    user_id: int,
    request: Request,
    context: AccessContext = Depends(require_admin),
) -> UserPublic:
    updated = set_user_admin_status(_state(request).session_factory, user_id=user_id, is_admin=True)
    _audit_from_context(request, context=context, event_type="admin.promote_user", message="User promoted to admin.", entity_type="user", entity_id=user_id)
    return updated


@router.post("/admin/users/{user_id}/demote", response_model=UserPublic, dependencies=[Depends(require_admin)])
def admin_demote_user(
    user_id: int,
    request: Request,
    context: AccessContext = Depends(require_admin),
) -> UserPublic:
    updated = set_user_admin_status(_state(request).session_factory, user_id=user_id, is_admin=False)
    _audit_from_context(request, context=context, event_type="admin.demote_user", message="User demoted from admin.", entity_type="user", entity_id=user_id)
    return updated


@router.get("/admin/system", response_model=AdminSystemSummary, dependencies=[Depends(require_admin)])
def admin_system(
    request: Request,
    context: AccessContext = Depends(require_admin),
) -> AdminSystemSummary:
    queue = queue_status(request)
    return get_admin_system_summary(
        _state(request).session_factory,
        queue_backend=queue.backend,
        redis_configured=queue.redis_configured,
    )


@router.get("/admin/deployment", dependencies=[Depends(require_admin)])
def admin_deployment_diagnostics(request: Request) -> dict[str, object]:
    settings = _state(request).settings
    optional_fid_ready = (
        importlib.util.find_spec("nmrglue") is not None
        and importlib.util.find_spec("numpy") is not None
    )
    return {
        "app_env": settings.app_env,
        "database_url_configured": bool(settings.database_url),
        "redis_configured": bool(settings.redis_url),
        "api_key_configured": bool(settings.api_key),
        "admin_email_count": len(settings.admin_emails),
        "healthcheck_path": settings.healthcheck_path,
        "startup_issues": getattr(request.app.state, "startup_issues", []),
        "optional_fid_dependencies_ready": optional_fid_ready,
        "raw_fid_vendors_beta": ["Bruker", "Varian/Agilent"],
        "queue_name": settings.queue_name,
        "require_verified_email": settings.require_verified_email,
    }


@router.get("/admin/release-health", dependencies=[Depends(require_admin)])
def admin_release_health(request: Request) -> dict[str, object]:
    settings = _state(request).settings
    optional_fid_ready = (
        importlib.util.find_spec("nmrglue") is not None
        and importlib.util.find_spec("numpy") is not None
    )
    metrics = get_metrics_summary(_state(request).session_factory)
    queue = queue_status(request)
    return {
        "release_version": settings.release_version,
        "release_stage": settings.release_stage,
        "app_version": settings.release_version,
        "startup_issues": getattr(request.app.state, "startup_issues", []),
        "database_status": "configured" if settings.database_url else "missing",
        "redis_status": "configured" if settings.redis_url else "not_configured",
        "queue_status": queue.model_dump(),
        "fid_optional_dependencies_ready": optional_fid_ready,
        "supported_raw_fid_vendors_beta": ["Bruker", "Varian/Agilent"],
        "analyses_total": metrics.total_analyses,
        "jobs_total": metrics.total_jobs,
        "pending_review_total": metrics.pending_review,
        "hours_saved_estimate": metrics.hours_saved_estimate,
        "value_dashboard": [
            {"label": "Analyses run", "value": metrics.total_analyses},
            {"label": "Batch jobs", "value": metrics.total_jobs},
            {"label": "Pending reviews", "value": metrics.pending_review},
            {"label": "Estimated hours saved", "value": metrics.hours_saved_estimate},
        ],
        "recommended_smoke_tests": [
            "GET /health",
            "GET /admin/deployment",
            "GET /admin/release-health",
            "POST /proton/evidence",
            "POST /carbon13/analyze",
            "POST /carbon13/spectrum/analyze",
            "POST /carbon13/fid/analyze",
            "POST /spectrum/preview with a processed CSV",
            "POST /fid/preview with Bruker and Varian/Agilent beta fixtures",
        ],
    }


@router.post("/proton/evidence", response_model=ProtonEvidenceReport, dependencies=[Depends(require_access_context)])
def proton_evidence_route(
    payload: AnalysisInputs,
    request: Request,
    context: AccessContext = Depends(require_access_context),
) -> ProtonEvidenceReport:
    report = analyze_proton_evidence(
        smiles=payload.smiles,
        nmr_text=payload.nmr_text,
        sample_id=payload.sample_id,
        solvent=payload.solvent,
    )
    _audit_from_context(
        request,
        context=context,
        event_type="proton.evidence",
        message="¹H NMR evidence scoring completed.",
        metadata={
            "sample_id": payload.sample_id,
            "label": report.label,
            "score": report.overall_score,
        },
    )
    return report


@router.post("/carbon13/validate", response_model=Carbon13UploadPreview, dependencies=[Depends(require_access_context)])
def carbon13_validate_route(
    payload: Carbon13Inputs,
    request: Request,
    context: AccessContext = Depends(require_access_context),
) -> Carbon13UploadPreview:
    try:
        peaks = parse_carbon13_text(payload.carbon13_text, solvent=payload.solvent)
    except (Carbon13ParseError, PydanticValidationError, ValueError) as exc:
        raise _upload_http_400(exc, operation="¹³C peak-table upload") from exc
    warnings: list[str] = []
    if any(peak.is_likely_solvent for peak in peaks):
        warnings.append("One or more ¹³C shifts overlap known solvent-carbon regions.")
    if any(getattr(peak, "is_likely_impurity", False) for peak in peaks):
        warnings.append("One or more ¹³C shifts overlap embedded impurity-reference regions.")
    return Carbon13UploadPreview(
        filename="pasted_13c_text",
        source_mode="text",
        observed_signal_count=len(peaks),
        peaks=peaks,
        warnings=warnings,
        metadata={"sample_id": payload.sample_id, "solvent": payload.solvent},
    )


@router.post("/carbon13/analyze", response_model=Carbon13AnalysisReport, dependencies=[Depends(require_access_context)])
def carbon13_analyze_route(
    payload: Carbon13Inputs,
    request: Request,
    context: AccessContext = Depends(require_access_context),
) -> Carbon13AnalysisReport:
    try:
        report = analyze_carbon13_text(
            payload.smiles,
            payload.carbon13_text,
            solvent=payload.solvent,
            sample_id=payload.sample_id,
        )
    except (Carbon13ParseError, PydanticValidationError, ValueError) as exc:
        raise _upload_http_400(exc, operation="¹³C processed spectrum preview") from exc
    _audit_from_context(
        request,
        context=context,
        event_type="carbon13.analyze",
        message="¹³C NMR validation completed.",
        metadata={
            "sample_id": payload.sample_id,
            "label": report.label,
            "observed_carbon_signals": report.observed_carbon_signals,
        },
    )
    return report


@router.post("/carbon13/evidence", response_model=Carbon13AnalysisReport, dependencies=[Depends(require_access_context)])
def carbon13_evidence_route(
    payload: Carbon13Inputs,
    request: Request,
    context: AccessContext = Depends(require_access_context),
) -> Carbon13AnalysisReport:
    return carbon13_analyze_route(payload=payload, request=request, context=context)


@router.post("/carbon13/upload", response_model=Carbon13AnalysisReport, dependencies=[Depends(require_access_context)])
async def carbon13_upload_route(
    request: Request,
    file: UploadFile = File(...),
    smiles: str = Form(...),
    solvent: str | None = Form(default=None),
    sample_id: str | None = Form(default=None),
    context: AccessContext = Depends(require_access_context),
) -> Carbon13AnalysisReport:
    filename = file.filename or "carbon13_peaks.csv"
    content = await file.read()
    try:
        preview = parse_carbon13_table(filename, content, solvent=solvent)
        report = analyze_carbon13(
            smiles=smiles,
            peaks=preview.peaks,
            solvent=solvent,
            sample_id=sample_id,
        )
    except Carbon13ParseError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    combined_notes = list(report.notes)
    for warning in preview.warnings:
        if warning not in combined_notes:
            combined_notes.append(warning)
    report = report.model_copy(update={"notes": combined_notes})
    _audit_from_context(
        request,
        context=context,
        event_type="carbon13.upload.analyze",
        message="¹³C peak table uploaded and analyzed.",
        metadata={"filename": filename, "sample_id": sample_id, "label": report.label},
    )
    return report


@router.post("/carbon13/spectrum/preview", response_model=Carbon13UploadPreview, dependencies=[Depends(require_access_context)])
async def carbon13_spectrum_preview_route(
    request: Request,
    file: UploadFile = File(...),
    solvent: str | None = Form(default=None),
    peak_sensitivity: float | None = Form(default=None),
    mask_solvent_regions: bool = Form(default=True),
    display_mode: str = Form(default="real"),
    vertical_gain: float = Form(default=1.0),
    debug_preview: bool = Form(default=False),
    processed_baseline_correction: str = Form(default="none"),
    processed_baseline_order: int = Form(default=3),
    context: AccessContext = Depends(require_access_context),
) -> Carbon13UploadPreview:
    filename = file.filename or "carbon13_spectrum.csv"
    content = await file.read()
    display_mode_value = _unwrap_form_default(display_mode)
    vertical_gain_value = _coerce_optional_form_float(vertical_gain, default=1.0)
    debug_preview_value = _coerce_optional_form_bool(debug_preview, default=False)
    try:
        preview = parse_carbon13_processed_spectrum(
            filename,
            content,
            solvent=solvent,
            peak_sensitivity=peak_sensitivity,
            mask_solvent_regions=mask_solvent_regions,
            display_mode=display_mode_value,
            vertical_gain=vertical_gain_value,
            debug_preview=debug_preview_value,
            processed_baseline_correction=_unwrap_form_default(processed_baseline_correction),
            processed_baseline_order=int(_unwrap_form_default(processed_baseline_order) or 3),
        )
    except Carbon13ParseError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    _audit_from_context(
        request,
        context=context,
        event_type="carbon13.spectrum.preview",
        message="¹³C processed spectrum preview generated.",
        metadata={
            "filename": filename,
            "solvent": solvent,
            "observed_signal_count": preview.observed_signal_count,
        },
    )
    return preview


@router.post("/carbon13/spectrum/analyze", response_model=Carbon13AnalysisReport, dependencies=[Depends(require_access_context)])
async def carbon13_spectrum_analyze_route(
    request: Request,
    file: UploadFile = File(...),
    smiles: str = Form(...),
    solvent: str | None = Form(default=None),
    sample_id: str | None = Form(default=None),
    peak_sensitivity: float | None = Form(default=None),
    mask_solvent_regions: bool = Form(default=True),
    manual_peaks_json: str | None = Form(default=None),
    display_mode: str = Form(default="real"),
    vertical_gain: float = Form(default=1.0),
    debug_preview: bool = Form(default=False),
    processed_baseline_correction: str = Form(default="none"),
    processed_baseline_order: int = Form(default=3),
    context: AccessContext = Depends(require_access_context),
) -> Carbon13AnalysisReport:
    filename = file.filename or "carbon13_spectrum.csv"
    content = await file.read()
    display_mode_value = _unwrap_form_default(display_mode)
    vertical_gain_value = _coerce_optional_form_float(vertical_gain, default=1.0)
    debug_preview_value = _coerce_optional_form_bool(debug_preview, default=False)
    try:
        preview = parse_carbon13_processed_spectrum(
            filename,
            content,
            solvent=solvent,
            peak_sensitivity=peak_sensitivity,
            mask_solvent_regions=mask_solvent_regions,
            display_mode=display_mode_value,
            vertical_gain=vertical_gain_value,
            debug_preview=debug_preview_value,
            processed_baseline_correction=_unwrap_form_default(processed_baseline_correction),
            processed_baseline_order=int(_unwrap_form_default(processed_baseline_order) or 3),
        )
        reviewed_peaks = _manual_carbon13_peaks_from_json(manual_peaks_json, solvent=solvent)
        report = analyze_carbon13(
            smiles=smiles,
            peaks=reviewed_peaks or preview.peaks,
            solvent=solvent,
            sample_id=sample_id,
        )
    except (Carbon13ParseError, StructureParseError, PydanticValidationError, ValueError) as exc:
        raise _upload_http_400(exc, operation="¹³C processed spectrum analysis") from exc
    combined_notes = list(report.notes)
    if manual_peaks_json and "Reviewer-adjusted ¹³C peak acceptance/exclusion decisions were used for analysis." not in combined_notes:
        combined_notes.append("Reviewer-adjusted ¹³C peak acceptance/exclusion decisions were used for analysis.")
    for warning in preview.warnings:
        if warning not in combined_notes:
            combined_notes.append(warning)
    report = report.model_copy(update={"notes": combined_notes})
    _audit_from_context(
        request,
        context=context,
        event_type="carbon13.spectrum.analyze",
        message="¹³C processed spectrum uploaded and analyzed.",
        metadata={"filename": filename, "sample_id": sample_id, "label": report.label},
    )
    return report


def _carbon13_raw_fid_preview_from_upload(
    *,
    filename: str,
    content: bytes,
    solvent: str | None,
    smiles: str | None,
    proton_nmr_text: str | None,
    reference_ppm: float | None,
    settings: FIDProcessingSettings,
    raw_upload_provenance: dict[str, object] | None = None,
) -> tuple[Carbon13UploadPreview, FIDPreviewReport]:
    fid_preview = process_bruker_1d_zip(
        filename=filename,
        content=content,
        solvent=solvent,
        nucleus="13C",
        reference_ppm=reference_ppm,
        reference_nmr_text=None,
        settings=settings,
        expected_total_h=None,
        expected_non_labile_h=None,
        raw_upload_provenance=raw_upload_provenance,
    )
    peaks = carbon13_peaks_from_shift_values(
        [(peak.shift_ppm, peak.integration_h) for peak in fid_preview.inferred_peaks],
        solvent=solvent,
    )
    peaks, context_meta, context_notes = refine_carbon13_peaks_with_context(
        peaks,
        smiles=smiles,
        proton_nmr_text=proton_nmr_text,
        solvent=solvent,
    )
    warnings = list(fid_preview.warnings)
    warnings.extend(note for note in context_notes if note not in warnings)
    warnings.append(
        "Raw ¹³C FID beta processing reuses the automatic 1D FID transform path; review phasing, baseline, and peak picking before signoff."
    )
    preview = Carbon13UploadPreview(
        filename=filename,
        source_mode="raw_fid",
        observed_signal_count=len(peaks),
        peaks=peaks,
        warnings=warnings,
        metadata={
            "solvent": solvent,
            "format_detected": fid_preview.format_detected,
            "point_count": fid_preview.point_count,
            "preview_points": [
                point.model_dump(mode="json") for point in fid_preview.preview_points
            ],
            "original_spectrum_state": fid_preview.metadata.get("original_spectrum_state"),
            "baseline_flatness_qa": fid_preview.metadata.get("baseline_flatness_qa"),
            "display_preprocessing": fid_preview.metadata.get("display_preprocessing"),
            "evidence_trace_mode": fid_preview.metadata.get("evidence_trace_mode"),
            "display_mode": fid_preview.metadata.get("display_mode"),
            "display_gain": fid_preview.metadata.get("display_gain"),
            "baseline_lock_visual_only": fid_preview.metadata.get("baseline_lock_visual_only"),
            "preview_downsampling": fid_preview.metadata.get("preview_downsampling"),
            "fid_processing": fid_preview.processing_metadata.model_dump(mode="json"),
            "raw_upload_provenance": fid_preview.processing_metadata.raw_upload_provenance,
            "analysis_artifact_policy": fid_preview.processing_metadata.analysis_artifact_policy,
            "fid_quality": fid_preview.metadata.get("fid_quality"),
            "baseline_qa": fid_preview.metadata.get("baseline_qa"),
            "display": fid_preview.metadata.get("display"),
            "context_guidance": context_meta,
        },
    )
    return (preview, fid_preview)


@router.post("/carbon13/fid/preview", response_model=Carbon13UploadPreview, dependencies=[Depends(require_access_context)])
async def carbon13_fid_preview_route(
    request: Request,
    file: UploadFile = File(...),
    smiles: str | None = Form(default=None),
    proton_nmr_text: str | None = Form(default=None),
    solvent: str | None = Form(default=None),
    reference_ppm: float | None = Form(default=77.0),
    selected_preset: str | None = Form(default="balanced"),
    processing_preset: str | None = Form(default=None),
    zero_fill_factor: int | None = Form(default=None),
    line_broadening_hz: float | None = Form(default=None),
    apodization_mode: str = Form(default="exponential"),
    apply_group_delay: bool = Form(default=True),
    auto_phase: bool = Form(default=True),
    auto_baseline: bool = Form(default=True),
    phase_mode: str = Form(default="auto"),
    phase_p0: float = Form(default=0.0),
    phase_p1: float = Form(default=0.0),
    baseline_correction: str = Form(default="bernstein"),
    baseline_order: int = Form(default=3),
    baseline_lock: bool | None = Form(default=None),
    peak_sensitivity: float | None = Form(default=None),
    mask_solvent_regions: bool = Form(default=True),
    display_mode: str = Form(default="real"),
    vertical_gain: float = Form(default=1.0),
    debug_preview: bool = Form(default=False),
    context: AccessContext = Depends(require_access_context),
) -> Carbon13UploadPreview:
    filename = file.filename or "carbon13_dataset.zip"
    content = await file.read()
    raw_upload_provenance = _raw_fid_upload_provenance(
        request,
        filename=filename,
        content=content,
        content_type=file.content_type,
        user_id=context.user_id,
    )
    settings = _fid_settings_from_form(
        selected_preset=selected_preset,
        processing_preset=processing_preset,
        zero_fill_factor=zero_fill_factor,
        line_broadening_hz=line_broadening_hz,
        apodization_mode=apodization_mode,
        apply_group_delay=apply_group_delay,
        auto_phase=auto_phase,
        auto_baseline=auto_baseline,
        phase_mode=phase_mode,
        phase_p0=phase_p0,
        phase_p1=phase_p1,
        baseline_correction=baseline_correction,
        baseline_order=baseline_order,
        baseline_lock=baseline_lock,
        peak_sensitivity=peak_sensitivity,
        mask_solvent_regions=mask_solvent_regions,
        display_mode=display_mode,
        vertical_gain=vertical_gain,
        debug_preview=debug_preview,
    )
    try:
        preview, _fid_preview = _carbon13_raw_fid_preview_from_upload(
            filename=filename,
            content=content,
            solvent=solvent,
            smiles=smiles,
            proton_nmr_text=proton_nmr_text,
            reference_ppm=reference_ppm,
            settings=settings,
            raw_upload_provenance=raw_upload_provenance,
        )
    except (FIDProcessingError, PydanticValidationError, ValueError) as exc:
        raise _upload_http_400(exc, operation="¹³C raw FID preview") from exc
    _audit_from_context(
        request,
        context=context,
        event_type="carbon13.fid.preview",
        message="¹³C raw FID beta preview generated.",
        metadata={
            "filename": filename,
            "solvent": solvent,
            "observed_signal_count": preview.observed_signal_count,
        },
    )
    return preview


@router.post("/carbon13/fid/analyze", response_model=Carbon13AnalysisReport, dependencies=[Depends(require_access_context)])
async def carbon13_fid_analyze_route(
    request: Request,
    file: UploadFile = File(...),
    smiles: str = Form(...),
    proton_nmr_text: str | None = Form(default=None),
    solvent: str | None = Form(default=None),
    sample_id: str | None = Form(default=None),
    reference_ppm: float | None = Form(default=77.0),
    selected_preset: str | None = Form(default="balanced"),
    processing_preset: str | None = Form(default=None),
    zero_fill_factor: int | None = Form(default=None),
    line_broadening_hz: float | None = Form(default=None),
    apodization_mode: str = Form(default="exponential"),
    apply_group_delay: bool = Form(default=True),
    auto_phase: bool = Form(default=True),
    auto_baseline: bool = Form(default=True),
    phase_mode: str = Form(default="auto"),
    phase_p0: float = Form(default=0.0),
    phase_p1: float = Form(default=0.0),
    baseline_correction: str = Form(default="bernstein"),
    baseline_order: int = Form(default=3),
    baseline_lock: bool | None = Form(default=None),
    peak_sensitivity: float | None = Form(default=None),
    mask_solvent_regions: bool = Form(default=True),
    manual_peaks_json: str | None = Form(default=None),
    display_mode: str = Form(default="real"),
    vertical_gain: float = Form(default=1.0),
    debug_preview: bool = Form(default=False),
    context: AccessContext = Depends(require_access_context),
) -> Carbon13AnalysisReport:
    filename = file.filename or "carbon13_dataset.zip"
    content = await file.read()
    raw_upload_provenance = _raw_fid_upload_provenance(
        request,
        filename=filename,
        content=content,
        content_type=file.content_type,
        user_id=context.user_id,
    )
    settings = _fid_settings_from_form(
        selected_preset=selected_preset,
        processing_preset=processing_preset,
        zero_fill_factor=zero_fill_factor,
        line_broadening_hz=line_broadening_hz,
        apodization_mode=apodization_mode,
        apply_group_delay=apply_group_delay,
        auto_phase=auto_phase,
        auto_baseline=auto_baseline,
        phase_mode=phase_mode,
        phase_p0=phase_p0,
        phase_p1=phase_p1,
        baseline_correction=baseline_correction,
        baseline_order=baseline_order,
        baseline_lock=baseline_lock,
        peak_sensitivity=peak_sensitivity,
        mask_solvent_regions=mask_solvent_regions,
        display_mode=display_mode,
        vertical_gain=vertical_gain,
        debug_preview=debug_preview,
    )
    try:
        preview, _fid_preview = _carbon13_raw_fid_preview_from_upload(
            filename=filename,
            content=content,
            solvent=solvent,
            smiles=smiles,
            proton_nmr_text=proton_nmr_text,
            reference_ppm=reference_ppm,
            settings=settings,
            raw_upload_provenance=raw_upload_provenance,
        )
        reviewed_peaks = _manual_carbon13_peaks_from_json(manual_peaks_json, solvent=solvent)
        report = analyze_carbon13(
            smiles=smiles,
            peaks=reviewed_peaks or preview.peaks,
            solvent=solvent,
            sample_id=sample_id,
        )
    except (FIDProcessingError, StructureParseError, PydanticValidationError, ValueError) as exc:
        raise _upload_http_400(exc, operation="¹³C raw FID analysis") from exc
    combined_notes = list(report.notes)
    if manual_peaks_json and "Reviewer-adjusted ¹³C peak acceptance/exclusion decisions were used for analysis." not in combined_notes:
        combined_notes.append("Reviewer-adjusted ¹³C peak acceptance/exclusion decisions were used for analysis.")
    for warning in preview.warnings:
        if warning not in combined_notes:
            combined_notes.append(warning)
    report = report.model_copy(update={"notes": combined_notes})
    _audit_from_context(
        request,
        context=context,
        event_type="carbon13.fid.analyze",
        message="¹³C raw FID beta uploaded and analyzed.",
        metadata={"filename": filename, "sample_id": sample_id, "label": report.label},
    )
    return report


def create_app(settings: Settings | None = None) -> FastAPI:
    settings = settings or get_settings()
    session_factory = create_session_factory(settings.database_url)
    startup_issues = validate_startup_settings(settings)

    @asynccontextmanager
    async def app_lifespan(_: FastAPI) -> AsyncIterator[None]:
        init_db(session_factory)
        yield

    app = FastAPI(
        title="NMRCheck API",
        version=settings.release_version,
        description=(
            "API for rule-based ¹H NMR text analysis against a structure represented as SMILES, now with email verification, password reset, Alembic-ready persistence, optional Redis/RQ background workers, review workflow, admin metrics dashboards, processed spectrum upload for CSV/TSV/JCAMP-DX files, Bruker and Varian/Agilent 1D raw FID beta processing, E2E regression scaffolds, deployment diagnostics, scientific validation fixtures, CI release-health checks, evidence-confidence reporting, and ¹H/¹³C solvent-aware spectral evidence scoring."
        ),
        lifespan=app_lifespan,
    )
    if settings.allowed_origins:
        app.add_middleware(
            CORSMiddleware,
            allow_origins=list(settings.allowed_origins),
            allow_credentials=True,
            allow_methods=["*"],
            allow_headers=["*"],
        )
    app.include_router(router)
    from .nmr2d_routes import router as nmr2d_router

    app.include_router(nmr2d_router)
    app.state.session_factory = session_factory
    app.state.settings = settings
    app.state.api_key = settings.api_key
    app.state.startup_issues = startup_issues
    return app
