from __future__ import annotations

from pathlib import Path

from fastapi.testclient import TestClient

from nmrcheck.api import create_app
from nmrcheck.nmr2d_analyzer import analyze_nmr2d
from nmrcheck.nmr2d_parser import parse_processed_2d_nmr
from nmrcheck.settings import Settings

FIXTURES = Path(__file__).parent / "fixtures" / "week25"
PROTON_TEXT = "¹H NMR (400 MHz, CDCl3) δ 3.65 (q, J = 7.1 Hz, 2H), 1.26 (t, J = 7.1 Hz, 3H), 2.10 (br s, 1H)"
CARBON_TEXT = "¹³C NMR (101 MHz, CDCl3) δ 58.3, 18.2."


def _client(tmp_path, *, enabled: bool) -> tuple[TestClient, dict[str, str]]:
    app = create_app(
        Settings(
            database_url=f"sqlite:///{tmp_path / 'week25_2d.sqlite3'}",
            require_verified_email=False,
            api_key="test-key",
            enable_2d_nmr=enabled,
        )
    )
    return TestClient(app), {"x-api-key": "test-key"}


def _upload(filename: str) -> tuple[str, bytes, str]:
    return (filename, (FIXTURES / filename).read_bytes(), "text/csv")


def test_parse_processed_cosy_peak_table() -> None:
    preview = parse_processed_2d_nmr("cosy_ethanol.csv", (FIXTURES / "cosy_ethanol.csv").read_bytes())

    assert preview.experiments == ["COSY"]
    assert preview.peak_count == 2
    assert preview.peaks[0].proton1_ppm == 3.65
    assert preview.peaks[0].proton2_ppm == 1.26
    assert preview.metadata["raw_2d_fid_processing"] == "not_implemented_guarded_release"


def test_parse_hsqc_and_hmbc_with_contour_preview() -> None:
    hsqc = parse_processed_2d_nmr(
        "hsqc_ethanol.csv",
        (FIXTURES / "hsqc_ethanol.csv").read_bytes(),
        include_contour_preview=True,
    )
    hmbc = parse_processed_2d_nmr("hmbc_ethanol.csv", (FIXTURES / "hmbc_ethanol.csv").read_bytes())

    assert hsqc.experiments == ["HSQC"]
    assert hsqc.peaks[0].proton1_ppm == 3.65
    assert hsqc.peaks[0].carbon_ppm == 58.3
    assert len(hsqc.contour_preview) == 2
    assert hmbc.experiments == ["HMBC"]


def test_2d_analyzer_links_current_1d_context_and_requires_review() -> None:
    preview = parse_processed_2d_nmr("hsqc_ethanol.csv", (FIXTURES / "hsqc_ethanol.csv").read_bytes())

    report = analyze_nmr2d(
        smiles="CCO",
        preview=preview,
        sample_id="ethanol-2d",
        solvent="CDCl3",
        proton_nmr_text=PROTON_TEXT,
        carbon13_text=CARBON_TEXT,
    )

    assert report.label in {"supportive", "review"}
    assert report.linked_1d_peak_count == 2
    assert report.evidence_summary["human_review_required"] is True
    assert all(peak.evidence_label == "supportive" for peak in report.peaks)
    assert any("human review" in note.lower() for note in report.notes)


def test_2d_feature_flag_disabled_blocks_preview(tmp_path) -> None:
    client, headers = _client(tmp_path, enabled=False)
    with client:
        status = client.get("/nmr2d/status")
        blocked = client.post("/nmr2d/preview", headers=headers, files={"file": _upload("cosy_ethanol.csv")})

    assert status.status_code == 200
    assert status.json()["enabled"] is False
    assert blocked.status_code == 404


def test_2d_feature_flag_enabled_preview_analyze_and_run_lookup(tmp_path) -> None:
    client, headers = _client(tmp_path, enabled=True)
    with client:
        status = client.get("/nmr2d/status")
        preview = client.post(
            "/nmr2d/preview",
            headers=headers,
            data={"include_contour_preview": "true"},
            files={"file": _upload("hsqc_ethanol.csv")},
        )
        analysis = client.post(
            "/nmr2d/analyze",
            headers=headers,
            data={
                "smiles": "CCO",
                "sample_id": "ethanol-2d",
                "solvent": "CDCl3",
                "proton_nmr_text": PROTON_TEXT,
                "carbon13_text": CARBON_TEXT,
            },
            files={"file": _upload("hsqc_ethanol.csv")},
        )
        run_id = analysis.json()["run_id"]
        run = client.get(f"/nmr2d/runs/{run_id}", headers=headers)
        report = client.get(f"/nmr2d/runs/{run_id}/report", headers=headers)
        raw_stub = client.post("/nmr2d/raw/preview", headers=headers)

    assert status.json()["enabled"] is True
    assert preview.status_code == 200, preview.text
    assert preview.json()["experiments"] == ["HSQC"]
    assert analysis.status_code == 200, analysis.text
    assert analysis.json()["run_id"] == run_id
    assert analysis.json()["metadata"]["raw_2d_fid_processing"] == "not_implemented"
    assert run.status_code == 200, run.text
    assert run.json()["report"]["run_id"] == run_id
    assert run.json()["review_status"] == "pending_review"
    assert report.status_code == 200, report.text
    assert report.json()["run_id"] == run_id
    assert report.json()["evidence_summary"]["human_review_required"] is True
    assert raw_stub.status_code == 200, raw_stub.text
    assert raw_stub.json()["implemented"] is False
