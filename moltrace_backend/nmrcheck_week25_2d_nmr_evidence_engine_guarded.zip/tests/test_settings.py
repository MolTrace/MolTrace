from nmrcheck.settings import normalize_database_url


def test_normalize_postgres_scheme() -> None:
    assert normalize_database_url("postgresql://user:pass@host/db") == "postgresql+psycopg://user:pass@host/db"
