
from __future__ import annotations

from datetime import datetime
from typing import Any, Literal

from pydantic import BaseModel, ConfigDict, EmailStr, Field, field_validator

from .nmr2d_models import (
    NMR2DAnalyzeRequest,
    NMR2DAnalyzeResult,
    NMR2DCorrelationEvidence,
    NMR2DExperimentType,
    NMR2DPeak,
    NMR2DPreviewReport,
    NMR2DRunRecord,
)

DiagnosticLabel = Literal[
    "consistent",
    "possible_overlap_or_missing_labile_signals",
    "possible_impurity_or_incorrect_assignment",
    "invalid_input",
]

JobStatus = Literal["pending", "queued", "processing", "completed", "failed"]
ActionTokenPurpose = Literal["verify_email", "reset_password"]
ReviewStatus = Literal["pending_review", "approved", "rejected", "needs_revision"]
ReviewAction = Literal["approve", "reject", "override", "request_changes", "review"]
FIDPresetId = Literal[
    "baseline_preserve",
    "balanced",
    "sensitive_weak_peaks",
    "higher_resolution",
    "custom",
]
FIDQualityLabel = Literal["good", "review", "poor", "failed"]


class RawArchiveRecord(BaseModel):
    model_config = ConfigDict(extra="forbid")

    id: int
    created_at: datetime
    user_id: int | None = None
    filename: str = Field(min_length=1, max_length=255)
    content_type: str | None = Field(default=None, max_length=100)
    byte_size: int = Field(ge=0)
    sha256: str = Field(min_length=64, max_length=64)
    storage_path: str = Field(min_length=1)
    vendor_detected: str = Field(min_length=1, max_length=100)
    dataset_root: str | None = Field(default=None, max_length=500)
    required_files_present: bool = False
    files_found: list[str] = Field(default_factory=list)
    acquisition_metadata: dict[str, Any] = Field(default_factory=dict)
    warnings: list[str] = Field(default_factory=list)
    immutable: bool = True
    raw_archive_id: str | None = Field(default=None, min_length=64, max_length=64)


class RawArchivePreview(BaseModel):
    model_config = ConfigDict(extra="forbid")

    archive: RawArchiveRecord
    already_stored: bool = False
    provenance: dict[str, Any] = Field(default_factory=dict)


class RawArchiveExportManifest(BaseModel):
    model_config = ConfigDict(extra="forbid")

    exported_at: datetime
    raw_archive: RawArchiveRecord | None = None
    raw_archive_id: str | None = None
    sha256: str | None = Field(default=None, min_length=64, max_length=64)
    original_filename: str | None = None
    storage_backend: str | None = None
    include_original_archive: bool = False
    sha256_verified: bool = False
    files: list[str] = Field(default_factory=list)
    warnings: list[str] = Field(default_factory=list)


class Peak(BaseModel):
    model_config = ConfigDict(extra="forbid")

    shift_ppm: float = Field(ge=-50.0, le=260.0)
    multiplicity: str = Field(min_length=1, max_length=20)
    integration_h: float = Field(gt=0.0, le=50.0)
    j_values_hz: list[float] = Field(default_factory=list)


class StructureSummary(BaseModel):
    model_config = ConfigDict(extra="forbid")

    smiles: str
    formula: str
    molecular_weight: float
    total_hydrogens: int
    labile_hydrogens: int
    non_labile_hydrogens: int
    aromatic_protons: int
    aliphatic_protons: int
    aromatic_atom_count: int


class SolventHeuristicHit(BaseModel):
    model_config = ConfigDict(extra="forbid")

    solvent: str
    signal_label: str
    expected_ppm: float
    observed_ppm: float
    delta_ppm: float = Field(ge=0.0)
    kind: Literal["residual", "water", "exchange", "impurity"]


class AnalysisInputs(BaseModel):
    model_config = ConfigDict(
        extra="forbid",
        json_schema_extra={
            "examples": [
                {
                    "sample_id": "cmpd-001",
                    "smiles": "CCO",
                    "nmr_text": "¹H NMR (400 MHz, CDCl3) δ 3.65 (q, J = 7.1 Hz, 2H), 1.26 (t, J = 7.1 Hz, 3H), 2.10 (br s, 1H)",
                    "solvent": "CDCl3",
                }
            ]
        },
    )

    sample_id: str | None = Field(default=None, max_length=100)
    smiles: str = Field(min_length=1, max_length=500)
    nmr_text: str = Field(min_length=3, max_length=10_000)
    solvent: str | None = Field(default=None, max_length=50)

    @field_validator("sample_id", "solvent", mode="before")
    @classmethod
    def _optional_trim(cls, value: str | None) -> str | None:
        if value is None:
            return None
        value = str(value).strip()
        return value or None

    @field_validator("smiles", "nmr_text", mode="before")
    @classmethod
    def _required_trim(cls, value: str) -> str:
        value = str(value).strip()
        if not value:
            raise ValueError("This field cannot be empty.")
        return value


class AnalysisValidationInputs(BaseModel):
    model_config = ConfigDict(extra="forbid")

    sample_id: str | None = Field(default=None, max_length=100)
    smiles: str | None = Field(default=None, max_length=500)
    nmr_text: str | None = Field(default=None, max_length=10_000)
    solvent: str | None = Field(default=None, max_length=50)

    @field_validator("sample_id", "smiles", "nmr_text", "solvent", mode="before")
    @classmethod
    def _optional_trim(cls, value: str | None) -> str | None:
        if value is None:
            return None
        value = str(value).strip()
        return value or None


class AnalysisReport(BaseModel):
    model_config = ConfigDict(extra="forbid")

    label: DiagnosticLabel
    confidence: float = Field(ge=0.0, le=1.0)
    sample_id: str | None = None
    solvent: str | None = None
    expected_total_h: int
    expected_non_labile_h: int
    expected_labile_h: int
    observed_total_h: float
    rounded_observed_total_h: int
    delta_total_h: int
    parsed_peak_count: int
    notes: list[str]
    peaks: list[Peak]
    structure: StructureSummary
    solvent_signal_hits: list[SolventHeuristicHit] = Field(default_factory=list)
    pattern_alerts: list[str] = Field(default_factory=list)
    proton_evidence_score: float | None = Field(default=None, ge=0.0, le=1.0)
    proton_evidence: dict[str, Any] = Field(default_factory=dict)


class BatchAnalysisInputs(BaseModel):
    model_config = ConfigDict(extra="forbid")

    items: list[AnalysisInputs] = Field(min_length=1, max_length=100)


class BatchAnalysisReport(BaseModel):
    model_config = ConfigDict(extra="forbid")

    items: list[AnalysisReport]
    total_items: int


class ValidationReport(BaseModel):
    model_config = ConfigDict(extra="forbid")

    sample_id: str | None = None
    solvent: str | None = None
    structure_valid: bool
    nmr_text_valid: bool
    structure_nmr_match: bool = False
    analysis_ready: bool = False
    parseable_peak_count: int
    expected_visible_h: float | None = None
    observed_total_h: float | None = None
    adjusted_observed_total_h: float | None = None
    delta_visible_h: float | None = None
    parsed_peaks: list[Peak] = Field(default_factory=list)
    structure: StructureSummary | None = None
    warnings: list[str] = Field(default_factory=list)
    errors: list[str] = Field(default_factory=list)




class SpectrumPoint(BaseModel):
    model_config = ConfigDict(extra="forbid")

    shift_ppm: float = Field(ge=-50.0, le=260.0)
    intensity: float


class SpectrumPeakMatch(BaseModel):
    model_config = ConfigDict(extra="forbid")

    reference_peak: Peak
    extracted_peak: Peak
    reference_raw_text: str
    reference_shift_start_ppm: float | None = Field(default=None, ge=-5.0, le=20.0)
    reference_shift_end_ppm: float | None = Field(default=None, ge=-5.0, le=20.0)
    delta_ppm: float = Field(ge=0.0)
    status: Literal["matched", "shifted"]
    multiplicity_match: bool
    integration_match: bool


class SpectrumMissingReferencePeak(BaseModel):
    model_config = ConfigDict(extra="forbid")

    reference_peak: Peak
    reference_raw_text: str
    reference_shift_start_ppm: float | None = Field(default=None, ge=-5.0, le=20.0)
    reference_shift_end_ppm: float | None = Field(default=None, ge=-5.0, le=20.0)


class SpectrumExtraPeak(BaseModel):
    model_config = ConfigDict(extra="forbid")

    extracted_peak: Peak


class SpectrumComparisonReport(BaseModel):
    model_config = ConfigDict(extra="forbid")

    matched: list[SpectrumPeakMatch] = Field(default_factory=list)
    missing_reference: list[SpectrumMissingReferencePeak] = Field(default_factory=list)
    extra_spectrum: list[SpectrumExtraPeak] = Field(default_factory=list)
    matched_count: int = Field(ge=0, default=0)
    shifted_count: int = Field(ge=0, default=0)
    missing_count: int = Field(ge=0, default=0)
    extra_count: int = Field(ge=0, default=0)
    multiplicity_match_count: int = Field(ge=0, default=0)
    integration_match_count: int = Field(ge=0, default=0)
    total_shift_delta_ppm: float = Field(ge=0.0, default=0.0)
    reference_total_h: float = Field(ge=0.0, default=0.0)
    extracted_total_h: float = Field(ge=0.0, default=0.0)
    structure_visible_h: float | None = Field(default=None, ge=0.0)
    reference_structure_delta_h: float | None = None
    extracted_structure_delta_h: float | None = None
    reference_extracted_delta_h: float | None = None
    structure_reference_mismatch: bool = False
    structure_extracted_mismatch: bool = False
    notes: list[str] = Field(default_factory=list)


class SpectrumPreviewReport(BaseModel):
    model_config = ConfigDict(extra="forbid")

    filename: str
    format_detected: str
    source_mode: Literal["trace", "peak_table"]
    point_count: int = Field(ge=0)
    preview_points: list[SpectrumPoint] = Field(default_factory=list)
    inferred_peaks: list[Peak] = Field(default_factory=list)
    inferred_nmr_text: str = ""
    reference_nmr_text_normalized: str | None = None
    reference_peaks: list[Peak] = Field(default_factory=list)
    comparison: SpectrumComparisonReport | None = None
    warnings: list[str] = Field(default_factory=list)
    metadata: dict[str, Any] = Field(default_factory=dict)


class SpectrumAnalyzeResult(BaseModel):
    model_config = ConfigDict(extra="forbid")

    preview: SpectrumPreviewReport
    generated_inputs: AnalysisInputs
    analysis: AnalysisReport


class FIDProcessingSettings(BaseModel):
    model_config = ConfigDict(extra="forbid")

    selected_preset: FIDPresetId = "balanced"
    zero_fill_factor: int = Field(default=2, ge=1, le=8)
    fourier_transform: str = "fft_1d"
    apodization_mode: str = "exponential"
    line_broadening_hz: float = Field(default=0.3, ge=0.0, le=10.0)
    apply_group_delay: bool = True
    auto_phase: bool = True
    auto_baseline: bool = True
    phase_mode: str = "auto"
    phase_p0: float = 0.0
    phase_p1: float = 0.0
    baseline_correction: str = "bernstein"
    baseline_order: int = Field(default=3, ge=1, le=8)
    baseline_lock_visual_only: bool = True
    peak_sensitivity: float | None = Field(default=None, ge=0.02, le=0.45)
    mask_solvent_regions: bool = True
    max_preview_points: int = Field(default=700, ge=100, le=5000)
    display_mode: Literal["real", "magnifier"] = "real"
    vertical_gain: float = Field(default=1.0, ge=1.0, le=1_000_000.0)
    debug_preview: bool = False


class FIDProcessingRecipe(BaseModel):
    model_config = ConfigDict(extra="forbid")

    vendor: str = "unknown"
    nucleus: str = "1H"
    processing_preset: str = "balanced"
    digital_filter_correction: str = "auto"
    apodization_mode: str = "exponential"
    line_broadening_hz: float = Field(default=0.3, ge=0.0, le=10.0)
    zero_fill_factor: int = Field(default=2, ge=1, le=8)
    fourier_transform: str = "fft_1d"
    phase_mode: str = "auto"
    phase_p0: float = 0.0
    phase_p1: float = 0.0
    baseline_correction: str = "bernstein"
    baseline_order: int = Field(default=3, ge=1, le=8)
    reference_ppm: float | None = None
    solvent: str | None = None
    peak_sensitivity: float | None = Field(default=None, ge=0.02, le=0.45)
    mask_solvent_regions: bool = True
    display_mode: Literal["real", "magnifier"] = "real"
    vertical_gain: float = Field(default=1.0, ge=1.0, le=1_000_000.0)
    debug_preview: bool = False


class FIDProcessingPreset(BaseModel):
    model_config = ConfigDict(extra="forbid")

    id: FIDPresetId
    label: str
    description: str
    settings: dict[str, Any] = Field(default_factory=dict)


class FIDQADiagnostics(BaseModel):
    model_config = ConfigDict(extra="forbid")

    quality_score: float = Field(ge=0.0, le=1.0)
    quality_label: FIDQualityLabel
    dynamic_range: float = Field(ge=0.0)
    noise_estimate: float = Field(ge=0.0)
    baseline_offset_ratio: float = Field(ge=0.0)
    saturation_clipping_proxy: float = Field(ge=0.0, le=1.0)
    point_count: int = Field(ge=0)
    warnings: list[str] = Field(default_factory=list)


class FIDProcessingMetadata(BaseModel):
    model_config = ConfigDict(extra="forbid")

    vendor_format_detected: str
    dataset_folder: str
    selected_preset: str = "Balanced"
    nucleus: str = "1H"
    solvent: str | None = None
    reference_ppm: float | None = None
    reference_shift_applied_ppm: float = 0.0
    reference_peak_selection: dict[str, Any] = Field(default_factory=dict)
    group_delay_correction_applied: bool = False
    automatic_phase_correction: bool = False
    automatic_baseline_correction: bool = False
    zero_filling: dict[str, Any] = Field(default_factory=dict)
    line_broadening: dict[str, Any] = Field(default_factory=dict)
    phase_settings: dict[str, Any] = Field(default_factory=dict)
    baseline_correction: dict[str, Any] = Field(default_factory=dict)
    digital_filter_correction_status: str = "not_applied"
    qa_diagnostics: FIDQADiagnostics
    processing_parameters: dict[str, Any] = Field(default_factory=dict)
    processing_recipe: FIDProcessingRecipe = Field(default_factory=FIDProcessingRecipe)
    acquisition_parameters: dict[str, Any] = Field(default_factory=dict)
    raw_dataset_files_found: dict[str, bool] = Field(default_factory=dict)
    raw_upload_provenance: dict[str, Any] = Field(default_factory=dict)
    analysis_artifact_policy: dict[str, Any] = Field(default_factory=dict)
    nmrglue_used: bool = False
    pulseprogram_present: bool = False
    pdata_present: bool = False
    extracted_peak_list: list[Peak] = Field(default_factory=list)
    reviewer_signoff_required: bool = True
    human_review_status: str = "pending_review"
    warnings: list[str] = Field(default_factory=list)


class FIDPreviewReport(SpectrumPreviewReport):
    model_config = ConfigDict(extra="forbid")

    fid_run_id: int | None = None
    processing_metadata: FIDProcessingMetadata


class FIDProcessResult(BaseModel):
    model_config = ConfigDict(extra="forbid")

    preview: FIDPreviewReport
    generated_inputs: AnalysisInputs
    analysis: AnalysisReport


class FIDRunReviewCreate(BaseModel):
    model_config = ConfigDict(extra="forbid")

    action: ReviewAction | None = None
    comment: str | None = Field(default=None, max_length=4000)


class FIDRunReviewDecisionRecord(BaseModel):
    model_config = ConfigDict(extra="forbid")

    id: int
    run_id: int
    reviewer_user_id: int
    action: ReviewAction
    previous_status: ReviewStatus
    new_status: ReviewStatus
    comment: str | None = None
    created_at: datetime


class FIDRunRecord(BaseModel):
    model_config = ConfigDict(extra="forbid")

    id: int
    user_id: int | None = None
    analysis_id: int | None = None
    raw_archive_id: int | None = None
    raw_sha256: str | None = Field(default=None, min_length=64, max_length=64)
    created_at: datetime
    sample_id: str | None = None
    filename: str
    selected_preset: str
    quality_label: FIDQualityLabel
    quality_score: float = Field(ge=0.0, le=1.0)
    review_status: ReviewStatus = "pending_review"
    reviewer_user_id: int | None = None
    reviewed_at: datetime | None = None
    reviewer_comment: str | None = None
    preview: FIDPreviewReport
    processing_metadata: FIDProcessingMetadata
    processing_recipe: dict[str, Any] = Field(default_factory=dict)
    derived_spectrum_metadata: dict[str, Any] = Field(default_factory=dict)
    review_decision_count: int = 0


class FIDRunReport(BaseModel):
    model_config = ConfigDict(extra="forbid")

    run: FIDRunRecord
    raw_fid_provenance: dict[str, Any] = Field(default_factory=dict)
    processing_assumptions: dict[str, Any] = Field(default_factory=dict)
    qa_diagnostics: FIDQADiagnostics
    inferred_peak_list: list[Peak] = Field(default_factory=list)
    review_decisions: list[FIDRunReviewDecisionRecord] = Field(default_factory=list)


class Carbon13Peak(BaseModel):
    model_config = ConfigDict(extra="forbid")

    shift_ppm: float = Field(ge=-50.0, le=260.0)
    intensity: float | None = None
    assignment: str | None = Field(default=None, max_length=200)
    region: str | None = None
    carbon_type: str | None = None
    is_likely_solvent: bool = False
    is_likely_impurity: bool = False
    impurity_matches: list[dict[str, Any]] = Field(default_factory=list)
    notes: list[str] = Field(default_factory=list)


class Carbon13Inputs(BaseModel):
    model_config = ConfigDict(extra="forbid")

    smiles: str = Field(min_length=1, max_length=500)
    carbon13_text: str = Field(min_length=1, max_length=20_000)
    solvent: str | None = Field(default=None, max_length=50)
    sample_id: str | None = Field(default=None, max_length=100)

    @field_validator("smiles", "carbon13_text", mode="before")
    @classmethod
    def _required_trim(cls, value: str) -> str:
        value = str(value).strip()
        if not value:
            raise ValueError("This field cannot be empty.")
        return value

    @field_validator("solvent", "sample_id", mode="before")
    @classmethod
    def _optional_trim(cls, value: str | None) -> str | None:
        if value is None:
            return None
        value = str(value).strip()
        return value or None


class Carbon13UploadPreview(BaseModel):
    model_config = ConfigDict(extra="forbid")

    filename: str
    source_mode: str
    observed_signal_count: int
    peaks: list[Carbon13Peak] = Field(default_factory=list)
    warnings: list[str] = Field(default_factory=list)
    metadata: dict[str, Any] = Field(default_factory=dict)


class Carbon13RegionSummary(BaseModel):
    model_config = ConfigDict(extra="forbid")

    region: str
    count: int
    shifts_ppm: list[float] = Field(default_factory=list)


class Carbon13AnalysisReport(BaseModel):
    model_config = ConfigDict(extra="forbid")

    sample_id: str | None = None
    smiles: str
    solvent: str | None = None
    expected_carbon_atoms: int
    observed_carbon_signals: int
    delta_carbon_signals: int
    label: Literal[
        "carbon_count_consistent",
        "possible_overlap_or_missing_weak_carbons",
        "possible_extra_carbons_or_impurity",
        "invalid_input",
    ]
    confidence: float = Field(ge=0.0, le=1.0)
    peaks: list[Carbon13Peak] = Field(default_factory=list)
    region_summary: list[Carbon13RegionSummary] = Field(default_factory=list)
    solvent_warnings: list[str] = Field(default_factory=list)
    notes: list[str] = Field(default_factory=list)
    carbon13_match_score: float | None = None
    carbon_count_score: float | None = None
    region_consistency_score: float | None = None
    solvent_exclusion_score: float | None = None
    dept_apt_consistency_score: float | None = None
    expected_region_summary: dict[str, int] = Field(default_factory=dict)
    observed_region_summary: dict[str, int] = Field(default_factory=dict)
    evidence_summary: list[str] = Field(default_factory=list)
    structure: StructureSummary | None = None


class ProtonEvidencePeak(BaseModel):
    model_config = ConfigDict(extra="forbid")

    shift_ppm: float = Field(ge=-5.0, le=20.0)
    multiplicity: str
    integration_h: float
    region: str
    is_likely_solvent: bool = False
    is_likely_water: bool = False
    notes: list[str] = Field(default_factory=list)


class ProtonEvidenceReport(BaseModel):
    model_config = ConfigDict(extra="forbid")

    sample_id: str | None = None
    smiles: str
    solvent: str | None = None
    expected_total_h: int
    expected_non_labile_h: int
    expected_labile_h: int
    observed_total_h: float
    observed_non_solvent_h: float
    solvent_or_water_h: float
    delta_total_h: float
    delta_non_solvent_h: float
    label: DiagnosticLabel
    overall_score: float = Field(ge=0.0, le=1.0)
    integration_score: float = Field(ge=0.0, le=1.0)
    solvent_exclusion_score: float = Field(ge=0.0, le=1.0)
    region_support_score: float = Field(ge=0.0, le=1.0)
    peaks: list[ProtonEvidencePeak] = Field(default_factory=list)
    notes: list[str] = Field(default_factory=list)
    warnings: list[str] = Field(default_factory=list)
    structure: StructureSummary | None = None


class SpectralEvidenceScore(BaseModel):
    model_config = ConfigDict(extra="forbid")

    nucleus: str
    score: float = Field(ge=0.0, le=1.0)
    matched_count: int = 0
    unmatched_observed_count: int = 0
    unmatched_expected_count: int = 0
    notes: list[str] = Field(default_factory=list)


class StoredAnalysisRecord(BaseModel):
    model_config = ConfigDict(extra="forbid")

    id: int
    created_at: datetime
    label: DiagnosticLabel
    sample_id: str | None = None
    solvent: str | None = None
    smiles: str
    nmr_text: str
    expected_total_h: int
    observed_total_h: float
    confidence: float
    notes: list[str]
    parsed_peak_count: int = 0
    delta_total_h: int = 0
    job_id: int | None = None
    user_id: int | None = None
    review_status: ReviewStatus = "pending_review"
    reviewer_user_id: int | None = None
    reviewed_at: datetime | None = None
    review_comment: str | None = None
    final_label: str | None = None
    hours_saved_estimate: float = 0.0


class FullStoredAnalysisRecord(StoredAnalysisRecord):
    model_config = ConfigDict(extra="forbid")

    full_report: AnalysisReport


class ProjectCreate(BaseModel):
    model_config = ConfigDict(extra="forbid")

    name: str = Field(min_length=1, max_length=200)
    description: str | None = Field(default=None, max_length=2000)

    @field_validator("name", "description", mode="before")
    @classmethod
    def _trim_project_fields(cls, value: str | None) -> str | None:
        if value is None:
            return None
        value = str(value).strip()
        return value or None


class ProjectRecord(BaseModel):
    model_config = ConfigDict(extra="forbid")

    id: int
    user_id: int
    name: str
    description: str | None = None
    created_at: datetime
    updated_at: datetime
    sample_count: int = 0
    analysis_count: int = 0
    linked_analysis_count: int = 0


class ProjectSampleCreate(BaseModel):
    model_config = ConfigDict(extra="forbid")

    sample_id: str | None = Field(default=None, max_length=100)
    smiles: str = Field(min_length=1, max_length=500)
    nmr_text: str = Field(min_length=3, max_length=10_000)
    solvent: str | None = Field(default=None, max_length=50)
    analysis_id: int | None = Field(default=None, ge=1)

    @field_validator("sample_id", "solvent", mode="before")
    @classmethod
    def _trim_optional_sample_fields(cls, value: str | None) -> str | None:
        if value is None:
            return None
        value = str(value).strip()
        return value or None

    @field_validator("smiles", "nmr_text", mode="before")
    @classmethod
    def _trim_required_sample_fields(cls, value: str) -> str:
        value = str(value).strip()
        if not value:
            raise ValueError("This field cannot be empty.")
        return value


class ProjectSampleAnalysisLink(BaseModel):
    model_config = ConfigDict(extra="forbid")

    analysis_id: int = Field(ge=1)


class ProjectSampleRecord(BaseModel):
    model_config = ConfigDict(extra="forbid")

    id: int
    project_id: int
    analysis_id: int | None = None
    sample_id: str | None = None
    smiles: str
    nmr_text: str
    solvent: str | None = None
    created_at: datetime
    updated_at: datetime


class JobRecord(BaseModel):
    model_config = ConfigDict(extra="forbid")

    id: int
    created_at: datetime
    user_id: int | None = None
    job_name: str | None = None
    uploaded_filename: str | None = None
    status: JobStatus
    total_items: int
    completed_items: int
    started_at: datetime | None = None
    finished_at: datetime | None = None
    error_message: str | None = None
    backend_job_id: str | None = None
    queue_name: str | None = None
    review_required: bool = True
    review_completion_rate: float = 0.0


class AsyncJobAccepted(BaseModel):
    model_config = ConfigDict(extra="forbid")

    job: JobRecord
    accepted: bool = True
    detail: str = "Job accepted and queued for background processing."
    queue_backend: Literal["rq", "fastapi-background"]


class UserCreate(BaseModel):
    model_config = ConfigDict(extra="forbid")

    email: EmailStr
    password: str = Field(min_length=8, max_length=512)


class UserLogin(BaseModel):
    model_config = ConfigDict(extra="forbid")

    email: EmailStr
    password: str = Field(min_length=8, max_length=512)


class UserPublic(BaseModel):
    model_config = ConfigDict(extra="forbid")

    id: int
    email: EmailStr
    is_active: bool
    is_admin: bool
    is_verified: bool
    created_at: datetime
    verified_at: datetime | None = None


class AccessTokenResponse(BaseModel):
    model_config = ConfigDict(extra="forbid")

    access_token: str
    token_type: Literal["bearer"] = "bearer"
    expires_at: datetime
    user: UserPublic


class MessageResponse(BaseModel):
    model_config = ConfigDict(extra="forbid")

    detail: str


class EmailActionRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")

    email: EmailStr


class PasswordResetConfirm(BaseModel):
    model_config = ConfigDict(extra="forbid")

    token: str = Field(min_length=10, max_length=512)
    new_password: str = Field(min_length=8, max_length=512)


class TokenActionPreview(BaseModel):
    model_config = ConfigDict(extra="forbid")

    detail: str
    token: str | None = None
    expires_at: datetime | None = None


class EmailOutboxRecord(BaseModel):
    model_config = ConfigDict(extra="forbid")

    id: int
    created_at: datetime
    to_email: EmailStr
    subject: str
    body: str
    purpose: ActionTokenPurpose | None = None


class QueueWorkerStatus(BaseModel):
    model_config = ConfigDict(extra="forbid")

    backend: Literal["rq", "fastapi-background"]
    redis_configured: bool
    queue_name: str
    detail: str


class ReviewDecisionCreate(BaseModel):
    model_config = ConfigDict(extra="forbid")

    comment: str | None = Field(default=None, max_length=4000)
    final_label: str | None = Field(default=None, max_length=100)
    hours_saved_estimate: float | None = Field(default=None, ge=0.0, le=100.0)


class ReviewDecisionRecord(BaseModel):
    model_config = ConfigDict(extra="forbid")

    id: int
    analysis_id: int
    reviewer_user_id: int
    action: ReviewAction
    previous_status: ReviewStatus
    new_status: ReviewStatus
    comment: str | None = None
    previous_label: str | None = None
    final_label: str | None = None
    created_at: datetime


class ReviewQueueItem(BaseModel):
    model_config = ConfigDict(extra="forbid")

    analysis: StoredAnalysisRecord
    evidence_notes: list[str] = Field(default_factory=list)
    recommended_action: ReviewStatus | None = None


class AuditEventRecord(BaseModel):
    model_config = ConfigDict(extra="forbid")

    id: int
    created_at: datetime
    event_type: str
    message: str
    actor_user_id: int | None = None
    actor_email: str | None = None
    entity_type: str | None = None
    entity_id: int | None = None
    metadata: dict[str, Any] = Field(default_factory=dict)


class NMR2DEvidenceReportSection(BaseModel):
    model_config = ConfigDict(extra="forbid")

    run_id: int
    report_url: str
    experiment_type: str
    peak_count: int = 0
    matched_correlations: int = 0
    suspicious_correlations: int = 0
    evidence_score: float = Field(ge=0.0, le=1.0)
    cosy_connectivity_notes: list[str] = Field(default_factory=list)
    hsqc_hmqc_direct_attachment_notes: list[str] = Field(default_factory=list)
    hmbc_long_range_notes: list[str] = Field(default_factory=list)
    missing_extra_correlation_notes: list[str] = Field(default_factory=list)
    human_review_status: ReviewStatus = "pending_review"
    score_components: dict[str, Any] = Field(default_factory=dict)
    warnings: list[str] = Field(default_factory=list)


class AnalysisEvidenceReport(BaseModel):
    model_config = ConfigDict(extra="forbid")

    analysis: FullStoredAnalysisRecord
    structure: StructureSummary
    parsed_nmr_text: str
    parsed_peaks: list[Peak] = Field(default_factory=list)
    spectrum_derived_matched_peaks: list[Peak] = Field(default_factory=list)
    unmatched_peaks: list[Peak] = Field(default_factory=list)
    impurity_candidates: list[str] = Field(default_factory=list)
    confidence_notes: list[str] = Field(default_factory=list)
    review_decisions: list[ReviewDecisionRecord] = Field(default_factory=list)
    audit_events: list[AuditEventRecord] = Field(default_factory=list)
    audit_metadata: dict[str, Any] = Field(default_factory=dict)
    nmr2d_evidence: list[NMR2DEvidenceReportSection] = Field(default_factory=list)
    time_saved_estimate: float = 0.0


class StoredReportRecord(BaseModel):
    model_config = ConfigDict(extra="forbid")

    id: int
    analysis_id: int
    user_id: int | None = None
    created_at: datetime
    version: int = 1
    title: str
    report: AnalysisEvidenceReport


class SampleDetailRecord(BaseModel):
    model_config = ConfigDict(extra="forbid")

    sample: ProjectSampleRecord
    latest_analysis: StoredAnalysisRecord | None = None
    notes: list[str] = Field(default_factory=list)
    reports_count: int = 0


class SampleTimelineRecord(BaseModel):
    model_config = ConfigDict(extra="forbid")

    sample: ProjectSampleRecord
    analysis_ids: list[int] = Field(default_factory=list)
    review_decisions: list[ReviewDecisionRecord] = Field(default_factory=list)
    audit_events: list[AuditEventRecord] = Field(default_factory=list)


class SampleReportsRecord(BaseModel):
    model_config = ConfigDict(extra="forbid")

    sample: ProjectSampleRecord
    reports: list[StoredReportRecord] = Field(default_factory=list)


class ProjectDashboardRecord(BaseModel):
    model_config = ConfigDict(extra="forbid")

    project: ProjectRecord
    sample_count: int = 0
    analysis_count: int = 0
    approved_reviews: int = 0
    rejected_reviews: int = 0
    pending_review: int = 0
    solvent_distribution: dict[str, int] = Field(default_factory=dict)
    hours_saved_estimate: float = 0.0
    likely_impurity_flags: int = 0
    latest_activity: list[AuditEventRecord] = Field(default_factory=list)


class SampleAnalysisComparisonItem(BaseModel):
    model_config = ConfigDict(extra="forbid")

    analysis_id: int
    created_at: datetime
    label: DiagnosticLabel
    final_label: str | None = None
    proton_count_delta: int = 0
    confidence: float
    impurity_flags: int = 0
    reviewer_outcome: ReviewStatus
    peak_count: int = 0
    peak_count_change: int = 0
    time_saved: float = 0.0


class SampleAnalysisComparison(BaseModel):
    model_config = ConfigDict(extra="forbid")

    sample: ProjectSampleRecord
    basis: Literal["sample_id", "smiles", "none"]
    items: list[SampleAnalysisComparisonItem] = Field(default_factory=list)


class MetricCard(BaseModel):
    model_config = ConfigDict(extra="forbid")

    key: str
    label: str
    value: float
    unit: str | None = None
    detail: str | None = None


class MetricsSummary(BaseModel):
    model_config = ConfigDict(extra="forbid")

    total_analyses: int
    total_jobs: int
    pending_review: int
    approved_reviews: int
    rejected_reviews: int
    overrides: int
    validation_failures: int
    likely_impurity_flags: int
    hours_saved_estimate: float
    automation_rate: float = Field(ge=0.0, le=1.0)
    cards: list[MetricCard] = Field(default_factory=list)


class AdminUserRecord(BaseModel):
    model_config = ConfigDict(extra="forbid")

    id: int
    email: EmailStr
    is_active: bool
    is_admin: bool
    is_verified: bool
    created_at: datetime
    analyses_count: int = 0
    jobs_count: int = 0


class AdminSystemSummary(BaseModel):
    model_config = ConfigDict(extra="forbid")

    users: int
    admins: int
    active_users: int
    analyses: int
    jobs: int
    pending_review: int
    audit_events: int
    queue_backend: str
    redis_configured: bool
