# NMRCheck

This is the canonical active baseline for NMRCheck.

Core surface area:

- authenticated registration, login, verification, and password reset
- rule-based `¹H NMR` validation and analysis against SMILES
- solvent-aware `¹H` evidence scoring and beta `¹³C NMR` validation
- review queue, audit logging, admin controls, and metrics
- processed spectrum preview and analysis for CSV / TSV / JDX / DX uploads
- raw Bruker and Varian/Agilent 1D FID beta preview, analysis, reports, and reviewer signoff
- guarded processed 2D NMR evidence support for COSY, HSQC/HMQC, and HMBC behind `ENABLE_2D_NMR`

Canonical source of truth:

- `src/nmrcheck/settings.py`
- `src/nmrcheck/api.py`
- `src/nmrcheck/web.py`
- `src/nmrcheck/spectrum.py`
- `src/nmrcheck/fid.py`
- `src/nmrcheck/orm.py`
- `src/nmrcheck/models.py`

## Supported processed spectrum formats

- CSV / TSV peak tables
- CSV / TSV processed traces
- simple JCAMP-DX (JDX / DX) XY-style exports

## Supported raw FID beta formats

- Bruker 1D dataset `.zip`, `.tar.gz`, or `.tgz` archive with a folder containing `fid` and `acqus`
- Varian/Agilent 1D dataset `.zip`, `.tar.gz`, or `.tgz` archive with a folder, often ending in `.fid`, containing `fid` and `procpar`

Raw FID-derived evidence requires human reviewer signoff before final report use.

## Guarded 2D NMR Evidence Engine

Week 25 adds an additive, feature-flagged processed 2D evidence layer. Set
`ENABLE_2D_NMR=true` to expose `POST /nmr2d/preview`,
`POST /nmr2d/analyze`, `GET /nmr2d/runs/{run_id}`,
`GET /nmr2d/runs/{run_id}/report`, and the guarded UI section. The module
accepts processed COSY, HSQC/HMQC, and HMBC peak tables
(`.csv`, `.tsv`, `.json`), optionally carries lightweight contour preview
points from intensity-bearing tables, links correlations to current ¹H and
¹³C text context, and stores a separate `nmr2d_runs` record for review.
Local development defaults to `ENABLE_2D_NMR=true` and
`ENABLE_2D_CONTOUR_PREVIEW=true`; `ENABLE_RAW_2D_FID_BETA=false` keeps raw 2D
FID/SER processing disabled unless explicitly enabled for beta work. When
`ENABLE_2D_NMR=false`, protected 2D endpoints return a clear feature-flag error
and the UI hides the 2D navigation and section.

The 2D layer is intentionally separate from the stable ¹H, ¹³C, spectrum
viewer, raw FID vault, reports, and reviewer workflows. Regression tests pin
those existing outputs while the feature flag is enabled. Raw 2D FID/SER
production processing is not implemented in this guarded release.

## Immutable Raw FID Vault

Raw FID uploads are handled non-destructively. The original archive is hashed
with SHA-256, inspected for safe paths/files, stored in the local immutable raw
data vault by default (`RAW_VAULT_DIR`, default `raw_data_vault/`), and
recorded in the `raw_archives` table with vendor/acquisition metadata and
required-file status. Bruker metadata is read from `acqus`, optional `procs`,
and `pulseprogram`; Varian/Agilent metadata is read from `procpar`, without
editing vendor files. Processing outputs are stored as derivative metadata. The app does not overwrite
raw binary FID files or extracted FID/SER files. Vault limits and policy are
controlled with `RAW_ARCHIVE_MAX_BYTES`, `RAW_ARCHIVE_MAX_FILES`,
`RAW_ARCHIVE_ALLOWED_EXTENSIONS`, `RAW_ARCHIVE_IMMUTABLE`, and
`RAW_ARCHIVE_REQUIRE_HASH_VERIFICATION`. The stored archive SHA-256 is
recalculated before download, preview/process, and export; mismatches are
blocked and audited as `raw_fid.integrity_failure`. FID evidence packages are available at
`GET /fid/runs/{run_id}/package` and include `analysis.json`,
`processing_metadata.json`, `raw_upload_provenance.json`,
`raw_archive_export_manifest.json`, and the original archive when it is still
available in immutable storage.

Raw FID beta processing defaults to automatic phase correction followed by
Bernstein polynomial baseline correction, order 3. Phase and baseline correction
settings, p0/p1, phase score, Bernstein coefficients, baseline QA, warnings, and
whether each correction was applied are recorded in metadata for review.
Processed spectrum uploads are not baseline corrected by default; processed-file
baseline correction is optional and explicit.

FID processing runs link back to the immutable raw archive by database ID and
SHA-256. Run records store the processing recipe and derived spectrum metadata
separately from the raw archive, including phase, baseline, zero-fill,
apodization, digital-filter correction status, reference/solvent context,
peak-picking settings, warnings, and reviewer status.
The structured `FIDProcessingRecipe` defaults to auto phasing, Bernstein
baseline correction order 3, real display mode, vertical gain `1.0`, and
`debug_preview=false`. Reprocessing builds a new recipe against the verified
vault archive instead of editing or replacing the original FID package.

The explicit immutable-vault workflow is:

- `POST /raw-fid/upload` stores the original archive and returns its SHA-256 archive ID.
- `GET /raw-fid/{archive_id}` returns metadata and integrity status only.
- `GET /raw-fid/{archive_id}/download` verifies SHA-256 before serving original bytes.
- `POST /raw-fid/{archive_id}/preview` processes a temporary preview without creating a run unless requested.
- `POST /raw-fid/{archive_id}/process` creates a linked FID processing run and analysis.
- `GET /raw-fid/{archive_id}/runs` lists derived processing runs.
- `GET /raw-fid/{archive_id}/export` packages the verified original archive, recipe, derived peak CSV, evidence report, audit trail, and hash manifest.

The export manifest records hashes for the original archive and derived evidence
files so a reviewer can verify that the raw data were preserved and that
processing runs are separate derived artifacts.

Legacy `/fid/preview` and `/fid/process` remain available. `/fid/preview` is now
temporary preview-only and recommends the explicit raw-vault workflow;
`/fid/process` stores the upload in the vault before processing and records a
legacy warning in provenance.

## Core invariants

- empty SMILES must fail
- invalid SMILES must fail
- empty `¹H NMR` text must fail
- malformed `¹H NMR` text must fail
- structure and parsed `¹H NMR` text must agree before analysis is accepted
- unsupported processed spectrum formats must fail clearly
- reference-assisted matching must remain visible in preview/analyze
- spectrum viewer controls must not break the analysis flow
- display gain is y-axis only and must not alter evidence intensity data
- raw FID uploads are immutable vault records; processing stores derived metadata and hashes, never raw overwrites
- stale auth tokens must return the UI to the auth screen cleanly

## Workflow smoke coverage

The test suite now covers a direct route-level workflow that exercises:

1. register
2. login
3. validate
4. analyze
5. spectrum preview
6. reference-assisted spectrum analysis
7. job submission
8. approve / reject review actions
9. export endpoints
10. FID run review/report actions
11. E2E API smoke coverage for auth, validation, analysis, workspaces, health, and deployment diagnostics

## Week 20 Additions

Varian/Agilent 1D beta detection and nmrglue processing dispatch are now wired into the existing Raw FID flow. Deployment hardening now includes `GET /admin/deployment`, startup setting validation, Render install of optional FID dependencies, and the checklist in `docs/deployment_hardening.md`.

## Week 21 Release Candidate

Scientific validation fixtures, regression coverage, `GET /admin/release-health`, local SQLite reset via `python -m nmrcheck.cli reset-dev-db`, GitHub Actions CI, and evidence-confidence reporting are now included. The Raw FID run history is presented as one reviewer table with Open, Select, Report, Approve, and Reject actions.

## Week 22 Evidence Engine

The app now includes ¹H peak-level evidence scoring plus a ¹³C NMR beta layer. New endpoints include `POST /proton/evidence`, `POST /carbon13/validate`, `POST /carbon13/analyze`, `POST /carbon13/evidence`, `POST /carbon13/upload`, `POST /carbon13/spectrum/preview`, `POST /carbon13/spectrum/analyze`, `POST /carbon13/fid/preview`, and `POST /carbon13/fid/analyze`. The ¹³C path compares observed non-solvent carbon signals with the SMILES-derived carbon count, classifies carbon-shift regions, accepts optional DEPT/APT-like carbon types, and checks embedded ¹³C solvent/impurity-reference shifts.

Run the full regression suite with:

```bash
PYTHONPATH=src uv run pytest
```
